# Python Interview Practice - 18 Repository Exercises

This pack adapts all 18 numbered exercise folders from [Krishnazz/Karat-Preperation](https://github.com/Krishnazz/Karat-Preperation) into Python. It preserves the distinct transaction, music, and rental variants. It is an independent Python practice adaptation of a community preparation repository.

Source snapshot: `d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba`. Prepared November 23, 2026.

## Start here

Use **Python 3.10 or newer**. No packages need to be installed. Extract the ZIP and open a terminal in the `karat_python` folder. On Windows, use `py` instead of `python` if that is how Python is installed.

```bash
python run_tests.py --list
python run_tests.py --exercise 01 --stage 1 -v
```

Read `exercises/01-CloudCompute/QUESTION.md`, then edit that folder's `starter.py`.

The unedited Stage 1 starter intentionally produces exactly **one failing test method** per exercise, plus passing tests. A failing exit code is expected until you fix the bug. Later stages contain `NotImplementedError` stubs and are run separately.

```bash
# After fixing Stage 1, implement and run the next stage.
python run_tests.py --exercise 01 --stage 2 -v
python run_tests.py --exercise 01 --stage 3 -v

# Check your full implementation.
python run_tests.py --exercise 01 --stage all

# Review the supplied reference solution after your attempt.
python run_tests.py --exercise 01 --mode solution --stage all

# Validate every reference solution.
python run_tests.py --exercise all --mode solution --stage all
```

Stage availability differs by exercise. The Transactions exercise includes an optional Stage 5 adapted from solution-only helper methods; its original prompt has four numbered stages. Campus stages and the Music 16 playlist task are reconstructed from source code/tests and are labeled accordingly.

## Contents

| ID | Exercise | Available stages | Main focus |
|---|---|---|---|
| 01 | [Cloud Compute Reservations](exercises/01-CloudCompute/QUESTION.md) | 1, 2, 3 | Maintain compute pools and reservations, calculate remaining capacity, and expire reservations at a supplied time. |
| 02 | [Gym Membership and Workout Billing](exercises/02-Gym/QUESTION.md) | 1, 2, 3 | Manage membership levels, summarize workouts, and calculate tier-based charges after free workouts. |
| 03 | [Clinic Appointments and Patient Visits](exercises/03-Doctor/QUESTION.md) | 1, 2 | Summarize appointment outcomes and calculate each doctor's average visit duration by visit type. |
| 04 | [Campus Access Control](exercises/04-Campus/QUESTION.md) | 1, 2, 3 | Authorize campus users according to an access hierarchy, record access sessions, and identify users present outside opening hours. |
| 05 | [Device Fleet Lifecycle](exercises/05-DeviceFleet/QUESTION.md) | 1, 2 | Enforce device status transitions, validate registrations, and count active devices by type. |
| 06 | [Account Transactions and Activity Monitoring](exercises/06-Transactions/QUESTION.md) | 1, 2, 3, 4, 5 | Repair account balances, calculate transaction statistics and fees, and detect suspicious debit activity. Two optional analytics helpers are extracted from the source solution. |
| 07 | [Insurance Claims and Status History](exercises/07-Insurance/QUESTION.md) | 1, 2 | Track claim outcomes and keep an audit history of staff decisions. Status statistics summarize all claims; history summaries count actions by approver role. |
| 08 | [Stock Prices, Consecutive Changes, and Portfolio Value](exercises/08-StockMarket/QUESTION.md) | 1, 2, 3 | Maintain historical stock prices, identify the sharpest recorded movement, and value a user portfolio at current recorded prices. |
| 09 | [Imported Transactions, Running Balances, and Type Summaries](exercises/09-TransactionNew/QUESTION.md) | 1, 2 | Import financial events from multiple sources, report account activity, and maintain balances for newly recorded transactions. |
| 10 | [Medical Equipment Reservations and Status Reports](exercises/10-Rental/QUESTION.md) | 1, 2 | Manage shared clinic equipment, allow staff to reserve time intervals, and report booked minutes by reservation status. |
| 11 | [Listener Statistics and Duplicate Song Groups](exercises/11-Music/QUESTION.md) | 1, 2 | Analyze listener activity and identify duplicate catalog records imported from different feeds. Keep skipped plays in listener statistics and use deterministic IDs when reporting duplicate groups. |
| 12 | [Order Status and Restaurant Delivery Averages](exercises/12-FoodDelivery/QUESTION.md) | 1, 2 | Track food orders through their lifecycle and report delivery performance for each restaurant. An order may have multiple delivery records. |
| 13 | [Player Statistics, Head-to-Head Results, and Recent Form](exercises/13-Playground/QUESTION.md) | 1, 2, 3, 4 | Maintain player records and per-player match observations, then answer statistics and ranking queries. A match may have a separate observation for each participant. |
| 14 | [Banking Compliance Queries](exercises/14-TransactionLatest/QUESTION.md) | 1, 2 | Store the day's financial events and provide account-level and high-value transaction queries. This is the repository's latest transaction variant, with two stages. |
| 15 | [Order Notifications and Idempotent Delivery Updates](exercises/15-Notification/QUESTION.md) | 1, 2 | Manage messages generated for retail orders. Providers can repeat delivery updates within a batch or across batches; only new status/timestamp pairs should be retained. |
| 16 | [Music Analytics, Duplicate Groups, and Playlist Rules](exercises/16-Music/QUESTION.md) | 1, 2, 3 | Compute listener statistics, identify duplicate catalog entries, and evaluate playlist rules. This later music variant includes a playlist task reconstructed from the source tests and implementation. |
| 17 | [Toll Logs, Complete Journeys, and Speeding Detection](exercises/17-TollBooth/QUESTION.md) | 1, 2, 3 | Parse toll-booth observations, count completed highway journeys, and flag journeys whose segment speeds exceed the stated thresholds. |
| 18 | [Equipment Reservations with Turnaround Time](exercises/18-RentalLatest/QUESTION.md) | 1, 2, 3 | Manage sports-facility equipment reservations, query active member bookings, and find equipment with a 30-minute cleaning gap around a requested interval. |

## Files in every exercise

| File | Purpose |
|---|---|
| `QUESTION.md` | Python question, data model, method contracts, examples, and clarifications. |
| `starter.py` | Existing code with a Stage 1 regression, plus later-stage method stubs. |
| `test_exercise.py` | Staged standard-library unittest checks. |
| `solution.py` | Complete reference implementation. |
| `SOLUTION_NOTES.md` | Bug explanation, source corrections, assumptions, test coverage, and complexity. |
| `metadata.json` | Machine-readable question and source mapping. |

## What was preserved and what changed

- All 18 original scenario folders remain separate, with original numbering.
- Java models become Python dataclasses or ordinary classes; enums remain enums where appropriate; methods use snake_case.
- Written requirements take priority over incorrect Java reference implementations. Exercise notes identify every substantive correction found during conversion.
- When a source comment records the old bug, the starter reconstructs it. If the source is already correct and preserves no original defect, the candidate question labels an **added practice regression** instead of claiming it was the original bug.
- Original test scenarios are translated and additional boundary or state tests are documented. Stage 1 regressions may be grouped into one test method to preserve the single-failure practice format.
- No source claims about official Karat scoring or guaranteed interview questions are made.

The complete combined reading guide is `QUESTION_BOOK.md`. The companion PDF contains questions and contracts without solution code. `CONVERSION_REPORT.md` records source inconsistencies and test results. `SOURCES.md` and `source_manifest.json` retain source links and revision details.

## Verification

Verified with Python 3.12.14: **132 reference-solution tests pass** across all 18 exercises. All selectable stages also pass individually. Across Stage 1 starters, 54 tests produce exactly 18 intentional failures (one per exercise), with no test errors.

There are 48 selectable stage groups, including 1 optional solution-derived stage group(s). This is a packaging count, not a claim about the original repository's interview structure.

## Suggested practice approach

State the requirement violated by the failing test, trace the shortest relevant code path, make a focused fix, and rerun the whole current stage. Then implement the next task while preserving existing behavior. Read the reference solution only after your attempt.
