# Conversion and verification report

Source commit: `d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba`. Python 3.12.14.

All 132 full reference-solution tests pass. All 18 unedited starters have exactly one Stage 1 failure and no errors.

## Per-exercise results

| ID | Reference tests | Starter Stage 1 tests | Expected failures |
|---|---:|---:|---:|
| 01 | 7 | 2 | 1 |
| 02 | 7 | 3 | 1 |
| 03 | 5 | 2 | 1 |
| 04 | 7 | 3 | 1 |
| 05 | 7 | 3 | 1 |
| 06 | 12 | 2 | 1 |
| 07 | 6 | 3 | 1 |
| 08 | 7 | 3 | 1 |
| 09 | 6 | 3 | 1 |
| 10 | 6 | 4 | 1 |
| 11 | 5 | 2 | 1 |
| 12 | 4 | 2 | 1 |
| 13 | 11 | 3 | 1 |
| 14 | 7 | 4 | 1 |
| 15 | 7 | 4 | 1 |
| 16 | 9 | 3 | 1 |
| 17 | 9 | 3 | 1 |
| 18 | 10 | 5 | 1 |

## Source issues and adaptation decisions


### 01 - Cloud Compute Reservations

Bug provenance: Reconstructed from the explicit bug comment in the published question.

- The source question already contains the ACTIVE-status fix and a comment describing the prior bug. The Python starter removes that guard to restore the documented challenge.
- Stage 2 methods are absent from the Java question despite being called by tests. Python supplies explicit stubs.
- Preserved the source admission rule rather than adding status, duplicate-ID, or start-time restrictions.

Details: [SOLUTION_NOTES.md](exercises/01-CloudCompute/SOLUTION_NOTES.md).


### 02 - Gym Membership and Workout Billing

Bug provenance: Original paid-membership classification defect retained from the source question.

- Both Java files count only GOLD as paid; the Python starter preserves this classification bug, and the solution counts SILVER and GOLD.
- Java percentage arithmetic uses integer division. Python uses true division to preserve fractional percentages; this language conversion removes a separate arithmetic defect.
- The Java billing solution calls Math.ceil(duration / 60) after integer division. Python computes ceiling hours correctly, following the prompt.
- The Java main method does not call the supplied billing test. The Python suite executes that test in Stage 3. Unused redundant workout collections were removed.

Details: [SOLUTION_NOTES.md](exercises/02-Gym/SOLUTION_NOTES.md).


### 03 - Clinic Appointments and Patient Visits

Bug provenance: Added practice regression because the source starter already passes its statistics test.

- The published question already computes statistics correctly; the Python starter therefore contains an added practice regression, not a recovered historical bug.
- The added regression replaces real division with integer division, which the source fractional-rate test detects.
- The source question omits visit-method definitions and comments out average tests. Explicit stubs and active translated tests restore the described tasks.
- The source addPatientVisit test contains no assertions; Python adds storage and exclusion assertions for the same supplied records.

Details: [SOLUTION_NOTES.md](exercises/03-Doctor/SOLUTION_NOTES.md).


### 04 - Campus Access Control

Bug provenance: Reconstructed from the commented equality-only implementation and source lower-level authorization tests.

- Both published files contain completed implementations rather than unsolved question text.
- The authorization starter restores the equality-only implementation left as a comment in the source.
- Narrative requirements and the three-stage structure are reconstructed from code comments and tests; they are not claimed as an original numbered prompt.

Details: [SOLUTION_NOTES.md](exercises/04-Campus/SOLUTION_NOTES.md).


### 05 - Device Fleet Lifecycle

Bug provenance: Added practice regression derived from the source invalid-transition tests; published starter is already fixed.

- The source status-update code already checks the transition table and passes its tests. The Python starter introduces an added practice regression that omits transition validation.
- The existing valid-status check remains so the regression is confined to disallowed transitions between otherwise recognized states.
- Removed diagnostic printing and preserved the unused ReplacementEntry data model without inventing a new task.

Details: [SOLUTION_NOTES.md](exercises/05-DeviceFleet/SOLUTION_NOTES.md).


### 06 - Account Transactions and Activity Monitoring

Bug provenance: Original missing-DEBIT branch retained from the source question.

- The Java question contains a malformed opening block comment; Python uses clean standalone source.
- The Java suspicious-account solution can add duplicate IDs for overlapping qualifying triples and does not sort the output. Python follows the explicit sorted-list contract and returns unique IDs.
- The Java fee solution omits accounts that incur no fee. Python makes the stated per-account output explicit by including zero-fee accounts; this clarification is visible in the question.
- The source model comment claims monotonic test timestamps, but later supplied tests are deliberately shuffled. Python follows the task text and chronological source fee test.
- Two solution-only helpers are retained as clearly labeled optional Stage 5. Their behavior is derived from code, and their tests are newly added.

Details: [SOLUTION_NOTES.md](exercises/06-Transactions/SOLUTION_NOTES.md).


### 07 - Insurance Claims and Status History

Bug provenance: The original bug is restored from an explicit source comment; Stage 1 wording is reconstructed from the supplied code and tests. This source has two stages.

- The problem file begins with Stage 2; the Stage 1 contract is reconstructed from its model comments and existing statistics tests.
- Both Java files already include the repaired resolved-state predicate. The commented original predicate identifies the restored starter bug.
- Java divides zero by zero for an empty claim list. The Python exercise explicitly defines an empty resolution rate of 0.0.
- The supplied status_history declaration is retained as scaffolding; Stage 2 still requires checking independent initialization and implementing the two new methods.

Details: [SOLUTION_NOTES.md](exercises/07-Insurance/SOLUTION_NOTES.md).


### 08 - Stock Prices, Consecutive Changes, and Portfolio Value

Bug provenance: Stage 1 includes an added practice regression because the published Stage 1 code already passes its tests. This is not claimed to recover the original interview bug.

- The published Stage 1 implementation already computes a correct average and exposes no original bug. An added practice regression uses integer division and is caught by the original 104.25 average assertion.
- The Java biggest-change code initializes a sentinel to Integer.MIN_VALUE; its absolute value overflows in Java, and a direct Python port would also misbehave. Initialize from a real adjacent pair instead.
- The Java solution returns an invalid sentinel result for a single record; this adaptation returns None, matching the absence of a pair.
- The problem-file portfolio implementation groups by company name, while the separate solution compares full Stock objects. Python follows the stated stock identity (symbol and name).
- The Java solution applies abs to net holdings; Python follows buy-minus-sell arithmetic and does not turn negative positions into positive holdings.
- Stray whitespace in some problem-file symbols/dates is normalized to the clean Solution.java fixtures.

Details: [SOLUTION_NOTES.md](exercises/08-StockMarket/SOLUTION_NOTES.md).


### 09 - Imported Transactions, Running Balances, and Type Summaries

Bug provenance: Stage 1 retains the original defect present in the source problem. Later-stage implementations are replaced by stubs. This source has two stages.

- The original Stage 1 bug is preserved directly: net_change is assigned credits without subtracting debits.
- The problem file contains completed later-stage code; Python restores method stubs for practice while retaining the balances declaration as model scaffolding.
- The source test runner comments out the Stage 2 tests. The Python staged runner enables them explicitly.

Details: [SOLUTION_NOTES.md](exercises/09-TransactionNew/SOLUTION_NOTES.md).


### 10 - Medical Equipment Reservations and Status Reports

Bug provenance: Stage 1 contains an added practice regression because the published code already passes its tests. The source provides two stages; the rental variant is kept separate from RentalLatest.

- The published Stage 1 code already checks active status and passes its existing tests. Removing that check is an added practice regression, chosen to exercise its supplied cancelled-slot test.
- The source cancelReservation documentation says to cancel active bookings, but the implementation returns True on a repeated cancellation. Both Python starter and solution honor the stated active-only contract; this is a documented correction, not the intentional regression.
- The source supplies completed reporting methods; the Python starter replaces them with Stage 2 stubs.
- No equipment-existence check is introduced because the source test fixtures intentionally omit equipment registration.

Details: [SOLUTION_NOTES.md](exercises/10-Rental/SOLUTION_NOTES.md).


### 11 - Listener Statistics and Duplicate Song Groups

Bug provenance: Stage 1 preserves the original wrong-list defect. Stage 2 follows the stated duplicate-group requirements and corrects additional flaws in the Java reference solution. This source has two stages.

- The original starter appends completed plays to the global play-event list instead of the local completed list. The Python starter preserves that single wrong-list defect.
- The Java dedup solution uses a persistent group map, so repeated calls accumulate entries. Python builds groups per call.
- The Java dedup solution assumes iteration order yields the smallest ID and sorted remaining IDs. Python explicitly sorts each duplicate group.
- A tuple key avoids collisions possible with concatenated title and artist text. Optional metadata is retained in the model but does not affect grouping.

Details: [SOLUTION_NOTES.md](exercises/11-Music/SOLUTION_NOTES.md).


### 12 - Order Status and Restaurant Delivery Averages

Bug provenance: Stage 1 contains an added practice regression because the published statistics code already passes its test. The delivery tasks preserve the source requirements. This source has two stages.

- Both Java files already correctly include all active order statuses. The Python starter inserts an added practice regression that omits PREPARING; it is not claimed to be the original interview bug.
- The prompt leaves no-delivery restaurant behavior unspecified. The reference solution uses 0.0, so that behavior is explicitly retained.
- The source provides per-order delivery lists; Python uses a separate default_factory list for every order.

Details: [SOLUTION_NOTES.md](exercises/12-FoodDelivery/SOLUTION_NOTES.md).


### 13 - Player Statistics, Head-to-Head Results, and Recent Form

Bug provenance: Restored from the commented-out WIN-only condition in the original problem file.

- The source problem already comments out the original WIN-only total-matches filter. The starter restores that documented fault.
- The Java head-to-head answer returns timestamp 0 for an empty history, contrary to its None/null requirement. The Python answer returns None.
- The Java recent-form answer lacks the required final sorting and n <= 0 handling. Both are implemented according to the prose contract.
- Head-to-head selection in the source is directional; the Python question states this explicitly to avoid double-counting reciprocal observations.

Details: [SOLUTION_NOTES.md](exercises/13-Playground/SOLUTION_NOTES.md).


### 14 - Banking Compliance Queries

Bug provenance: Added practice regression because the source Stage 1 implementation is already corrected; it is not claimed to be the original interview fault.

- The checked-in problem already contains a correct Stage 1 account query. Its original fault is not recoverable from the repository.
- To supply the requested debugging experience, the Python starter includes an added practice regression comparing the transaction ID to the requested account ID. The existing source account-filtering test detects it.
- There are only two source stages; no third-stage problem has been invented.

Details: [SOLUTION_NOTES.md](exercises/14-TransactionLatest/SOLUTION_NOTES.md).


### 15 - Order Notifications and Idempotent Delivery Updates

Bug provenance: Added practice regression supported by the source order-filtering test because the checked-in Stage 1 code is already correct.

- The source already implements the Stage 1 order query correctly; the original failing line is not preserved.
- The Python starter adds a documented practice regression by filtering on notification_id instead of order_id. This is an introduced exercise fault, not a claim about the original interview code.
- The original problem text has incomplete Java comment/bracing structure. Only its intended API and behavior are carried over.
- The Java answer encodes pairs into strings; the Python answer uses a set of tuples to represent exactly the specified duplicate identity.

Details: [SOLUTION_NOTES.md](exercises/15-Notification/SOLUTION_NOTES.md).


### 16 - Music Analytics, Duplicate Groups, and Playlist Rules

Bug provenance: Added practice regression at the documented completion boundary; the source Stage 1 code itself is already corrected.

- The checked-in Stage 1 implementation is already fixed. The starter adds a practice boundary fault (> instead of >=) detected by the original statistics scenario.
- The Java deduplication answer stores grouping state across calls, does not apply its attempted sort, and uses a space-concatenated key that can collide. Python uses a fresh tuple-keyed dictionary and explicit sorting.
- The Java playlist answer accumulates counters across multiple rules of the same type. Python evaluates each rule with independent totals.
- Stage 3 wording is reconstructed from tests and code because the source omits its prose prompt. No additional rule types are added.

Details: [SOLUTION_NOTES.md](exercises/16-Music/SOLUTION_NOTES.md).


### 17 - Toll Logs, Complete Journeys, and Speeding Detection

Bug provenance: The starter preserves the observable Java float32 timestamp narrowing. A corrected precision assertion makes the failure visible in Python.

- Both source files parse timestamps with Float.parseFloat before storing them in double fields. The Python starter explicitly emulates this float32 narrowing; the solution uses Python float directly.
- The source timestamp assertions use f-suffixed literals, which round their expected values too. The Python tests compare with the decimal timestamp text at the stated 0.0001-second tolerance.
- The disabled Java testLogFile expects 13 records, but SMALL_LOG contains 9. The Python test corrects the expectation to 9.
- The Java speed-check answer can dereference a missing fast-segment counter when the first segment is below 120 km/h. The Python solution initializes journey counters.
- The count fixture includes a non-consecutive booth jump. It remains a counting example only; all speeding tests use genuine 10 km segments.

Details: [SOLUTION_NOTES.md](exercises/17-TollBooth/SOLUTION_NOTES.md).


### 18 - Equipment Reservations with Turnaround Time

Bug provenance: Reconstructed cancellation regression from the supplied cancellation-frees-slot test; the checked-in problem already contains the status-aware fix.

- The checked-in problem already includes the active-status fix and completed later-stage methods. The Python starter restores a cancelled-booking regression supported by testCancelledReservationFreesSlot and replaces later tasks with stubs.
- The prose about turnaround could be read as changing all reservation creation. Earlier source tests accept adjacent bookings; therefore the new 30-minute requirement is scoped to get_available_equipment, matching the source implementation.
- Source tests create reservations without first registering equipment. Python preserves this behavior instead of adding a new rejection condition.

Details: [SOLUTION_NOTES.md](exercises/18-RentalLatest/SOLUTION_NOTES.md).

