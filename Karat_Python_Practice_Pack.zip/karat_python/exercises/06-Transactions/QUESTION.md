# 06. Account Transactions and Activity Monitoring

Repair account balances, calculate transaction statistics and fees, and detect suspicious debit activity. Two optional analytics helpers are extracted from the source solution.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/06-Transactions/TransactionProblem.txt).

The source has four numbered stages. Optional Stage 5 is extracted from two extra methods found only in its solution file; it is clearly separate from the original questions.

## Data model

- `TransactionType`: Enum: CREDIT, DEBIT
- `Account`: account_id: int, owner_name: str
- `Transaction`: transaction_id: int, account_id: int, type: TransactionType, amount: float, timestamp_sec: int

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug account balances

- Read the account manager and repair get_balance. CREDIT increases the balance and DEBIT decreases it. Transactions belonging to another account must not affect the result.
- Accounts with no transactions have a zero balance. Existing account and transaction registration methods are provided.

Python methods:

```python
get_balance(account_id: int) -> float
```

## Stage 2: Average transaction amount

- Return account IDs mapped to the average absolute transaction amount, including CREDIT and DEBIT records.
- Omit accounts without transactions. All transactions refer to valid accounts.

Python methods:

```python
get_average_transaction_amount_by_account() -> dict[int, float]
```

## Stage 3: Calculate transaction fees

- Order transactions by timestamp_sec separately for each account. Its first three transactions are free.
- Every later CREDIT costs $1 and every later DEBIT costs $2. Return the total fee per account.

Python methods:

```python
get_transaction_fees() -> dict[int, float]
```

## Stage 4: Detect suspicious accounts

- Consider only DEBIT records whose amount is at least 50.
- An account qualifies if any three or more such records fit in an inclusive 60-second window. Input records may arrive out of order.
- Return qualifying account IDs once each in ascending order. Records at t and t+60 can be in the same window.

Python methods:

```python
get_suspicious_accounts() -> list[int]
```

## Stage 5: Optional: additional analytics from the Java solution

- These two helpers exist only in Solution.java; they are optional practice questions derived from that code, not numbered tasks in the original prompt.
- get_top_spending_account returns the account with the largest total DEBIT amount. Break equal-total ties by smaller account ID; return -1 if there are no debit transactions.
- get_transaction_count_by_account maps each account with transactions to its number of records, including both types. Omit accounts with no records.

Python methods:

```python
get_top_spending_account() -> int
get_transaction_count_by_account() -> dict[int, int]
```

## Examples

Credits of 100 and 10 plus debits of 30 and 20 produce a balance of 60 and an average amount of 40. Three large debits at times 500, 530, and 560 qualify; replacing 560 by 561 does not.

## Clarifications

- Source inputs use positive amounts, valid enum values, unique transaction IDs, and valid account IDs. Negative balances are permitted; no overdraft rejection is requested.
- No fees are subtracted by get_balance: fees are a separate report.
- Fee output includes all registered accounts, with 0.0 for accounts having at most three transactions. This makes the prompt's "each account" behavior explicit where source tests are silent.
- For equal timestamps, retain insertion order (stable sorting). This is an adaptation clarification because the source does not specify another tie-break.
- The source fee prompt says getPaymentFee, while its implementation/tests say getTransactionFees. The Python API uses get_transaction_fees.
