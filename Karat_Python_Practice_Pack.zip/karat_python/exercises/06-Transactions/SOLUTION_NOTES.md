# Account Transactions and Activity Monitoring: solution notes

## Stage 1

The starter sums CREDIT amounts but never subtracts DEBIT amounts. Add the debit branch while retaining the account-ID filter.

Provenance: Original missing-DEBIT branch retained from the source question.

## Source corrections and adaptation decisions

- The Java question contains a malformed opening block comment; Python uses clean standalone source.
- The Java suspicious-account solution can add duplicate IDs for overlapping qualifying triples and does not sort the output. Python follows the explicit sorted-list contract and returns unique IDs.
- The Java fee solution omits accounts that incur no fee. Python makes the stated per-account output explicit by including zero-fee accounts; this clarification is visible in the question.
- The source model comment claims monotonic test timestamps, but later supplied tests are deliberately shuffled. Python follows the task text and chronological source fee test.
- Two solution-only helpers are retained as clearly labeled optional Stage 5. Their behavior is derived from code, and their tests are newly added.

## Tests

Translated the source basic and multi-account balances, averages, all three fee accounts (including the shuffled third account), and both suspicious-activity scenarios. Added free-tier boundaries, empty results, zero-fee accounts, equal timestamp ordering, overlapping qualifying windows, unique sorted account IDs, and optional-helper tie/count behavior.

## Complexity

For T transactions and A accounts, balance, average, count, and top-spender operations take O(T) time (plus O(A) result/storage for grouped operations). Fee calculation and suspicious detection take O(T log T) worst-case time for per-account sorting and O(T + A) additional space. Inspecting consecutive triples after sorting is sufficient: any window with at least three qualifying records contains a qualifying consecutive triple.

## Source

[Question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/06-Transactions/TransactionProblem.txt) | [Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/06-Transactions/Solution.java)
