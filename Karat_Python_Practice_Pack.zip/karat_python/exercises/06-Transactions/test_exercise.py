import unittest

def build_suite(M, stage="all"):
    C,D=M.TransactionType.CREDIT,M.TransactionType.DEBIT

    def manager(ids=(1,2,3)):
        m=M.AccountManager()
        for ident in ids:
            m.add_account(M.Account(ident,str(ident)))
        return m

    def add(m,rows):
        for row in rows:
            m.add_transaction(M.Transaction(*row))

    class Stage1(unittest.TestCase):
        def test_source_regression(self):
            # The two original failing balance scenarios share one regression test.
            m=manager((1,))
            add(m,[(101,1,C,100.0,1000),(102,1,D,30.0,1010),(103,1,D,20.0,1020),(104,1,C,10.0,1030)])
            self.assertAlmostEqual(m.get_balance(1),60.0)
            m=manager((1,2))
            add(m,[(201,1,C,50.0,2000),(202,2,C,80.0,2005),(203,1,D,10.0,2010),
                   (204,2,D,5.5,2015),(205,2,D,14.5,2020)])
            self.assertAlmostEqual(m.get_balance(1),40.0)
            self.assertAlmostEqual(m.get_balance(2),60.0)

        def test_empty_and_credit_only(self):
            m=manager()
            self.assertEqual(m.get_balance(1),0.0)
            add(m,[(1,1,C,15.5,100),(2,2,C,20.0,100)])
            self.assertAlmostEqual(m.get_balance(1),15.5)
            self.assertEqual(m.get_balance(99),0.0)

    class Stage2(unittest.TestCase):
        def test_source_averages(self):
            m=manager()
            add(m,[(101,1,C,100.0,1000),(102,1,D,30.0,1010),(103,1,D,20.0,1020),(104,1,C,10.0,1030),
                   (201,2,C,80.0,2005),(202,2,D,5.5,2015),(203,2,D,14.5,2020)])
            result=m.get_average_transaction_amount_by_account()
            self.assertAlmostEqual(result[1],40.0)
            self.assertAlmostEqual(result[2],100/3)
            self.assertNotIn(3,result)

        def test_empty_and_single_debit(self):
            m=manager()
            self.assertEqual(m.get_average_transaction_amount_by_account(),{})
            add(m,[(1,1,D,7.5,100)])
            self.assertEqual(m.get_average_transaction_amount_by_account(),{1:7.5})

    class Stage3(unittest.TestCase):
        def test_source_fees(self):
            m=manager()
            add(m,[(1,1,C,100,1000),(2,1,D,20,1010),(3,1,C,10,1020),(4,1,D,5,1030),(5,1,C,7,1040),
                   (6,2,D,50,2000),(7,2,D,10,2010),(8,2,C,20,2020),(9,2,D,5,2030),
                   (26,3,D,50,2000),(27,3,D,10,2010),(28,3,C,20,2020),(29,3,D,5,2005)])
            self.assertEqual(m.get_transaction_fees(),{1:3.0,2:2.0,3:1.0})

        def test_free_tier_and_zero_fee_accounts(self):
            # Added, follows the explicit Python clarification.
            m=manager()
            add(m,[(1,1,D,10,100),(2,1,C,10,200),(3,1,D,10,300)])
            self.assertEqual(m.get_transaction_fees(),{1:0.0,2:0.0,3:0.0})
            add(m,[(4,1,D,10,400)])
            self.assertEqual(m.get_transaction_fees()[1],2.0)

        def test_equal_timestamp_stability(self):
            m=manager((1,))
            add(m,[(1,1,D,10,100),(2,1,D,10,100),(3,1,D,10,100),(4,1,C,10,100)])
            self.assertEqual(m.get_transaction_fees(),{1:1.0})

    class Stage4(unittest.TestCase):
        def test_source_detection(self):
            m=manager()
            add(m,[(1,1,D,50,1000),(2,1,D,70,1030),(3,1,D,90,1060),
                   (4,2,D,60,2000),(5,2,D,80,2070),(6,2,D,55,2141),
                   (7,3,C,1000,3000),(8,3,D,49.99,3010),(9,3,D,50,3020),(10,3,D,50,3100)])
            self.assertEqual(m.get_suspicious_accounts(),[1])
            m=manager((10,))
            add(m,[(100,10,D,50,500),(101,10,D,50,560),(102,10,D,50,530)])
            self.assertEqual(m.get_suspicious_accounts(),[10])

        def test_unique_sorted_ids_and_overlap(self):
            m=manager((9,2,5))
            ident=0
            for account,times in [(9,[10,20,30,40]),(2,[0,30,60]),(5,[0,30,61])]:
                for time in times:
                    ident+=1
                    add(m,[(ident,account,D,50,time)])
            self.assertEqual(m.get_suspicious_accounts(),[2,9])

        def test_empty_detection(self):
            self.assertEqual(manager().get_suspicious_accounts(),[])

    class Stage5(unittest.TestCase):
        # Added tests for source-solution-only optional extensions.
        def test_top_spender_and_tie(self):
            m=manager()
            self.assertEqual(m.get_top_spending_account(),-1)
            add(m,[(1,2,D,50,1),(2,1,D,20,2),(3,1,D,30,3),(4,3,C,999,4)])
            self.assertEqual(m.get_top_spending_account(),1)
            add(m,[(5,2,D,1,5)])
            self.assertEqual(m.get_top_spending_account(),2)

        def test_transaction_counts(self):
            m=manager()
            self.assertEqual(m.get_transaction_count_by_account(),{})
            add(m,[(1,2,D,50,1),(2,1,D,20,2),(3,1,C,30,3)])
            self.assertEqual(m.get_transaction_count_by_account(),{2:1,1:2})

    groups={'1':Stage1,'2':Stage2,'3':Stage3,'4':Stage4,'5':Stage5}
    selected=list(groups.values()) if stage=='all' else [groups[str(stage)]]
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in selected)
