from dataclasses import dataclass
from enum import Enum

class TransactionType(Enum):
    CREDIT='CREDIT'
    DEBIT='DEBIT'

@dataclass
class Account:
    account_id: int
    owner_name: str

@dataclass
class Transaction:
    transaction_id: int
    account_id: int
    type: TransactionType
    amount: float
    timestamp_sec: int

class AccountManager:
    def __init__(self):
        self.accounts: dict[int, Account] = {}
        self.transactions: list[Transaction] = []

    def add_account(self, account: Account) -> None:
        self.accounts[account.account_id] = account

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def get_balance(self, account_id: int) -> float:
        balance = 0.0
        for transaction in self.transactions:
            if transaction.account_id == account_id:
                if transaction.type is TransactionType.CREDIT:
                    balance += transaction.amount
        return balance

    def get_average_transaction_amount_by_account(self) -> dict[int, float]:
        raise NotImplementedError("Implement Stage 2.")

    def get_transaction_fees(self) -> dict[int, float]:
        raise NotImplementedError("Implement Stage 3.")

    def get_suspicious_accounts(self) -> list[int]:
        raise NotImplementedError("Implement Stage 4.")

    def get_top_spending_account(self) -> int:
        raise NotImplementedError("Implement Stage 5.")

    def get_transaction_count_by_account(self) -> dict[int, int]:
        raise NotImplementedError("Implement Stage 5.")
