from dataclasses import dataclass
from enum import Enum

class TransactionType(Enum):
    CREDIT='CREDIT'
    DEBIT='DEBIT'

@dataclass
class Account:
    account_id: int
    owner_name: str

@dataclass
class Transaction:
    transaction_id: int
    account_id: int
    type: TransactionType
    amount: float
    timestamp_sec: int

class AccountManager:
    def __init__(self):
        self.accounts: dict[int, Account] = {}
        self.transactions: list[Transaction] = []

    def add_account(self, account: Account) -> None:
        self.accounts[account.account_id] = account

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def get_balance(self, account_id: int) -> float:
        balance = 0.0
        for transaction in self.transactions:
            if transaction.account_id == account_id:
                if transaction.type is TransactionType.CREDIT:
                    balance += transaction.amount
                elif transaction.type is TransactionType.DEBIT:
                    balance -= transaction.amount
        return balance

    def get_average_transaction_amount_by_account(self) -> dict[int, float]:
        totals: dict[int, float] = {}
        counts: dict[int, int] = {}
        for transaction in self.transactions:
            key = transaction.account_id
            totals[key] = totals.get(key, 0.0) + abs(transaction.amount)
            counts[key] = counts.get(key, 0) + 1
        return {key: total / counts[key] for key, total in totals.items()}

    def get_transaction_fees(self) -> dict[int, float]:
        grouped: dict[int, list[Transaction]] = {}
        for transaction in self.transactions:
            grouped.setdefault(transaction.account_id, []).append(transaction)
        fees = {account_id: 0.0 for account_id in self.accounts}
        for account_id, records in grouped.items():
            ordered = sorted(records, key=lambda transaction: transaction.timestamp_sec)
            fees[account_id] = float(sum(1 if t.type is TransactionType.CREDIT else 2
                                         for t in ordered[3:]))
        return fees

    def get_suspicious_accounts(self) -> list[int]:
        grouped: dict[int, list[int]] = {}
        for transaction in self.transactions:
            if transaction.type is TransactionType.DEBIT and transaction.amount >= 50:
                grouped.setdefault(transaction.account_id, []).append(transaction.timestamp_sec)
        suspicious = []
        for account_id, times in grouped.items():
            ordered = sorted(times)
            if any(ordered[i] - ordered[i - 2] <= 60 for i in range(2, len(ordered))):
                suspicious.append(account_id)
        return sorted(suspicious)

    def get_top_spending_account(self) -> int:
        spending: dict[int, float] = {}
        for transaction in self.transactions:
            if transaction.type is TransactionType.DEBIT:
                key = transaction.account_id
                spending[key] = spending.get(key, 0.0) + transaction.amount
        return min(spending, key=lambda key: (-spending[key], key)) if spending else -1

    def get_transaction_count_by_account(self) -> dict[int, int]:
        counts: dict[int, int] = {}
        for transaction in self.transactions:
            key = transaction.account_id
            counts[key] = counts.get(key, 0) + 1
        return counts
