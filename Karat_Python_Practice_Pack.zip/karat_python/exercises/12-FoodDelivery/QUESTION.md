# 12. Order Status and Restaurant Delivery Averages

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/12-FoodDelivery/FoodDeliveryProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 contains an added practice regression because the published statistics code already passes its test. The delivery tasks preserve the source requirements. This source has two stages.

Track food orders through their lifecycle and report delivery performance for each restaurant. An order may have multiple delivery records.

Example: one restaurant has deliveries lasting 30, 30, and 60 minutes across two orders. Its average is 40.0 minutes; averaging the two order averages would give an incorrect 37.5.

## Data model

- `OrderStatus`: PLACED, PREPARING, OUT_FOR_DELIVERY, DELIVERED, CANCELED.

- `Delivery`: delivery_id: int, start_minute: int, end_minute: int.

- `Order`: order_id: int, restaurant_id: int, customer_id: int, order_value: float, distance_km: float, status: OrderStatus, deliveries: list[Delivery].

- `OrderStats`: total_orders: int, active_orders: int, closed_orders: int.

- `OrderManager`: orders: list[Order].

## Stage 1: Debug order status counts

1. Read the order lifecycle and repair the failing order-statistics test.

2. Return total order count, active order count, and closed order count. PLACED, PREPARING, and OUT_FOR_DELIVERY are active; DELIVERED and CANCELED are closed.

### Python API

```python

OrderManager.get_order_statistics() -> OrderStats

```

## Stage 2: Attach deliveries and average their durations

1. Associate a Delivery with the matching order. Ignore an unknown order ID. Delivery duration is end_minute - start_minute.

2. Return a mapping from restaurant ID to the average duration of all its deliveries across all orders. Count deliveries individually, rather than averaging the per-order averages.

### Python API

```python

OrderManager.add_delivery(order_id: int, delivery: Delivery) -> None

OrderManager.get_average_delivery_time_by_restaurant() -> dict[int, float]

```

## Clarifications

- Delivery IDs are unique and times are valid within the same day, as stated by the source.

- Order IDs identify one order. No additional deduplication or status-transition validation is requested.

- Include each restaurant represented by at least one order. If it has no deliveries, return 0.0, following the Java reference solution.

- Count all attached deliveries regardless of the order's current status.
