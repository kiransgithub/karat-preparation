# Solution notes: Order Status and Restaurant Delivery Averages

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/12-FoodDelivery/FoodDeliveryProblem.txt) | [Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/12-FoodDelivery/Solution.java)

## Debugging diagnosis

The starter omits PREPARING from the active states. Include it so the original five-order example returns total=5, active=3, closed=2.

## Provenance

Stage 1 contains an added practice regression because the published statistics code already passes its test. The delivery tasks preserve the source requirements. This source has two stages.

## Source issues and conversion choices

- Both Java files already correctly include all active order statuses. The Python starter inserts an added practice regression that omits PREPARING; it is not claimed to be the original interview bug.

- The prompt leaves no-delivery restaurant behavior unspecified. The reference solution uses 0.0, so that behavior is explicitly retained.

- The source provides per-order delivery lists; Python uses a separate default_factory list for every order.

## Tests and complexity
The original five-status statistics and restaurant delivery fixtures are retained, including the ignored unknown order. Added tests check empty systems, legacy status updates, unknown IDs, restaurants with no deliveries, fractional averages, independent delivery lists, and counting deliveries without status filtering.

For n orders and d deliveries: statistics and attaching a delivery take O(n) time; delivery averages take O(n + d) time and O(r) space for r restaurants.
