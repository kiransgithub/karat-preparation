"""Python adaptation of the food-delivery exercise."""
from dataclasses import dataclass, field
from enum import Enum

class OrderStatus(Enum):
    PLACED = 'PLACED'
    PREPARING = 'PREPARING'
    OUT_FOR_DELIVERY = 'OUT_FOR_DELIVERY'
    DELIVERED = 'DELIVERED'
    CANCELED = 'CANCELED'

@dataclass
class Delivery:
    delivery_id: int
    start_minute: int
    end_minute: int

    def get_duration_minutes(self) -> int:
        return self.end_minute - self.start_minute

@dataclass
class Order:
    order_id: int
    restaurant_id: int
    customer_id: int
    order_value: float
    distance_km: float
    status: OrderStatus
    deliveries: list[Delivery] = field(default_factory=list)

@dataclass
class OrderStats:
    total_orders: int
    active_orders: int
    closed_orders: int

class OrderManager:
    def __init__(self):
        self.orders: list[Order] = []

    def add_order(self, order: Order) -> None:
        self.orders.append(order)

    def update_order_status(self, order_id: int, new_status: OrderStatus) -> None:
        for order in self.orders:
            if order.order_id == order_id:
                order.status = new_status
                return

    def get_order_statistics(self) -> OrderStats:
        active = 0
        closed = 0
        for order in self.orders:
            if order.status in (OrderStatus.PLACED, OrderStatus.PREPARING, OrderStatus.OUT_FOR_DELIVERY):
                active += 1
            elif order.status in (OrderStatus.DELIVERED, OrderStatus.CANCELED):
                closed += 1
        return OrderStats(len(self.orders), active, closed)

    def add_delivery(self, order_id: int, delivery: Delivery) -> None:
        for order in self.orders:
            if order.order_id == order_id:
                order.deliveries.append(delivery)
                return

    def get_average_delivery_time_by_restaurant(self) -> dict[int, float]:
        totals: dict[int, int] = {}
        counts: dict[int, int] = {}
        for order in self.orders:
            restaurant = order.restaurant_id
            totals.setdefault(restaurant, 0)
            counts.setdefault(restaurant, 0)
            for delivery in order.deliveries:
                totals[restaurant] += delivery.get_duration_minutes()
                counts[restaurant] += 1
        return {restaurant: totals[restaurant] / counts[restaurant] if counts[restaurant] else 0.0
                for restaurant in totals}
