import unittest

def build_suite(implementation, stage="all"):
    M = implementation
    S = M.OrderStatus

    class Stage1(unittest.TestCase):
        def test_empty_and_updates(self):
            manager = M.OrderManager()
            self.assertEqual(manager.get_order_statistics(), M.OrderStats(0, 0, 0))
            order = M.Order(1, 10, 100, 25.0, 3.2, S.PLACED)
            manager.add_order(order)
            self.assertEqual(manager.get_order_statistics(), M.OrderStats(1, 1, 0))
            manager.update_order_status(1, S.DELIVERED)
            self.assertEqual(order.status, S.DELIVERED)
            self.assertEqual(manager.get_order_statistics(), M.OrderStats(1, 0, 1))
            manager.update_order_status(999, S.CANCELED)
            self.assertEqual(order.status, S.DELIVERED)

        def test_regression(self):
            # Original five-order test.
            manager = M.OrderManager()
            rows = [(1, 10, 100, 25.0, 3.2, S.PLACED),
                    (2, 10, 101, 55.0, 1.4, S.PREPARING),
                    (3, 11, 102, 15.0, 6.0, S.OUT_FOR_DELIVERY),
                    (4, 11, 103, 40.0, 2.0, S.DELIVERED),
                    (5, 12, 104, 18.0, 4.5, S.CANCELED)]
            for row in rows:
                manager.add_order(M.Order(*row))
            self.assertEqual(manager.get_order_statistics(), M.OrderStats(5, 3, 2))

    class Stage2(unittest.TestCase):
        def test_original_delivery_averages(self):
            manager = M.OrderManager()
            for row in [(1, 10, 100, 25.0, 3.2, S.DELIVERED),
                        (2, 10, 101, 55.0, 1.4, S.DELIVERED),
                        (3, 11, 102, 15.0, 6.0, S.DELIVERED)]:
                manager.add_order(M.Order(*row))
            for order_id, data in [(1, (101, 10, 40)), (2, (102, 50, 80)),
                                   (2, (103, 90, 150)), (3, (104, 20, 50)),
                                   (999, (105, 0, 10))]:
                manager.add_delivery(order_id, M.Delivery(*data))
            averages = manager.get_average_delivery_time_by_restaurant()
            self.assertEqual(set(averages), {10, 11})
            self.assertAlmostEqual(averages[10], 40.0)
            self.assertAlmostEqual(averages[11], 30.0)
            self.assertEqual([len(o.deliveries) for o in manager.orders], [1, 2, 1])

        def test_empty_missing_and_no_deliveries(self):
            # Added tests for reference-solution behavior when a restaurant has no deliveries.
            manager = M.OrderManager()
            self.assertEqual(manager.get_average_delivery_time_by_restaurant(), {})
            manager.add_delivery(999, M.Delivery(1, 0, 10))
            self.assertEqual(manager.orders, [])
            manager.add_order(M.Order(1, 10, 1, 1.0, 1.0, S.PLACED))
            manager.add_order(M.Order(2, 20, 2, 2.0, 2.0, S.CANCELED))
            self.assertEqual(manager.get_average_delivery_time_by_restaurant(), {10: 0.0, 20: 0.0})
            manager.add_delivery(2, M.Delivery(2, 10, 11))
            manager.add_delivery(2, M.Delivery(3, 20, 22))
            self.assertEqual(manager.orders[0].deliveries, [])
            self.assertEqual(manager.get_average_delivery_time_by_restaurant(), {10: 0.0, 20: 1.5})

    groups = {'1': Stage1, '2': Stage2}
    suite = unittest.TestSuite()
    for key, case in groups.items():
        if stage == 'all' or str(stage) == key:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
