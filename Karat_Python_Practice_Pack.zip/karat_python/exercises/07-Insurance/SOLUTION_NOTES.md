# Solution notes: Insurance Claims and Status History

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/07-Insurance/InsuranceProblem.txt) | [Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/07-Insurance/Solution.java)

## Debugging diagnosis

The starter treats only APPROVED claims as resolved. Count both APPROVED and REJECTED; the nine-claim example has five resolved claims and a 55.555...% resolution rate.

## Provenance

The original bug is restored from an explicit source comment; Stage 1 wording is reconstructed from the supplied code and tests. This source has two stages.

## Source issues and conversion choices

- The problem file begins with Stage 2; the Stage 1 contract is reconstructed from its model comments and existing statistics tests.

- Both Java files already include the repaired resolved-state predicate. The commented original predicate identifies the restored starter bug.

- Java divides zero by zero for an empty claim list. The Python exercise explicitly defines an empty resolution rate of 0.0.

- The supplied status_history declaration is retained as scaffolding; Stage 2 still requires checking independent initialization and implementing the two new methods.

## Tests and complexity
The original model, nine-claim statistics, two sequential status updates, and nine-action role-count scenarios are translated. Added tests cover empty statistics, missing claims, and independent per-claim history lists.

With n claims and h history entries: statistics and ID lookup take O(n); role aggregation takes O(n + h) time and O(r) result space for r roles. Appending one history entry is amortized O(1) after lookup.
