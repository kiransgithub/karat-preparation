import unittest

def build_suite(implementation, stage="all"):
    M = implementation
    S = M.ClaimStatus
    T = M.ClaimType

    class Stage1(unittest.TestCase):
        def test_model_and_update(self):
            # Translated testClaim and the setup/update portion of testClaimsSystem.
            c = M.Claim(1, 101, T.AUTO, 2500.0, S.SUBMITTED)
            self.assertEqual((c.claim_id, c.policyholder_id, c.claim_type, c.amount, c.status),
                             (1, 101, T.AUTO, 2500.0, S.SUBMITTED))
            system = M.ClaimsSystem()
            system.add_claim(c)
            self.assertEqual(system.claims, [c])
            system.update_claim_status(1, S.UNDER_REVIEW)
            self.assertEqual(c.status, S.UNDER_REVIEW)
            system.update_claim_status(999, S.APPROVED)
            self.assertEqual(c.status, S.UNDER_REVIEW)

        def test_regression(self):
            # Original nine-claim test data.
            system = M.ClaimsSystem()
            data = [(1, 101, T.AUTO, 2500.0, S.UNDER_REVIEW),
                    (2, 102, T.HEALTH, 8400.0, S.APPROVED),
                    (3, 103, T.PROPERTY, 15000.0, S.REJECTED),
                    (4, 104, T.AUTO, 950.0, S.APPROVED),
                    (5, 105, T.HEALTH, 3200.0, S.UNDER_REVIEW),
                    (6, 106, T.PROPERTY, 22000.0, S.APPROVED),
                    (7, 107, T.AUTO, 1800.0, S.REJECTED),
                    (8, 108, T.HEALTH, 6700.0, S.SUBMITTED),
                    (9, 109, T.AUTO, 4200.0, S.UNDER_REVIEW)]
            for row in data:
                system.add_claim(M.Claim(*row))
            result = system.get_claim_statistics()
            self.assertEqual(result['total_claims'], 9)
            self.assertEqual(result['total_resolved_claims'], 5)
            self.assertAlmostEqual(result['resolution_rate'], 100 * 5 / 9)

        def test_empty(self):
            # Added clarification for an empty denominator.
            self.assertEqual(M.ClaimsSystem().get_claim_statistics(),
                             {'total_claims': 0, 'total_resolved_claims': 0, 'resolution_rate': 0.0})

    class Stage2(unittest.TestCase):
        def test_record_status_change(self):
            system = M.ClaimsSystem()
            c = M.Claim(1, 101, T.AUTO, 2500.0, S.SUBMITTED)
            system.add_claim(c)
            self.assertEqual(c.status_history, [])
            system.record_status_change(1, S.SUBMITTED, 'JUNIOR', 10)
            self.assertEqual(c.status, S.SUBMITTED)
            self.assertEqual(c.status_history, [M.StatusChange(S.SUBMITTED, 'JUNIOR', 10)])
            system.record_status_change(1, S.UNDER_REVIEW, 'SENIOR', 15)
            self.assertEqual(c.status, S.UNDER_REVIEW)
            self.assertEqual(c.status_history[1], M.StatusChange(S.UNDER_REVIEW, 'SENIOR', 15))
            self.assertEqual(len(c.status_history), 2)

        def test_role_counts(self):
            system = M.ClaimsSystem()
            for i, claim_type, amount in [(1, T.AUTO, 2500.0), (2, T.HEALTH, 8400.0),
                                          (3, T.PROPERTY, 15000.0), (4, T.AUTO, 950.0),
                                          (5, T.HEALTH, 3200.0)]:
                system.add_claim(M.Claim(i, 100 + i, claim_type, amount, S.SUBMITTED))
            changes = [(1, S.SUBMITTED, 'JUNIOR', 10), (1, S.UNDER_REVIEW, 'JUNIOR', 20),
                       (1, S.APPROVED, 'SENIOR', 30), (2, S.SUBMITTED, 'SENIOR', 40),
                       (2, S.UNDER_REVIEW, 'SENIOR', 50), (2, S.APPROVED, 'MANAGER', 60),
                       (3, S.SUBMITTED, 'JUNIOR', 70), (3, S.REJECTED, 'SENIOR', 80),
                       (4, S.SUBMITTED, 'JUNIOR', 90)]
            for change in changes:
                system.record_status_change(*change)
            self.assertEqual(system.get_status_change_counts_per_role(),
                             {'JUNIOR': 4, 'SENIOR': 4, 'MANAGER': 1})
            self.assertEqual(system.claims[-1].status_history, [])

        def test_missing_claim_and_independent_histories(self):
            # Added edge cases.
            system = M.ClaimsSystem()
            a, b = (M.Claim(i, i, T.AUTO, 1.0, S.SUBMITTED) for i in (1, 2))
            system.add_claim(a)
            system.add_claim(b)
            self.assertEqual(system.get_status_change_counts_per_role(), {})
            system.record_status_change(999, S.APPROVED, 'GHOST', 1)
            self.assertEqual(system.get_status_change_counts_per_role(), {})
            system.record_status_change(1, S.APPROVED, 'REVIEWER', 2)
            self.assertEqual(b.status_history, [])
            self.assertEqual(system.get_status_change_counts_per_role(), {'REVIEWER': 1})

    groups = {'1': Stage1, '2': Stage2}
    suite = unittest.TestSuite()
    for key, case in groups.items():
        if stage == 'all' or str(stage) == key:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
