"""Python adaptation of the insurance claims exercise; see QUESTION.md."""
from dataclasses import dataclass, field
from enum import Enum

class ClaimStatus(Enum):
    SUBMITTED = 'SUBMITTED'
    UNDER_REVIEW = 'UNDER_REVIEW'
    APPROVED = 'APPROVED'
    REJECTED = 'REJECTED'

class ClaimType(Enum):
    AUTO = 'AUTO'
    HEALTH = 'HEALTH'
    PROPERTY = 'PROPERTY'

@dataclass(frozen=True)
class StatusChange:
    new_status: ClaimStatus
    approver_role: str
    timestamp: int

@dataclass
class Claim:
    claim_id: int
    policyholder_id: int
    claim_type: ClaimType
    amount: float
    status: ClaimStatus
    status_history: list[StatusChange] = field(default_factory=list, compare=False)

class ClaimsSystem:
    def __init__(self):
        self.claims: list[Claim] = []

    def add_claim(self, claim: Claim) -> None:
        self.claims.append(claim)

    def update_claim_status(self, claim_id: int, status: ClaimStatus) -> None:
        for claim in self.claims:
            if claim.claim_id == claim_id:
                claim.status = status
                return

    def get_claim_statistics(self) -> dict[str, int | float]:
        total = len(self.claims)
        resolved = sum(c.status in (ClaimStatus.APPROVED, ClaimStatus.REJECTED) for c in self.claims)
        return {'total_claims': total,
                'total_resolved_claims': resolved,
                'resolution_rate': 100.0 * resolved / total if total else 0.0}

    def record_status_change(self, claim_id: int, new_status: ClaimStatus,
                             approver_role: str, timestamp: int) -> None:
        for claim in self.claims:
            if claim.claim_id == claim_id:
                claim.status = new_status
                claim.status_history.append(StatusChange(new_status, approver_role, timestamp))

    def get_status_change_counts_per_role(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for claim in self.claims:
            for change in claim.status_history:
                counts[change.approver_role] = counts.get(change.approver_role, 0) + 1
        return counts
