# 07. Insurance Claims and Status History

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/07-Insurance/InsuranceProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** The original bug is restored from an explicit source comment; Stage 1 wording is reconstructed from the supplied code and tests. This source has two stages.

Track claim outcomes and keep an audit history of staff decisions. Status statistics summarize all claims; history summaries count actions by approver role.

Example: nine claims with three approvals and two rejections have five resolved claims. Recording two JUNIOR actions and one SENIOR action yields {"JUNIOR": 2, "SENIOR": 1}.

## Data model

- `ClaimStatus`: SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED.

- `ClaimType`: AUTO, HEALTH, PROPERTY.

- `StatusChange`: new_status: ClaimStatus, approver_role: str, timestamp: int.

- `Claim`: claim_id: int, policyholder_id: int, claim_type: ClaimType, amount: float, status: ClaimStatus, status_history: list[StatusChange].

- `ClaimsSystem`: claims: list[Claim].

## Stage 1: Debug claim statistics

1. Read the models and existing add/update methods, then fix the failing statistics test.

2. Return total_claims, total_resolved_claims, and resolution_rate. APPROVED and REJECTED are resolved; the other states remain active. The rate is a percentage, not a fraction.

### Python API

```python

ClaimsSystem.get_claim_statistics() -> dict[str, int | float]

```

## Stage 2: Record status history and summarize approvers

1. Ensure each claim starts with its own empty status_history list. Its data-model field is supplied in the scaffold.

2. record_status_change updates the matching claim status and appends a StatusChange containing the new status, role, and integer-hour timestamp. Even recording the current status adds a history entry.

3. get_status_change_counts_per_role counts all history entries across all claims by role; omit roles with no changes and return an empty dictionary when no changes exist.

### Python API

```python

ClaimsSystem.record_status_change(claim_id: int, new_status: ClaimStatus, approver_role: str, timestamp: int) -> None

ClaimsSystem.get_status_change_counts_per_role() -> dict[str, int]

```

## Clarifications

- For zero claims, return a resolution_rate of 0.0; the original prompt does not define the empty denominator.

- Claim IDs are assumed unique in normal input. A missing ID is ignored, matching the Java search behavior.

- update_claim_status is the legacy update without history; record_status_change is the new operation that records history.

- No transition validation or timestamp sorting is required. Record history in call order.
