import unittest

def build_suite(M, stage="all"):
    A=M.AppointmentStatus
    V=M.VisitType

    class Stage1(unittest.TestCase):
        def test_source_regression(self):
            clinic=M.ClinicManager()
            for ident,duration,status in [(1,30,A.COMPLETED),(2,45,A.COMPLETED),(3,30,A.NO_SHOW),
                                           (4,60,A.CANCELLED),(5,30,A.SCHEDULED)]:
                clinic.add_appointment(M.Appointment(ident,10,99+ident,duration,status))
            stats=clinic.get_appointment_statistics()
            self.assertEqual(stats.total_appointments,5)
            self.assertEqual(stats.completed_appointments,2)
            self.assertAlmostEqual(stats.no_show_rate,0.2)

        def test_empty_and_all_no_shows(self):
            clinic=M.ClinicManager()
            self.assertEqual(clinic.get_appointment_statistics(),M.AppointmentStats(0,0,0.0))
            clinic.add_appointment(M.Appointment(1,10,100,30,A.NO_SHOW))
            self.assertEqual(clinic.get_appointment_statistics(),M.AppointmentStats(1,0,1.0))

    class Stage2(unittest.TestCase):
        def test_source_visit_storage(self):
            clinic=M.ClinicManager()
            clinic.add_doctor(M.Doctor(1,'dr_smith'))
            clinic.add_doctor(M.Doctor(2,'dr_jones'))
            for visit in [M.PatientVisit(1,100,1,540,30,V.CONSULTATION),
                          M.PatientVisit(2,101,2,600,45,V.FOLLOWUP),
                          M.PatientVisit(3,102,99,660,30,V.EMERGENCY)]:
                clinic.add_patient_visit(visit)
            self.assertEqual([v.visit_id for v in clinic.visits],[1,2])

        def test_source_average_types(self):
            clinic=M.ClinicManager()
            for doctor in [M.Doctor(1,'Smith'),M.Doctor(2,'Jones'),M.Doctor(3,'Brown')]:
                clinic.add_doctor(doctor)
            for row in [(1,100,1,540,30,V.CONSULTATION),(2,101,1,600,50,V.CONSULTATION),
                        (3,102,1,660,20,V.FOLLOWUP),(4,103,2,540,40,V.EMERGENCY)]:
                clinic.add_patient_visit(M.PatientVisit(*row))
            self.assertEqual(clinic.get_average_visit_duration_by_type(1),{V.CONSULTATION:40.0,V.FOLLOWUP:20.0})
            self.assertEqual(clinic.get_average_visit_duration_by_type(2),{V.EMERGENCY:40.0})
            self.assertEqual(clinic.get_average_visit_duration_by_type(3),{})
            self.assertEqual(clinic.get_average_visit_duration_by_type(999),{})

        def test_fractional_average(self):
            clinic=M.ClinicManager()
            clinic.add_doctor(M.Doctor(1,'A'))
            for i,duration in enumerate([1,2],1):
                clinic.add_patient_visit(M.PatientVisit(i,i,1,0,duration,V.FOLLOWUP))
            self.assertEqual(clinic.get_average_visit_duration_by_type(1),{V.FOLLOWUP:1.5})

    groups={'1':Stage1,'2':Stage2}
    selected=list(groups.values()) if stage=='all' else [groups[str(stage)]]
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in selected)
