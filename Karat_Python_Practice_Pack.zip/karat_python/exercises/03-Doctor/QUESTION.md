# 03. Clinic Appointments and Patient Visits

Summarize appointment outcomes and calculate each doctor's average visit duration by visit type.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/03-Doctor/DoctorProblem.txt).

Provenance: the published starter is already correct for Stage 1. This version introduces an added practice regression while preserving the source expected behavior. The source has two stages; no third-stage requirement is invented.

## Data model

- `AppointmentStatus`: Enum: SCHEDULED, COMPLETED, CANCELLED, NO_SHOW
- `VisitType`: Enum: CONSULTATION, FOLLOWUP, EMERGENCY
- `Doctor`: doctor_id: int, name: str
- `Appointment`: appointment_id: int, doctor_id: int, patient_id: int, duration_minutes: int, status: AppointmentStatus
- `PatientVisit`: visit_id: int, patient_id: int, doctor_id: int, start_time: int, duration_minutes: int, visit_type: VisitType
- `AppointmentStats`: total_appointments: int, completed_appointments: int, no_show_rate: float (fraction)

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug appointment statistics

- Read the manager and fix the supplied statistics regression. Count every appointment in the total, count COMPLETED records separately, and report NO_SHOW records divided by total appointments.
- For no appointments return total=0, completed=0, no_show_rate=0.0. The rate is a fraction, not a percentage.

Python methods:

```python
get_appointment_statistics() -> AppointmentStats
```

## Stage 2: Store visits and average by type

- add_patient_visit stores the visit only if its doctor_id is registered; ignore unknown doctors.
- For the requested doctor, return a dictionary from each observed VisitType to mean duration_minutes. Omit absent types and return {} when the doctor has no visits.

Python methods:

```python
add_patient_visit(patient_visit: PatientVisit) -> None
get_average_visit_duration_by_type(doctor_id: int) -> dict[VisitType, float]
```

## Examples

Two COMPLETED, one NO_SHOW, one CANCELLED, and one SCHEDULED appointment produce (5, 2, 0.2). CONSULTATION visits lasting 30 and 50 minutes for one doctor average 40 minutes.

## Clarifications

- start_time uses minutes since the start of the day. Durations are nonnegative and enums valid.
- Appointment statistics cover all stored appointments; add_appointment does not validate doctor IDs, matching the source.
- An unknown doctor produces an empty visit-average dictionary because unknown-doctor visits cannot be stored.
- Doctors are keyed by ID; registering an existing ID replaces the doctor object.
