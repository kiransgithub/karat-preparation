# Clinic Appointments and Patient Visits: solution notes

## Stage 1

Integer division loses the fractional no-show rate. Use no_shows / total when total is nonzero; preserve the zero-appointment branch.

Provenance: Added practice regression because the source starter already passes its statistics test.

## Source corrections and adaptation decisions

- The published question already computes statistics correctly; the Python starter therefore contains an added practice regression, not a recovered historical bug.
- The added regression replaces real division with integer division, which the source fractional-rate test detects.
- The source question omits visit-method definitions and comments out average tests. Explicit stubs and active translated tests restore the described tasks.
- The source addPatientVisit test contains no assertions; Python adds storage and exclusion assertions for the same supplied records.

## Tests

Retained the five-appointment statistics example and all visit records in the source storage/average tests, including originally commented-out tests. Added explicit checks for rejected unknown-doctor records, empty and unknown doctors, empty statistics, all-no-show statistics, and fractional averages.

## Complexity

Appointment statistics take O(A) time and O(1) extra space for A appointments. Visit insertion is expected O(1). A doctor's grouped averages take O(V) time over V visits and O(K) space for observed visit types; K is at most three.

## Source

[Question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/03-Doctor/DoctorProblem.txt) | [Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/03-Doctor/Solution.java)
