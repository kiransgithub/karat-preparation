from dataclasses import dataclass
from enum import Enum

class AppointmentStatus(Enum):
    SCHEDULED='SCHEDULED'
    COMPLETED='COMPLETED'
    CANCELLED='CANCELLED'
    NO_SHOW='NO_SHOW'

class VisitType(Enum):
    CONSULTATION='CONSULTATION'
    FOLLOWUP='FOLLOWUP'
    EMERGENCY='EMERGENCY'

@dataclass
class Doctor:
    doctor_id: int
    name: str

@dataclass
class Appointment:
    appointment_id: int
    doctor_id: int
    patient_id: int
    duration_minutes: int
    status: AppointmentStatus

@dataclass
class PatientVisit:
    visit_id: int
    patient_id: int
    doctor_id: int
    start_time: int
    duration_minutes: int
    visit_type: VisitType

@dataclass
class AppointmentStats:
    total_appointments: int
    completed_appointments: int
    no_show_rate: float

class ClinicManager:
    def __init__(self):
        self.doctors: dict[int, Doctor] = {}
        self.appointments: list[Appointment] = []
        self.visits: list[PatientVisit] = []

    def add_doctor(self, doctor: Doctor) -> None:
        self.doctors[doctor.doctor_id] = doctor

    def add_appointment(self, appointment: Appointment) -> None:
        self.appointments.append(appointment)

    def get_appointment_statistics(self) -> AppointmentStats:
        total = len(self.appointments)
        completed = sum(a.status is AppointmentStatus.COMPLETED for a in self.appointments)
        no_shows = sum(a.status is AppointmentStatus.NO_SHOW for a in self.appointments)
        rate = no_shows / total if total else 0.0
        return AppointmentStats(total, completed, rate)

    def add_patient_visit(self, patient_visit: PatientVisit) -> None:
        if patient_visit.doctor_id in self.doctors:
            self.visits.append(patient_visit)

    def get_average_visit_duration_by_type(self, doctor_id: int) -> dict[VisitType, float]:
        totals: dict[VisitType, int] = {}
        counts: dict[VisitType, int] = {}
        for visit in self.visits:
            if visit.doctor_id == doctor_id:
                key = visit.visit_type
                totals[key] = totals.get(key, 0) + visit.duration_minutes
                counts[key] = counts.get(key, 0) + 1
        return {kind: total / counts[kind] for kind, total in totals.items()}
