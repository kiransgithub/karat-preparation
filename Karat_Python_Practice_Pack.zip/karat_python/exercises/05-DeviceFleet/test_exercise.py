import unittest

def build_suite(M, stage="all"):
    def device(ident='D-1',kind='SENSOR',status='ACTIVE',day=10):
        return M.Device(ident,kind,'WAREHOUSE-A',status,day,50,1)

    class Stage1(unittest.TestCase):
        def test_source_valid_transitions(self):
            for old,new in [('ACTIVE','SUSPENDED'),('MAINTENANCE_DUE','ACTIVE'),
                            ('REGISTERED','RETIRED'),('SUSPENDED','ACTIVE')]:
                m=M.DeviceLifecycleManager()
                m.devices['D-1']=device(status=old)
                self.assertTrue(m.update_device_status('D-1',new))
                self.assertEqual(m.devices['D-1'].status,new)

        def test_source_regression(self):
            for old,new in [('ACTIVE','REGISTERED'),('RETIRED','ACTIVE'),('ACTIVE','ACTIVE')]:
                m=M.DeviceLifecycleManager()
                m.devices['D-1']=device(status=old)
                self.assertFalse(m.update_device_status('D-1',new))
                self.assertEqual(m.devices['D-1'].status,old)

        def test_source_unknown_device_and_status(self):
            m=M.DeviceLifecycleManager()
            self.assertFalse(m.update_device_status('UNKNOWN','ACTIVE'))
            m.devices['D-1']=device()
            self.assertFalse(m.update_device_status('D-1','BROKEN'))
            self.assertEqual(m.devices['D-1'].status,'ACTIVE')

    class Stage2(unittest.TestCase):
        def test_source_add_device_and_duplicate(self):
            m=M.DeviceLifecycleManager()
            first=device(status='REGISTERED')
            self.assertTrue(m.add_device(first))
            self.assertIs(m.devices['D-1'],first)
            self.assertFalse(m.add_device(device(kind='CAMERA',day=20)))
            self.assertIs(m.devices['D-1'],first)

        def test_source_invalid_fields_and_day_boundary(self):
            m=M.DeviceLifecycleManager()
            for item in [device(kind='THERMOSTAT'),device(status='BROKEN'),device(day=-1)]:
                self.assertFalse(m.add_device(item))
                self.assertEqual(m.devices,{})
            self.assertTrue(m.add_device(device(day=0)))

        def test_source_active_counts(self):
            m=M.DeviceLifecycleManager()
            for item in [device('D-1'),device('D-2'),device('D-3','CAMERA','SUSPENDED'),
                         device('D-4','GATEWAY'),device('D-5','CAMERA','REGISTERED')]:
                m.devices[item.device_id]=item
            self.assertEqual(m.get_active_device_counts_by_type(),{'SENSOR':2,'GATEWAY':1})
            m=M.DeviceLifecycleManager()
            m.devices['D-1']=device(status='SUSPENDED')
            self.assertEqual(m.get_active_device_counts_by_type(),{})

        def test_empty_and_counts_after_transition(self):
            # Added: counts reflect the current status rather than insertion-time status.
            m=M.DeviceLifecycleManager()
            self.assertEqual(m.get_active_device_counts_by_type(),{})
            m.add_device(device(status='REGISTERED'))
            self.assertTrue(m.update_device_status('D-1','ACTIVE'))
            self.assertEqual(m.get_active_device_counts_by_type(),{'SENSOR':1})
            self.assertTrue(m.update_device_status('D-1','RETIRED'))
            self.assertEqual(m.get_active_device_counts_by_type(),{})

    groups={'1':Stage1,'2':Stage2}
    selected=list(groups.values()) if stage=='all' else [groups[str(stage)]]
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in selected)
