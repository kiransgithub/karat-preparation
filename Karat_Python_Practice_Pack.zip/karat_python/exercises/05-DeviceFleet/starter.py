from dataclasses import dataclass

@dataclass
class Device:
    device_id: str
    device_type: str
    location: str
    status: str
    registered_day: int
    next_maintenance_day: int
    failure_count: int

@dataclass
class ReplacementEntry:
    device_id: str
    failure_count: int
    age_days: int

class DeviceLifecycleManager:
    SUPPORTED_DEVICE_TYPES = frozenset({'SENSOR','CAMERA','GATEWAY'})
    VALID_STATUSES = frozenset({'REGISTERED','ACTIVE','SUSPENDED','MAINTENANCE_DUE','RETIRED'})
    VALID_TRANSITIONS = {
        'REGISTERED': frozenset({'ACTIVE','RETIRED'}),
        'ACTIVE': frozenset({'SUSPENDED','MAINTENANCE_DUE','RETIRED'}),
        'SUSPENDED': frozenset({'ACTIVE','RETIRED'}),
        'MAINTENANCE_DUE': frozenset({'ACTIVE','RETIRED'}),
        'RETIRED': frozenset(),
    }

    def __init__(self):
        self.devices: dict[str, Device] = {}

    def update_device_status(self, device_id: str, new_status: str) -> bool:
        device = self.devices.get(device_id)
        if device is None or new_status not in self.VALID_STATUSES:
            return False
        device.status = new_status
        return True

    def add_device(self, device: Device) -> bool:
        raise NotImplementedError("Implement Stage 2.")

    def get_active_device_counts_by_type(self) -> dict[str, int]:
        raise NotImplementedError("Implement Stage 2.")
