from dataclasses import dataclass

@dataclass
class Device:
    device_id: str
    device_type: str
    location: str
    status: str
    registered_day: int
    next_maintenance_day: int
    failure_count: int

@dataclass
class ReplacementEntry:
    device_id: str
    failure_count: int
    age_days: int

class DeviceLifecycleManager:
    SUPPORTED_DEVICE_TYPES = frozenset({'SENSOR','CAMERA','GATEWAY'})
    VALID_STATUSES = frozenset({'REGISTERED','ACTIVE','SUSPENDED','MAINTENANCE_DUE','RETIRED'})
    VALID_TRANSITIONS = {
        'REGISTERED': frozenset({'ACTIVE','RETIRED'}),
        'ACTIVE': frozenset({'SUSPENDED','MAINTENANCE_DUE','RETIRED'}),
        'SUSPENDED': frozenset({'ACTIVE','RETIRED'}),
        'MAINTENANCE_DUE': frozenset({'ACTIVE','RETIRED'}),
        'RETIRED': frozenset(),
    }

    def __init__(self):
        self.devices: dict[str, Device] = {}

    def update_device_status(self, device_id: str, new_status: str) -> bool:
        device = self.devices.get(device_id)
        if device is None or new_status not in self.VALID_STATUSES:
            return False
        if new_status not in self.VALID_TRANSITIONS.get(device.status, frozenset()):
            return False
        device.status = new_status
        return True

    def add_device(self, device: Device) -> bool:
        if (device.device_id in self.devices or device.status not in self.VALID_STATUSES or
                device.device_type not in self.SUPPORTED_DEVICE_TYPES or device.registered_day < 0):
            return False
        self.devices[device.device_id] = device
        return True

    def get_active_device_counts_by_type(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for device in self.devices.values():
            if device.status == 'ACTIVE':
                counts[device.device_type] = counts.get(device.device_type, 0) + 1
        return counts
