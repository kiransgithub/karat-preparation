# 05. Device Fleet Lifecycle

Enforce device status transitions, validate registrations, and count active devices by type.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/05-DeviceFleet/DevicefleetProblem.txt).

Provenance: the source status-update implementation is already corrected. Stage 1 therefore contains an added practice regression based on its existing tests. Stage 2 follows the published task text; there is no source Stage 3.

## Data model

- `Device`: device_id: str, device_type: str, location: str, status: str, registered_day: int, next_maintenance_day: int, failure_count: int
- `ReplacementEntry`: device_id: str, failure_count: int, age_days: int; present in source but unused by these tasks

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug status transitions

- update_device_status must return True and mutate status only when the device exists and the requested transition is allowed. Invalid requests return False without changing state.
- Allowed transitions: REGISTERED -> ACTIVE or RETIRED; ACTIVE -> SUSPENDED, MAINTENANCE_DUE, or RETIRED; SUSPENDED -> ACTIVE or RETIRED; MAINTENANCE_DUE -> ACTIVE or RETIRED; RETIRED -> none.
- Same-status updates are not allowed. Unknown status strings and unknown device IDs must be rejected.

Python methods:

```python
update_device_status(device_id: str, new_status: str) -> bool
```

## Stage 2: Register devices and count active types

- add_device accepts a device only if its ID is unused, its status is valid, its type is SENSOR, CAMERA, or GATEWAY, and registered_day >= 0. Return True on insertion; otherwise False, preserving all existing records.
- get_active_device_counts_by_type maps each device type to its ACTIVE-device count. Omit types with no ACTIVE devices and return {} for an empty qualifying set.

Python methods:

```python
add_device(device: Device) -> bool
get_active_device_counts_by_type() -> dict[str, int]
```

## Examples

ACTIVE -> SUSPENDED succeeds, but ACTIVE -> REGISTERED fails without changing the device. Two ACTIVE SENSOR devices and one ACTIVE GATEWAY produce {"SENSOR": 2, "GATEWAY": 1}.

## Clarifications

- Status and type strings are case-sensitive. The five valid statuses are REGISTERED, ACTIVE, SUSPENDED, MAINTENANCE_DUE, RETIRED.
- No validation of location, failure_count, or next_maintenance_day is requested. Registration may start in any valid status.
- The published source only supplies Stage 2 narrative. Stage 1 behavior is reconstructed from its existing method and three status-update tests.
- ReplacementEntry is retained for model completeness; no replacement-planning question exists in the supplied files.
