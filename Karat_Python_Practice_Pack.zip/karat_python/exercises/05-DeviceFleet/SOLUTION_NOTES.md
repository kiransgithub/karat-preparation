# Device Fleet Lifecycle: solution notes

## Stage 1

A recognized status is not necessarily an allowed destination. Check VALID_TRANSITIONS for the current status before assigning the new status.

Provenance: Added practice regression derived from the source invalid-transition tests; published starter is already fixed.

## Source corrections and adaptation decisions

- The source status-update code already checks the transition table and passes its tests. The Python starter introduces an added practice regression that omits transition validation.
- The existing valid-status check remains so the regression is confined to disallowed transitions between otherwise recognized states.
- Removed diagnostic printing and preserved the unused ReplacementEntry data model without inventing a new task.

## Tests

Retained all source transition cases (valid, disallowed, retired, same-status, unknown device, invalid status), registration validations and day-zero boundary, and active-count cases. Added empty-fleet and count-after-transition checks. Tests use the same device categories and state distinctions; descriptive fixture fields are shortened where they do not affect behavior.

## Complexity

Registration and status updates take expected O(1) time using dictionaries and sets. Counting takes O(D) time for D devices, with O(T) output space for T supported types (at most three).

## Source

[Question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/05-DeviceFleet/DevicefleetProblem.txt) | [Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/05-DeviceFleet/Solution.java)
