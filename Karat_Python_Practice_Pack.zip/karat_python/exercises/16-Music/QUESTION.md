# 16. Music Analytics, Duplicate Groups, and Playlist Rules

Compute listener statistics, identify duplicate catalog entries, and evaluate playlist rules. This later music variant includes a playlist task reconstructed from the source tests and implementation.

## Data model

- **Song**: `song_id: int, title: str, artist: str, duration_seconds: int, description: str | None = None, album: str | None = None, release_year: int | None = None, genre: str | None = None`
- **PlayEvent**: `play_id: int, user_id: int, song_id: int, listened_seconds: int, timestamp: int`
- **ListenerStats**: `total_plays: int, unique_songs: int, completion_rate: float`
- **DedupResult**: `song_id: int, merged_ids: list[int]`
- **Rule**: `type: str, max_seconds: int = 0, artist: str | None = None, max_count: int = 0`
- **Playlist**: `playlist_id: int, owner_user_id: int, song_ids: list[int], rules: list[Rule]`

## Stage 1: Repair listener statistics

- Read MusicLibrary and repair its failed statistics test.
- For the requested user, count all play events and all distinct song IDs, including skipped plays. A play is completed when listened_seconds is at least the song duration. Return completed plays / total plays, or 0.0 if there are no plays.

Python methods:

- `get_listener_stats(user_id: int) -> ListenerStats`

## Stage 2: Identify catalog duplicates

- Group songs with matching title and artist ignoring case, and exactly equal duration_seconds. Song IDs are unique.
- For every group with more than one song, keep the smallest song ID and return the other IDs in ascending order as merged_ids. Sort the DedupResult list by retained song ID.
- Identify groups only: do not remove catalog entries or rewrite play events. Return [] when no duplicate group exists.

Python methods:

- `find_duplicate_groups() -> list[DedupResult]`

## Stage 3: Validate playlist rules (reconstructed from source tests)

- For MAX_DURATION, report a violation when the sum of playlist song durations exceeds max_seconds.
- For MAX_PER_ARTIST, report a violation when occurrences of the specified artist exceed max_count.
- Return the names of violated rules in their input order. A missing playlist or a playlist without rules returns []. Evaluate each rule independently.

Python methods:

- `validate_playlist(playlist_id: int) -> list[str]`

## Examples

- Four plays of three distinct songs, with two completed plays, produce `ListenerStats(4, 3, 0.5)`.
- Songs 9, 2, and 7 with the same normalized title, artist, and duration produce `DedupResult(2, [7, 9])`.
- A playlist totaling 700 seconds with a 500-second limit reports `"MAX_DURATION"`.

## Clarifications

- Stage 3 has no standalone prose statement in the repository. Its contract is derived from testPlaylistValidation, the Rule/Playlist models, and the supplied Java implementation.
- Play events refer to known songs. Song IDs are unique. Deduplication ignores description, album, release_year, and genre; title and artist comparisons use Python casefold().
- Playlist artist rules use exact case-sensitive matching, consistent with the Java implementation. Repeated song IDs count as repeated occurrences.
- Unknown song IDs in a playlist are skipped, matching the supplied Java answer. Only MAX_DURATION and MAX_PER_ARTIST rules are in scope.
- The Python Rule dataclass replaces Java overloads: Rule("MAX_DURATION", max_seconds=500) or Rule("MAX_PER_ARTIST", artist="Artist A", max_count=1).

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/16-Music/MusicProblem.txt)
