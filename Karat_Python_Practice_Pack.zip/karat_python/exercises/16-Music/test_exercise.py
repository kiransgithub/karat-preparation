import unittest

def build_suite(implementation, stage='all'):
    M = implementation
    def catalog():
        lib = M.MusicLibrary()
        for sid,artist,duration,genre in [(1,'Artist A',100,'rock'),(2,'Artist A',200,'rock'),(3,'Artist B',150,'rock'),(4,'Artist B',250,'jazz'),(5,'Artist C',300,'jazz'),(6,'Artist C',100,'pop')]:
            lib.add_song(M.Song(sid,f'T{sid}',artist,duration,genre=genre))
        return lib

    class Stage1(unittest.TestCase):
        def test_source_statistics_regression(self):
            lib = M.MusicLibrary()
            for sid,title,artist,duration in [(101,'Song A','Artist 1',180),(102,'Song B','Artist 2',200),(103,'Song C','Artist 1',240)]:
                lib.add_song(M.Song(sid,title,artist,duration))
            for values in [(1,1,101,180,1000),(2,1,102,220,1100),(3,1,101,50,1200),(4,1,103,100,1300),(5,2,102,200,2000),(6,2,103,250,2100)]:
                lib.add_play_event(M.PlayEvent(*values))
            self.assertEqual(lib.get_listener_stats(1),M.ListenerStats(4,3,0.5))
            self.assertEqual(lib.get_listener_stats(2),M.ListenerStats(2,2,1.0))
            self.assertEqual(lib.get_listener_stats(3),M.ListenerStats(0,0,0.0))

        # Added isolated edges for empty and skipped-only histories.
        def test_empty(self):
            self.assertEqual(M.MusicLibrary().get_listener_stats(1),M.ListenerStats(0,0,0.0))

        def test_skipped_play_still_counts(self):
            lib = catalog()
            lib.add_play_event(M.PlayEvent(1,7,1,10,0))
            self.assertEqual(lib.get_listener_stats(7),M.ListenerStats(1,1,0.0))

    class Stage2(unittest.TestCase):
        def test_source_duplicate_groups(self):
            lib = M.MusicLibrary()
            rows = [M.Song(1,'Song A','Artist 1',180,genre='rock'),
                    M.Song(2,'song a','ARTIST 1',180,'Studio version','First Album',None,'rock'),
                    M.Song(3,'SONG A','artist 1',180,'Live','Live Album'),
                    M.Song(10,'Song B','Artist 2',200,album='B Album'),
                    M.Song(11,'SONG B','Artist 2',200,'some description',genre='pop'),
                    M.Song(20,'Song C','Artist 3',240),M.Song(21,'song c','Artist 3',240),
                    M.Song(99,'Only Song','Solo Artist',300)]
            for song in rows:
                lib.add_song(song)
            self.assertEqual(lib.find_duplicate_groups(),[M.DedupResult(1,[2,3]),M.DedupResult(10,[11]),M.DedupResult(20,[21])])

        # Added regressions for incorrect sorting and persistent grouping state in the Java answer.
        def test_repeated_calls_and_scrambled_ids(self):
            lib = M.MusicLibrary()
            for sid in [9,2,7]:
                lib.add_song(M.Song(sid,'A','B',100))
            expected = [M.DedupResult(2,[7,9])]
            self.assertEqual(lib.find_duplicate_groups(),expected)
            self.assertEqual(lib.find_duplicate_groups(),expected)
            self.assertEqual(len(lib.songs),3)

        # Added boundaries: duration distinguishes groups and tuple keys cannot collide on spaces.
        def test_distinct_keys_and_empty(self):
            lib = M.MusicLibrary()
            for song in [M.Song(1,'A B','C',10),M.Song(2,'A','B C',10),M.Song(3,'A B','C',11)]:
                lib.add_song(song)
            self.assertEqual(lib.find_duplicate_groups(),[])
            self.assertEqual(M.MusicLibrary().find_duplicate_groups(),[])

    class Stage3(unittest.TestCase):
        def test_source_playlist_validation(self):
            lib = catalog()
            lib.add_playlist(M.Playlist(100,1,[1,3,5,4],[M.Rule('MAX_DURATION',max_seconds=1000),M.Rule('MAX_PER_ARTIST',artist='Artist B',max_count=2)]))
            lib.add_playlist(M.Playlist(200,2,[1,2,5,6],[M.Rule('MAX_DURATION',max_seconds=1000),M.Rule('MAX_PER_ARTIST',artist='Artist A',max_count=1)]))
            lib.add_playlist(M.Playlist(300,3,[2,4,5],[M.Rule('MAX_DURATION',max_seconds=500)]))
            lib.add_playlist(M.Playlist(400,4,[1,2,3],[]))
            lib.add_playlist(M.Playlist(600,6,[1,2,5,6],[M.Rule('MAX_DURATION',max_seconds=500),M.Rule('MAX_PER_ARTIST',artist='Artist A',max_count=1)]))
            self.assertEqual(lib.validate_playlist(100),[])
            self.assertEqual(lib.validate_playlist(200),['MAX_PER_ARTIST'])
            self.assertEqual(lib.validate_playlist(300),['MAX_DURATION'])
            self.assertEqual(lib.validate_playlist(400),[])
            self.assertEqual(lib.validate_playlist(999),[])
            self.assertEqual(lib.validate_playlist(600),['MAX_DURATION','MAX_PER_ARTIST'])

        # Added regression: limits are inclusive, and independent rules cannot share counters.
        def test_repeated_rule_types_and_exact_limits(self):
            lib = catalog()
            lib.add_playlist(M.Playlist(1,1,[1,2,3],[M.Rule('MAX_DURATION',max_seconds=450),M.Rule('MAX_DURATION',max_seconds=450),M.Rule('MAX_PER_ARTIST',artist='Artist A',max_count=2),M.Rule('MAX_PER_ARTIST',artist='Artist B',max_count=1)]))
            self.assertEqual(lib.validate_playlist(1),[])

        # Added clarification checks: repeated occurrences, unknown IDs, and exact artist spelling.
        def test_playlist_occurrences_and_unknown_ids(self):
            lib = catalog()
            lib.add_playlist(M.Playlist(1,1,[1,1,999],[M.Rule('MAX_DURATION',max_seconds=200),M.Rule('MAX_PER_ARTIST',artist='Artist A',max_count=1),M.Rule('MAX_PER_ARTIST',artist='artist a',max_count=0)]))
            self.assertEqual(lib.validate_playlist(1),['MAX_PER_ARTIST'])

    classes = {'1': Stage1, '2': Stage2, '3': Stage3}
    chosen = classes if stage == "all" else {str(stage): classes[str(stage)]}
    suite = unittest.TestSuite()
    for case in chosen.values():
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
