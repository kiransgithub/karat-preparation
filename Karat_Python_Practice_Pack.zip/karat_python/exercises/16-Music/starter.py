from dataclasses import dataclass

@dataclass
class Song:
    song_id: int
    title: str
    artist: str
    duration_seconds: int
    description: str | None = None
    album: str | None = None
    release_year: int | None = None
    genre: str | None = None

@dataclass
class PlayEvent:
    play_id: int
    user_id: int
    song_id: int
    listened_seconds: int
    timestamp: int

@dataclass
class ListenerStats:
    total_plays: int
    unique_songs: int
    completion_rate: float

@dataclass
class DedupResult:
    song_id: int
    merged_ids: list[int]

@dataclass
class Rule:
    type: str
    max_seconds: int = 0
    artist: str | None = None
    max_count: int = 0

@dataclass
class Playlist:
    playlist_id: int
    owner_user_id: int
    song_ids: list[int]
    rules: list[Rule]

class MusicLibrary:
    def __init__(self):
        self.songs: dict[int, Song] = {}
        self.play_events: list[PlayEvent] = []
        self.playlists: dict[int, Playlist] = {}

    def add_song(self, song: Song) -> None:
        self.songs[song.song_id] = song

    def add_play_event(self, event: PlayEvent) -> None:
        self.play_events.append(event)

    def add_playlist(self, playlist: Playlist) -> None:
        self.playlists[playlist.playlist_id] = playlist

    def is_completed(self, event: PlayEvent) -> bool:
        return event.listened_seconds > self.songs[event.song_id].duration_seconds

    def get_listener_stats(self, user_id: int) -> ListenerStats:
        events = [e for e in self.play_events if e.user_id == user_id]
        total = len(events)
        completed = sum(self.is_completed(e) for e in events)
        unique = len({e.song_id for e in events})
        return ListenerStats(total, unique, completed / total if total else 0.0)

    def find_duplicate_groups(self) -> list[DedupResult]:
        raise NotImplementedError("Implement this stage.")

    def validate_playlist(self, playlist_id: int) -> list[str]:
        raise NotImplementedError("Implement this stage.")
