# 16. Solution notes

## Debugging task

Added practice regression at the documented completion boundary; the source Stage 1 code itself is already corrected.

The starter treats a listen exactly equal to the song duration as skipped. Completion requires listened_seconds >= duration_seconds.

## Source adjustments

- The checked-in Stage 1 implementation is already fixed. The starter adds a practice boundary fault (> instead of >=) detected by the original statistics scenario.
- The Java deduplication answer stores grouping state across calls, does not apply its attempted sort, and uses a space-concatenated key that can collide. Python uses a fresh tuple-keyed dictionary and explicit sorting.
- The Java playlist answer accumulates counters across multiple rules of the same type. Python evaluates each rule with independent totals.
- Stage 3 wording is reconstructed from tests and code because the source omits its prose prompt. No additional rule types are added.

## Verification and complexity
All three original named scenarios are preserved: listener statistics, three duplicate groups, and playlist validation. Added tests target repeated deduplication calls, reverse ID order, compound-key collisions, duration differences, independent repeated rules, exact limits, and the source's playlist handling of missing songs.

For E play events, listener statistics take O(E) time and O(E) temporary space. With S songs, duplicate grouping and sorting take O(S log S) worst-case time and O(S) space. For K playlist entries and R rules, validation takes O(KR) time and O(K + R) space. Querying duplicates does not mutate the catalog.

[Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/16-Music/Solution.java)
