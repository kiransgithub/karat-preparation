from dataclasses import dataclass

@dataclass
class Song:
    song_id: int
    title: str
    artist: str
    duration_seconds: int
    description: str | None = None
    album: str | None = None
    release_year: int | None = None
    genre: str | None = None

@dataclass
class PlayEvent:
    play_id: int
    user_id: int
    song_id: int
    listened_seconds: int
    timestamp: int

@dataclass
class ListenerStats:
    total_plays: int
    unique_songs: int
    completion_rate: float

@dataclass
class DedupResult:
    song_id: int
    merged_ids: list[int]

@dataclass
class Rule:
    type: str
    max_seconds: int = 0
    artist: str | None = None
    max_count: int = 0

@dataclass
class Playlist:
    playlist_id: int
    owner_user_id: int
    song_ids: list[int]
    rules: list[Rule]

class MusicLibrary:
    def __init__(self):
        self.songs: dict[int, Song] = {}
        self.play_events: list[PlayEvent] = []
        self.playlists: dict[int, Playlist] = {}

    def add_song(self, song: Song) -> None:
        self.songs[song.song_id] = song

    def add_play_event(self, event: PlayEvent) -> None:
        self.play_events.append(event)

    def add_playlist(self, playlist: Playlist) -> None:
        self.playlists[playlist.playlist_id] = playlist

    def is_completed(self, event: PlayEvent) -> bool:
        return event.listened_seconds >= self.songs[event.song_id].duration_seconds

    def get_listener_stats(self, user_id: int) -> ListenerStats:
        events = [e for e in self.play_events if e.user_id == user_id]
        total = len(events)
        completed = sum(self.is_completed(e) for e in events)
        unique = len({e.song_id for e in events})
        return ListenerStats(total, unique, completed / total if total else 0.0)

    def find_duplicate_groups(self) -> list[DedupResult]:
        groups: dict[tuple[str, str, int], list[int]] = {}
        for song in self.songs.values():
            key = (song.title.casefold(), song.artist.casefold(), song.duration_seconds)
            groups.setdefault(key, []).append(song.song_id)
        result = []
        for ids in groups.values():
            if len(ids) > 1:
                ordered = sorted(ids)
                result.append(DedupResult(ordered[0], ordered[1:]))
        return sorted(result, key=lambda row: row.song_id)

    def validate_playlist(self, playlist_id: int) -> list[str]:
        playlist = self.playlists.get(playlist_id)
        if playlist is None:
            return []
        songs = [self.songs[sid] for sid in playlist.song_ids if sid in self.songs]
        result = []
        for rule in playlist.rules:
            if rule.type == 'MAX_DURATION':
                if sum(song.duration_seconds for song in songs) > rule.max_seconds:
                    result.append(rule.type)
            elif rule.type == 'MAX_PER_ARTIST':
                if sum(song.artist == rule.artist for song in songs) > rule.max_count:
                    result.append(rule.type)
        return result
