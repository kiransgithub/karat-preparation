import unittest

def build_suite(implementation, stage="all"):
    M = implementation
    S = M.ReservationStatus

    class Stage1(unittest.TestCase):
        def test_make_and_conflict(self):
            manager = M.RentalManager()
            first = M.Reservation(101, 'Alice Johnson', 1, 480, 600)
            self.assertTrue(manager.make_reservation(first))
            self.assertEqual(len(manager.reservations), 1)
            self.assertFalse(manager.make_reservation(M.Reservation(102, 'Bob Smith', 1, 540, 660)))
            self.assertEqual(len(manager.reservations), 1)

        def test_different_equipment_and_adjacent(self):
            manager = M.RentalManager()
            self.assertTrue(manager.make_reservation(M.Reservation(101, 'Alice Johnson', 1, 480, 600)))
            self.assertTrue(manager.make_reservation(M.Reservation(102, 'Bob Smith', 2, 480, 600)))
            # Added boundary check: touching endpoints do not overlap.
            self.assertTrue(manager.make_reservation(M.Reservation(103, 'Carol', 1, 600, 660)))

        def test_regression(self):
            # Original cancelled-reservation-frees-slot test.
            manager = M.RentalManager()
            manager.make_reservation(M.Reservation(101, 'Alice Johnson', 1, 480, 600))
            manager.cancel_reservation(101)
            self.assertTrue(manager.make_reservation(M.Reservation(102, 'Bob Smith', 1, 480, 600)))

        def test_cancellation_fields(self):
            manager = M.RentalManager()
            reservation = M.Reservation(101, 'Alice Johnson', 1, 480, 600)
            manager.make_reservation(reservation)
            self.assertTrue(manager.cancel_reservation(101))
            self.assertEqual(reservation.status, S.CANCELLED)
            self.assertEqual(len(manager.reservations), 1)
            self.assertEqual((reservation.reservation_id, reservation.start_time,
                              reservation.end_time, reservation.equipment_id, reservation.staff_name),
                             (101, 480, 600, 1, 'Alice Johnson'))
            self.assertFalse(manager.cancel_reservation(999))
            # Added check for the source method's stated active-only contract.
            self.assertFalse(manager.cancel_reservation(101))
            self.assertEqual(manager.get_reservations_for_equipment(1), [])

    class Stage2(unittest.TestCase):
        def test_active_ids(self):
            manager = M.RentalManager()
            self.assertEqual(manager.get_active_reservation_ids(), [])
            for row in [(103, 'Carol White', 1, 600, 690), (101, 'Alice Johnson', 1, 480, 540),
                        (102, 'Bob Smith', 2, 500, 560)]:
                manager.make_reservation(M.Reservation(*row))
            self.assertEqual(manager.get_active_reservation_ids(), [101, 102, 103])
            manager.cancel_reservation(101)
            self.assertEqual(manager.get_active_reservation_ids(), [102, 103])
            manager.cancel_reservation(103)
            self.assertEqual(manager.get_active_reservation_ids(), [102])

        def test_total_minutes(self):
            manager = M.RentalManager()
            self.assertEqual(manager.get_total_minutes_by_status(), {'ACTIVE': 0, 'CANCELLED': 0})
            for row in [(101, 'Alice Johnson', 1, 480, 540), (102, 'Bob Smith', 2, 500, 560),
                        (103, 'Carol White', 1, 600, 690)]:
                manager.make_reservation(M.Reservation(*row))
            self.assertEqual(manager.get_total_minutes_by_status(), {'ACTIVE': 210, 'CANCELLED': 0})
            manager.cancel_reservation(101)
            self.assertEqual(manager.get_total_minutes_by_status(), {'ACTIVE': 150, 'CANCELLED': 60})
            manager.cancel_reservation(102)
            manager.cancel_reservation(103)
            self.assertEqual(manager.get_total_minutes_by_status(), {'ACTIVE': 0, 'CANCELLED': 210})

    groups = {'1': Stage1, '2': Stage2}
    suite = unittest.TestSuite()
    for key, case in groups.items():
        if stage == 'all' or str(stage) == key:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
