# Solution notes: Medical Equipment Reservations and Status Reports

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/10-Rental/RentalProblem.txt) | [Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/10-Rental/Solution.java)

## Debugging diagnosis

The starter incorrectly treats cancelled reservations as availability conflicts. Filter to ACTIVE reservations before testing interval overlap; cancellation then frees the slot while preserving the audit record.

## Provenance

Stage 1 contains an added practice regression because the published code already passes its tests. The source provides two stages; the rental variant is kept separate from RentalLatest.

## Source issues and conversion choices

- The published Stage 1 code already checks active status and passes its existing tests. Removing that check is an added practice regression, chosen to exercise its supplied cancelled-slot test.

- The source cancelReservation documentation says to cancel active bookings, but the implementation returns True on a repeated cancellation. Both Python starter and solution honor the stated active-only contract; this is a documented correction, not the intentional regression.

- The source supplies completed reporting methods; the Python starter replaces them with Stage 2 stubs.

- No equipment-existence check is introduced because the source test fixtures intentionally omit equipment registration.

## Tests and complexity
The source tests for storing a booking, rejecting overlap, separating equipment, freeing a cancelled slot, retaining cancellation fields, sorting active IDs, and status-duration totals are translated. Added checks cover endpoint adjacency, repeated cancellation, and active-equipment queries.

Availability, booking, cancellation, equipment queries, and minute aggregation scan n reservations: O(n) time. Active-ID reporting costs O(n + a log a), where a is the number of active bookings. Reporting returns O(n) worst-case output; duration totals use O(1) extra space.
