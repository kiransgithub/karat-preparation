"""Python adaptation of the medical-equipment rental exercise."""
from dataclasses import dataclass, field
from enum import Enum

class ReservationStatus(Enum):
    ACTIVE = 'ACTIVE'
    CANCELLED = 'CANCELLED'

@dataclass
class Equipment:
    equipment_id: int
    name: str

@dataclass(eq=False)
class Reservation:
    reservation_id: int
    staff_name: str
    equipment_id: int
    start_time: int
    end_time: int
    status: ReservationStatus = field(default=ReservationStatus.ACTIVE, init=False)

    def get_duration(self) -> int:
        return self.end_time - self.start_time

    def __eq__(self, other):
        return isinstance(other, Reservation) and self.reservation_id == other.reservation_id

    def __hash__(self):
        return hash(self.reservation_id)

class RentalManager:
    def __init__(self):
        self.equipment_list: list[Equipment] = []
        self.reservations: list[Reservation] = []

    def add_equipment(self, equipment: Equipment) -> None:
        self.equipment_list.append(equipment)

    def make_reservation(self, reservation: Reservation) -> bool:
        if not self.is_available(reservation.equipment_id, reservation.start_time, reservation.end_time):
            return False
        self.reservations.append(reservation)
        return True

    def is_available(self, equipment_id: int, start_time: int, end_time: int) -> bool:
        for reservation in self.reservations:
            if reservation.equipment_id == equipment_id and reservation.status == ReservationStatus.ACTIVE:
                if start_time < reservation.end_time and end_time > reservation.start_time:
                    return False
        return True

    def cancel_reservation(self, reservation_id: int) -> bool:
        for reservation in self.reservations:
            if reservation.reservation_id == reservation_id and reservation.status == ReservationStatus.ACTIVE:
                reservation.status = ReservationStatus.CANCELLED
                return True
        return False

    def get_reservations_for_equipment(self, equipment_id: int) -> list[Reservation]:
        return [r for r in self.reservations
                if r.equipment_id == equipment_id and r.status == ReservationStatus.ACTIVE]

    def get_active_reservation_ids(self) -> list[int]:
        return sorted(r.reservation_id for r in self.reservations if r.status == ReservationStatus.ACTIVE)

    def get_total_minutes_by_status(self) -> dict[str, int]:
        totals = {'ACTIVE': 0, 'CANCELLED': 0}
        for reservation in self.reservations:
            totals[reservation.status.name] += reservation.get_duration()
        return totals
