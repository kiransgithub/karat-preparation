# 10. Medical Equipment Reservations and Status Reports

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/10-Rental/RentalProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 contains an added practice regression because the published code already passes its tests. The source provides two stages; the rental variant is kept separate from RentalLatest.

Manage shared clinic equipment, allow staff to reserve time intervals, and report booked minutes by reservation status.

Example: a booking from minute 480 through 600 blocks a booking starting at 540, permits one starting at 600, and stops blocking the interval after cancellation. Three bookings of 60, 60, and 90 minutes total 210 active minutes.

## Data model

- `ReservationStatus`: ACTIVE, CANCELLED.

- `Equipment`: equipment_id: int, name: str.

- `Reservation`: reservation_id: int, staff_name: str, equipment_id: int, start_time: int, end_time: int; status initially ACTIVE; equality compares reservation_id.

- `RentalManager`: equipment_list: list[Equipment], reservations: list[Reservation].

## Stage 1: Debug booking availability

1. Read the manager and repair its failing reservation test.

2. Reservations conflict only for the same equipment when active time intervals overlap. A cancelled reservation remains stored but must free its time slot.

3. make_reservation returns True only when it stores the booking. cancel_reservation changes an active booking and returns True; return False when no active matching booking exists.

### Python API

```python

RentalManager.is_available(equipment_id: int, start_time: int, end_time: int) -> bool

RentalManager.make_reservation(reservation: Reservation) -> bool

RentalManager.cancel_reservation(reservation_id: int) -> bool

```

## Stage 2: Report active bookings and booked minutes

1. get_active_reservation_ids returns every active reservation ID in ascending numeric order, or an empty list.

2. get_total_minutes_by_status sums end_time - start_time for stored reservations separately by status. Always include ACTIVE and CANCELLED string keys, even when their totals are zero.

### Python API

```python

RentalManager.get_active_reservation_ids() -> list[int]

RentalManager.get_total_minutes_by_status() -> dict[str, int]

```

## Clarifications

- Times are integer minutes within one day and valid input has start_time < end_time.

- Intervals that only touch at an endpoint do not conflict.

- Equipment IDs need not be registered through add_equipment before booking: the original tests book without registering equipment.

- Reservation IDs are unique in valid input. This exercise does not add duplicate-ID validation.

- A second cancellation returns False, following the source method documentation's active-only contract.
