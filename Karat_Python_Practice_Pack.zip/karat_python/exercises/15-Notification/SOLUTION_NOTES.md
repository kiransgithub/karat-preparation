# 15. Solution notes

## Debugging task

Added practice regression supported by the source order-filtering test because the checked-in Stage 1 code is already correct.

The query uses the notification identifier as its filter instead of the parent order identifier. Filter by order_id, then sort the notification IDs.

## Source adjustments

- The source already implements the Stage 1 order query correctly; the original failing line is not preserved.
- The Python starter adds a documented practice regression by filtering on notification_id instead of order_id. This is an introduced exercise fault, not a claim about the original interview code.
- The original problem text has incomplete Java comment/bracing structure. Only its intended API and behavior are carried over.
- The Java answer encodes pairs into strings; the Python answer uses a set of tuples to represent exactly the specified duplicate identity.

## Verification and complexity
All four original named tests are translated, including within-batch duplicates, cross-batch duplicates, missing notification IDs, same-time/different-status pairs, and same-status/different-time pairs. Added cases check empty batches, independent notifications and instances, and insertion-independent ID sorting.

For N notifications and B updates in a batch, add_updates takes O(N + B) expected time because lookup is a linear scan and set insertion is expected O(1). Counting stored updates is expected O(1). Order queries take O(N + K log K) for K matching IDs. Storage is O(N + U), where U is the total number of distinct updates.

[Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/15-Notification/Solution.java)
