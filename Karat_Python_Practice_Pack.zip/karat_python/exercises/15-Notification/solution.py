from dataclasses import dataclass
from enum import Enum

class DeliveryStatus(Enum):
    QUEUED = 1
    SENT = 2
    DELIVERED = 3
    FAILED = 4

@dataclass(frozen=True)
class Notification:
    notification_id: int
    order_id: int
    created_at: int

class NotificationCenter:
    def __init__(self):
        self.notifications: list[Notification] = []
        self.notification_updates: dict[int, set[tuple[DeliveryStatus, int]]] = {}

    def add_notification(self, notification: Notification) -> None:
        self.notifications.append(notification)

    def get_notification(self, notification_id: int) -> Notification | None:
        return next((n for n in self.notifications if n.notification_id == notification_id), None)

    def get_order_notifications(self, order_id: int) -> list[int]:
        return sorted(n.notification_id for n in self.notifications if n.order_id == order_id)

    def add_updates(self, notification_id: int, updates: list[tuple[DeliveryStatus, int]]) -> int:
        if self.get_notification(notification_id) is None:
            return 0
        stored = self.notification_updates.setdefault(notification_id, set())
        before = len(stored)
        stored.update(updates)
        return len(stored) - before

    def get_update_count(self, notification_id: int) -> int:
        return len(self.notification_updates.get(notification_id, set()))
