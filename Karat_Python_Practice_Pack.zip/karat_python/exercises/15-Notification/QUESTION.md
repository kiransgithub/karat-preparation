# 15. Order Notifications and Idempotent Delivery Updates

Manage messages generated for retail orders. Providers can repeat delivery updates within a batch or across batches; only new status/timestamp pairs should be retained.

## Data model

- **DeliveryStatus**: `QUEUED=1, SENT=2, DELIVERED=3, FAILED=4`
- **Notification**: `notification_id: int, order_id: int, created_at: int`
- **Update**: `tuple[DeliveryStatus, int] representing (status, timestamp)`

## Stage 1: Repair notification lookup by order

- Read NotificationCenter and diagnose its failing query test.
- Return all notification IDs for the requested order, sorted ascending. Return [] for an order without notifications. Preserve add_notification and get_notification.

Python methods:

- `get_order_notifications(order_id: int) -> list[int]`

## Stage 2: Ingest and count unique updates

- For a known notification, store only status/timestamp pairs not already present and return the number added. Deduplicate both against earlier calls and within the current batch.
- For an unknown notification, store nothing and return 0.
- Return the number of stored unique updates for a notification; return 0 if it is missing or has no updates.

Python methods:

- `add_updates(notification_id: int, updates: list[tuple[DeliveryStatus, int]]) -> int`
- `get_update_count(notification_id: int) -> int`

## Examples

With notification 40 registered:

- `add_updates(40, [(DeliveryStatus.SENT, 5), (DeliveryStatus.DELIVERED, 15)])` returns `2`.
- A later batch `[(DeliveryStatus.SENT, 5), (DeliveryStatus.FAILED, 30)]` returns `1`.
- `get_update_count(40)` now returns `3`.

## Clarifications

- Times are integer minutes from the start of the current window.
- A duplicate requires both the same status and the same timestamp. Different statuses at one timestamp and one status at different timestamps remain distinct.
- No ordering, transition validation, latest-status calculation, or precedence rule is requested; the enum values preserve the source ranks only.
- add_notification appends records, and get_notification returns the first matching record or None.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/15-Notification/NotificationProblem.txt)
