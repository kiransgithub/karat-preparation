import unittest

def build_suite(implementation, stage='all'):
    M = implementation
    S = M.DeliveryStatus

    class Stage1(unittest.TestCase):
        def test_source_notification(self):
            n = M.Notification(1,500,30)
            self.assertEqual((n.notification_id,n.order_id,n.created_at),(1,500,30))

        def test_source_order_query_regression(self):
            center = M.NotificationCenter()
            for nid,oid in [(1,1),(2,2),(3,1),(4,2),(5,1)]:
                center.add_notification(M.Notification(nid,oid,0))
            self.assertEqual(center.get_order_notifications(1),[1,3,5])
            self.assertEqual(center.get_order_notifications(2),[2,4])
            self.assertEqual(center.get_order_notifications(99),[])
            # Added check: sorting is independent of arrival order.
            center.notifications.reverse()
            self.assertEqual(center.get_order_notifications(1),[1,3,5])

        # Added edge checks for existing behavior, isolated from later stubs.
        def test_existing_id_lookup(self):
            center = M.NotificationCenter()
            n = M.Notification(9,500,20)
            center.add_notification(n)
            self.assertEqual(center.get_notification(9),n)
            self.assertIsNone(center.get_notification(99))

        def test_empty_order(self):
            self.assertEqual(M.NotificationCenter().get_order_notifications(1),[])

    class Stage2(unittest.TestCase):
        def test_source_add_updates(self):
            center = M.NotificationCenter()
            for nid in (10,20):
                center.add_notification(M.Notification(nid,1,0))
            self.assertEqual(center.add_updates(10,[(S.SENT,5),(S.DELIVERED,15)]),2)
            self.assertEqual(center.add_updates(10,[(S.SENT,5),(S.FAILED,20)]),1)
            self.assertEqual(center.add_updates(10,[(S.SENT,5),(S.FAILED,20)]),0)
            self.assertEqual(center.add_updates(20,[(S.SENT,8),(S.SENT,8),(S.DELIVERED,12)]),2)
            self.assertEqual(center.add_updates(999,[(S.SENT,0)]),0)
            self.assertEqual(center.add_updates(10,[(S.SENT,25),(S.FAILED,25)]),2)
            self.assertEqual(center.add_updates(20,[(S.SENT,30),(S.SENT,35)]),2)

        def test_source_update_count(self):
            center = M.NotificationCenter()
            center.add_notification(M.Notification(10,1,0))
            center.add_notification(M.Notification(30,2,0))
            center.add_updates(10,[(S.SENT,5),(S.DELIVERED,15)])
            center.add_updates(10,[(S.SENT,5),(S.FAILED,20)])
            center.add_updates(999,[(S.SENT,0)])
            self.assertEqual(center.get_update_count(10),3)
            self.assertEqual(center.get_update_count(30),0)
            self.assertEqual(center.get_update_count(999),0)

        # Added edges: empty batch and the same update on separate notifications.
        def test_empty_and_independent_notifications(self):
            center = M.NotificationCenter()
            for nid in (1,2):
                center.add_notification(M.Notification(nid,1,0))
                self.assertEqual(center.add_updates(nid,[]),0)
                self.assertEqual(center.add_updates(nid,[(S.QUEUED,0)]),1)
                self.assertEqual(center.get_update_count(nid),1)
            self.assertEqual(M.NotificationCenter().get_update_count(1),0)

    classes = {'1': Stage1, '2': Stage2}
    chosen = classes if stage == "all" else {str(stage): classes[str(stage)]}
    suite = unittest.TestSuite()
    for case in chosen.values():
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
