from dataclasses import dataclass
from typing import Iterable

@dataclass(init=False)
class LogEntry:
    timestamp: float
    license_plate: str
    booth_type: str
    location: int
    direction: str

    def __init__(self, log_line: str):
        tokens = log_line.split()
        self.timestamp = float(tokens[0])
        self.license_plate = tokens[1]
        self.booth_type = tokens[3]
        self.location = int(tokens[2][:-1])
        letter = tokens[2][-1]
        if letter not in ('E', 'W'):
            raise ValueError('Direction must be E or W')
        self.direction = {'E': 'EAST', 'W': 'WEST'}[letter]

class LogFile:
    def __init__(self, reader: str | Iterable[str]):
        lines = reader.splitlines() if isinstance(reader, str) else reader
        self.log_entries = [LogEntry(line.strip()) for line in lines]

    def get(self, index: int) -> LogEntry:
        return self.log_entries[index]

    def size(self) -> int:
        return len(self.log_entries)

    def count_journeys(self) -> int:
        return sum(entry.booth_type == 'EXIT' for entry in self.log_entries)

    def catch_speeders(self) -> list[str]:
        previous: dict[str, LogEntry] = {}
        segments_at_least_120: dict[str, int] = {}
        flagged: set[str] = set()
        tickets: list[str] = []
        for current in self.log_entries:
            plate = current.license_plate
            if current.booth_type == 'ENTRY':
                previous[plate] = current
                segments_at_least_120[plate] = 0
                flagged.discard(plate)
                continue
            prior = previous.get(plate)
            if prior is None:
                continue
            speed = 10 * 3600 / (current.timestamp - prior.timestamp)
            if speed >= 120:
                segments_at_least_120[plate] += 1
            if speed >= 130 or segments_at_least_120[plate] >= 2:
                flagged.add(plate)
            if current.booth_type == 'EXIT':
                if plate in flagged:
                    tickets.append(plate)
                previous.pop(plate)
                segments_at_least_120.pop(plate)
                flagged.discard(plate)
            else:
                previous[plate] = current
        return tickets
