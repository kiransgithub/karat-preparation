import io
import unittest
from collections import Counter

SMALL_LOG = '''
90750.191 JOX304 250E ENTRY
91081.684 JOX304 260E MAINROAD
91483.251 JOX304 270E MAINROAD
91874.493 JOX304 280E EXIT
91082.101 THX138 110E ENTRY
91873.920 THX138 120E MAINROAD
91982.102 THX138 290E EXIT
92301.302 THX138 300E ENTRY
92371.302 THX138 310E EXIT
'''.strip()
SPEEDER_LOG = '''
1000.000 TST002 270W ENTRY
1275.000 TST002 260W EXIT
2000.000 TST003 100E ENTRY
2200.000 TST003 110E MAINROAD
2400.000 TST003 120E EXIT
3000.000 TST003 130E ENTRY
3200.000 TST003 140E EXIT
'''.strip()

def build_suite(implementation, stage='all'):
    M = implementation

    class Stage1(unittest.TestCase):
        def test_precision_regression(self):
            # Source records retained; expected literals corrected to avoid float32 rounding.
            e = M.LogEntry('44776.619 KTB918 310E MAINROAD')
            self.assertAlmostEqual(e.timestamp,44776.619,delta=0.0001)
            self.assertEqual((e.license_plate,e.location,e.direction,e.booth_type),('KTB918',310,'EAST','MAINROAD'))
            w = M.LogEntry('52160.132 ABC123 400W ENTRY')
            self.assertAlmostEqual(w.timestamp,52160.132,delta=0.0001)
            self.assertEqual((w.license_plate,w.location,w.direction,w.booth_type),('ABC123',400,'WEST','ENTRY'))

        def test_source_log_size_corrected(self):
            log = M.LogFile(io.StringIO(SMALL_LOG))
            self.assertEqual(log.size(),9)  # The source's disabled assertion incorrectly says 13.
            self.assertTrue(all(isinstance(e,M.LogEntry) for e in log.log_entries))
            self.assertEqual(log.get(0).license_plate,'JOX304')

        # Added edges: exact integer timestamps, an empty file, and invalid direction.
        def test_integer_and_direction(self):
            self.assertEqual(M.LogEntry('10.0 ABC 10W EXIT').direction,'WEST')
            self.assertEqual(M.LogFile('').size(),0)
            with self.assertRaises(ValueError):
                M.LogEntry('10 ABC 10N EXIT')

    class Stage2(unittest.TestCase):
        def test_source_count(self):
            self.assertEqual(M.LogFile(SMALL_LOG).count_journeys(),3)

        # Added edge: interleaved vehicles with no MAINROAD observation.
        def test_interleaved_and_empty(self):
            log = M.LogFile('0 A 10E ENTRY\n1 B 20W ENTRY\n400 A 20E EXIT\n401 B 10W EXIT')
            self.assertEqual(log.count_journeys(),2)
            self.assertEqual(M.LogFile('').count_journeys(),0)

    class Stage3(unittest.TestCase):
        def test_source_speeders(self):
            log = M.LogFile(SPEEDER_LOG)
            self.assertEqual(Counter(log.catch_speeders()),Counter({'TST002':1,'TST003':2}))
            self.assertEqual(Counter(log.catch_speeders()),Counter({'TST002':1,'TST003':2}))

        # Added exact 120 boundary, one fast segment, and first slow-segment cases.
        def test_thresholds_and_safe_journeys(self):
            text = '\n'.join([
                '0 TWO 10E ENTRY','300 TWO 20E MAINROAD','600 TWO 30E EXIT',
                '1000 ONE 10E ENTRY','1300 ONE 20E EXIT',
                '2000 SAFE 10E ENTRY','2400 SAFE 20E MAINROAD','2800 SAFE 30E EXIT',
                '3000 FAST 30W ENTRY','3275 FAST 20W EXIT'])
            self.assertEqual(Counter(M.LogFile(text).catch_speeders()),Counter({'TWO':1,'FAST':1}))

        # Added regression: off-highway travel and counts must not leak across journeys.
        def test_journey_state_reset(self):
            text = '\n'.join(['0 A 10E ENTRY','300 A 20E EXIT',
                              '301 A 30E ENTRY','601 A 40E EXIT',
                              '700 B 10E ENTRY','1100 B 20E EXIT',
                              '1101 B 30E ENTRY','1501 B 40E EXIT'])
            self.assertEqual(M.LogFile(text).catch_speeders(),[])

        # Added edge: interleaving does not mix one vehicle's timestamps with another's.
        def test_interleaved_speeders(self):
            text = '0 A 10E ENTRY\n1 B 40W ENTRY\n275 A 20E EXIT\n401 B 30W EXIT'
            self.assertEqual(M.LogFile(text).catch_speeders(),['A'])
            self.assertEqual(M.LogFile('').catch_speeders(),[])

    classes = {'1': Stage1, '2': Stage2, '3': Stage3}
    chosen = classes if stage == "all" else {str(stage): classes[str(stage)]}
    suite = unittest.TestSuite()
    for case in chosen.values():
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
