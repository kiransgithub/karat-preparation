from dataclasses import dataclass
from typing import Iterable

@dataclass(init=False)
class LogEntry:
    timestamp: float
    license_plate: str
    booth_type: str
    location: int
    direction: str

    def __init__(self, log_line: str):
        tokens = log_line.split()
        import struct
        self.timestamp = struct.unpack("f", struct.pack("f", float(tokens[0])))[0]
        self.license_plate = tokens[1]
        self.booth_type = tokens[3]
        self.location = int(tokens[2][:-1])
        letter = tokens[2][-1]
        if letter not in ('E', 'W'):
            raise ValueError('Direction must be E or W')
        self.direction = {'E': 'EAST', 'W': 'WEST'}[letter]

class LogFile:
    def __init__(self, reader: str | Iterable[str]):
        lines = reader.splitlines() if isinstance(reader, str) else reader
        self.log_entries = [LogEntry(line.strip()) for line in lines]

    def get(self, index: int) -> LogEntry:
        return self.log_entries[index]

    def size(self) -> int:
        return len(self.log_entries)

    def count_journeys(self) -> int:
        raise NotImplementedError("Implement this stage.")

    def catch_speeders(self) -> list[str]:
        raise NotImplementedError("Implement this stage.")
