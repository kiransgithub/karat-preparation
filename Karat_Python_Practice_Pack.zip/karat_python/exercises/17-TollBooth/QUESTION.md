# 17. Toll Logs, Complete Journeys, and Speeding Detection

Parse toll-booth observations, count completed highway journeys, and flag journeys whose segment speeds exceed the stated thresholds.

## Data model

- **LogEntry**: `timestamp: float, license_plate: str, booth_type: str, location: int, direction: str`
- **LogFile**: `log_entries: list[LogEntry]`

## Stage 1: Repair log parsing

- Read LogEntry and LogFile, then fix the parsing regression.
- Parse a line as timestamp, license plate, distance/direction token, and booth type. Preserve timestamp precision within 0.0001 seconds of the displayed decimal value. Convert E to EAST and W to WEST.

Python methods:

- `LogEntry(log_line: str)`
- `LogFile(reader: str | Iterable[str])`
- `get(index: int) -> LogEntry`
- `size() -> int`

## Stage 2: Count complete journeys

- Count journeys consisting of ENTRY, zero or more MAINROAD observations, then EXIT for a vehicle.
- You may assume journeys are complete and there are no missing observations. Different vehicles may be interleaved, and the same plate may take multiple journeys.

Python methods:

- `count_journeys() -> int`

## Stage 3: Find unsafe journeys

- Flag a journey if any 10 km segment has speed >= 130 km/h, or if at least two of its 10 km segments have speed >= 120 km/h.
- Return a list containing a license plate once per flagged journey. The same plate can therefore appear multiple times. Result order is not significant.
- Do not measure the gap between an EXIT and the next ENTRY. Reset all speeding state between journeys.

Python methods:

- `catch_speeders() -> list[str]`

## Examples

- `LogEntry("44776.619 KTB918 310E MAINROAD")` has location `310`, direction `"EAST"`, and timestamp approximately `44776.619`.
- An ENTRY at 1000 seconds followed by EXIT at 1275 seconds is a 10 km journey at approximately 130.91 km/h, so its plate is flagged.
- Two 10 km segments taking 300 seconds each meet the two-segment 120 km/h threshold.

## Clarifications

- Log lines have four whitespace-separated tokens and valid booth types ENTRY, MAINROAD, or EXIT. Direction must be E or W; any other direction raises ValueError.
- For speeding analysis, successive observations within one journey represent consecutive 10 km segments and strictly increasing timestamps for that vehicle. Other vehicles can be interleaved.
- The count-only SMALL_LOG source fixture includes a 120E-to-290E jump despite the no-missing-observations assumption. It is retained only for parsing/counting tests, not used as a valid speeding fixture.
- LogFile accepts either a text string or an iterable of lines such as io.StringIO. No physical file is required.
- The timestamp accuracy expectation is made explicit for this Python adaptation; source Java f-suffixed test literals obscure the float32 precision loss.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/17-TollBooth/TollBoothProblem.txt)
