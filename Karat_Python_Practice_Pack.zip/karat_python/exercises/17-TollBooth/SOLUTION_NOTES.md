# 17. Solution notes

## Debugging task

The starter preserves the observable Java float32 timestamp narrowing. A corrected precision assertion makes the failure visible in Python.

Converting the decimal timestamp through 32-bit float loses more than 0.0001 seconds at the provided values. Parse directly with Python float, which uses double precision.

## Source adjustments

- Both source files parse timestamps with Float.parseFloat before storing them in double fields. The Python starter explicitly emulates this float32 narrowing; the solution uses Python float directly.
- The source timestamp assertions use f-suffixed literals, which round their expected values too. The Python tests compare with the decimal timestamp text at the stated 0.0001-second tolerance.
- The disabled Java testLogFile expects 13 records, but SMALL_LOG contains 9. The Python test corrects the expectation to 9.
- The Java speed-check answer can dereference a missing fast-segment counter when the first segment is below 120 km/h. The Python solution initializes journey counters.
- The count fixture includes a non-consecutive booth jump. It remains a counting example only; all speeding tests use genuine 10 km segments.

## Verification and complexity
The original parsing records, three-journey log, and speeding multiplicities are translated. The disabled source log-size test is activated with its actual size of 9. Added tests cover the two-segment 120 boundary, a single 120 segment, safe first segments, repeated query calls, interleaved plates, empty logs, and resetting state between journeys.

For L observations and A simultaneously active vehicles: parsing, counting, and speeding detection are O(L) time. Parsing stores O(L) records; the speeding scan adds O(A) working state plus the output tickets. Under the complete-journey guarantee, counting EXIT events counts completed journeys directly.

[Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/17-TollBooth/Solution.java)
