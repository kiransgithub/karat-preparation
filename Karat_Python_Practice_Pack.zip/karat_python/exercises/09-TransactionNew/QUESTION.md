# 09. Imported Transactions, Running Balances, and Type Summaries

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/09-TransactionNew/TransactionNewProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 retains the original defect present in the source problem. Later-stage implementations are replaced by stubs. This source has two stages.

Import financial events from multiple sources, report account activity, and maintain balances for newly recorded transactions.

Example: a deposit of 500, withdrawal of 150, fee of 50, and interest of 20 leave a running balance of 320. A type summary totals positive transaction amounts even for debit types.

## Data model

- `TransactionType`: DEPOSIT, WITHDRAWAL, TRANSFER, FEE, INTEREST.

- `Transaction`: transaction_id: str, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int, description: str, source: str.

- `ImportSystem`: transactions: list[Transaction], balances: dict[int, float].

## Stage 1: Debug per-account net movement

1. Read the models and repair get_account_summary while preserving per-account filtering.

2. Return total_credits, total_debits, net_change, and transaction_count. DEPOSIT and INTEREST add funds; WITHDRAWAL, FEE, and TRANSFER subtract funds.

### Python API

```python

ImportSystem.get_account_summary(account_id: int) -> dict[str, int | float]

```

## Stage 2: Record transactions and aggregate by type

1. Maintain an initially empty balances mapping. The scaffold includes its declaration; verify that new accounts begin at 0.0.

2. record_transaction creates and appends a Transaction and updates that account's running balance using the type's direction.

3. get_type_summary aggregates across all accounts and sources. Keys are uppercase enum-name strings; each value has integer count and positive total_amount. Omit unused types.

### Python API

```python

ImportSystem.record_transaction(transaction_id: str, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int, description: str, source: str) -> None

ImportSystem.get_type_summary() -> dict[str, dict[str, int | float]]

```

## Clarifications

- Amounts are positive and transaction_type is a valid enum member, as specified by the source.

- add_transaction is the original append-only fixture/import helper; only record_transaction updates balances. Do not mix preloaded add_transaction rows into a running-balance workflow without defining a separate initialization policy.

- No deduplication, source matching, or reconciliation algorithm is requested in this variant.

- An account with no matching transactions has zeros for all four summary fields.
