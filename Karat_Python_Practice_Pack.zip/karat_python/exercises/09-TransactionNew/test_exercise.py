import unittest

def build_suite(implementation, stage="all"):
    M = implementation
    T = M.TransactionType

    class Stage1(unittest.TestCase):
        def test_transaction(self):
            t = M.Transaction('t001', 101, 500.0, T.DEPOSIT, 1, 'Salary', 'SRC_A')
            self.assertEqual((t.transaction_id, t.account_id, t.amount, t.transaction_type,
                              t.timestamp, t.description, t.source),
                             ('t001', 101, 500.0, T.DEPOSIT, 1, 'Salary', 'SRC_A'))

        def test_regression(self):
            # Original two-account summary scenario with all five types.
            system = M.ImportSystem()
            data = [('t001', 101, 500.0, T.DEPOSIT, 1, 'Salary'),
                    ('t002', 101, 300.0, T.DEPOSIT, 2, 'Refund'),
                    ('t003', 101, 150.0, T.WITHDRAWAL, 3, 'ATM'),
                    ('t004', 101, 50.0, T.FEE, 4, 'Service fee'),
                    ('t005', 101, 200.0, T.TRANSFER, 5, 'Wire out'),
                    ('t006', 101, 20.0, T.INTEREST, 6, 'Interest paid'),
                    ('t007', 202, 100.0, T.DEPOSIT, 7, 'Deposit'),
                    ('t008', 202, 30.0, T.WITHDRAWAL, 8, 'Withdrawal')]
            for row in data:
                system.add_transaction(M.Transaction(*row, 'SRC_A'))
            self.assertEqual(system.get_account_summary(101),
                             {'total_credits': 820.0, 'total_debits': 400.0,
                              'net_change': 420.0, 'transaction_count': 6})
            self.assertEqual(system.get_account_summary(202),
                             {'total_credits': 100.0, 'total_debits': 30.0,
                              'net_change': 70.0, 'transaction_count': 2})
            # Added negative-net check belongs to the same regression.
            system.add_transaction(M.Transaction('debit', 303, 4.5, T.FEE, 9, '', 'SRC_B'))
            self.assertEqual(system.get_account_summary(303)['net_change'], -4.5)

        def test_unknown_account(self):
            # Added empty result check.
            self.assertEqual(M.ImportSystem().get_account_summary(999),
                             {'total_credits': 0.0, 'total_debits': 0.0,
                              'net_change': 0.0, 'transaction_count': 0})

    class Stage2(unittest.TestCase):
        def test_record_transaction(self):
            system = M.ImportSystem()
            self.assertEqual(system.balances, {})
            rows = [('t001', 101, 500.0, T.DEPOSIT, 1, 'Salary', 500.0),
                    ('t002', 101, 150.0, T.WITHDRAWAL, 2, 'ATM', 350.0),
                    ('t003', 101, 50.0, T.FEE, 3, 'Service fee', 300.0),
                    ('t004', 101, 20.0, T.INTEREST, 4, 'Interest paid', 320.0),
                    ('t005', 202, 200.0, T.DEPOSIT, 5, 'Deposit', 200.0),
                    ('t006', 202, 50.0, T.TRANSFER, 6, 'Wire', 150.0)]
            for index, row in enumerate(rows, 1):
                tid, account, amount, kind, timestamp, description, expected = row
                system.record_transaction(tid, account, amount, kind, timestamp, description, 'SRC_A')
                self.assertEqual(len(system.transactions), index)
                self.assertAlmostEqual(system.balances[account], expected)
                self.assertEqual(system.transactions[-1], M.Transaction(tid, account, amount, kind, timestamp, description, 'SRC_A'))
            self.assertAlmostEqual(system.balances[101], 320.0)

        def test_type_summary(self):
            system = M.ImportSystem()
            data = [(101, 500.0, T.DEPOSIT), (101, 300.0, T.DEPOSIT),
                    (202, 800.0, T.DEPOSIT), (101, 150.0, T.WITHDRAWAL),
                    (202, 50.0, T.WITHDRAWAL), (101, 50.0, T.FEE),
                    (202, 200.0, T.TRANSFER), (101, 20.0, T.INTEREST)]
            for i, (account, amount, kind) in enumerate(data, 1):
                system.record_transaction(f't{i:03}', account, amount, kind, i, '', 'SRC_A')
            self.assertEqual(system.get_type_summary(),
                             {'DEPOSIT': {'count': 3, 'total_amount': 1600.0},
                              'WITHDRAWAL': {'count': 2, 'total_amount': 200.0},
                              'FEE': {'count': 1, 'total_amount': 50.0},
                              'TRANSFER': {'count': 1, 'total_amount': 200.0},
                              'INTEREST': {'count': 1, 'total_amount': 20.0}})
            only = M.ImportSystem()
            only.record_transaction('t100', 300, 100.0, T.DEPOSIT, 1, 'First', 'SRC_A')
            only.record_transaction('t101', 300, 200.0, T.DEPOSIT, 2, 'Second', 'SRC_A')
            self.assertEqual(only.get_type_summary(), {'DEPOSIT': {'count': 2, 'total_amount': 300.0}})

        def test_empty_and_first_debit(self):
            # Added negative starting balance and independent system state.
            system = M.ImportSystem()
            self.assertEqual(system.get_type_summary(), {})
            system.record_transaction('fee', 1, 2.5, T.FEE, 1, '', 'SRC_A')
            self.assertAlmostEqual(system.balances[1], -2.5)
            self.assertEqual(M.ImportSystem().balances, {})

    groups = {'1': Stage1, '2': Stage2}
    suite = unittest.TestSuite()
    for key, case in groups.items():
        if stage == 'all' or str(stage) == key:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
