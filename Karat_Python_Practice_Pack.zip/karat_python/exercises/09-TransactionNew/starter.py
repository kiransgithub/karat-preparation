"""Python adaptation of the imported-transactions exercise."""
from dataclasses import dataclass
from enum import Enum

class TransactionType(Enum):
    DEPOSIT = 'DEPOSIT'
    WITHDRAWAL = 'WITHDRAWAL'
    TRANSFER = 'TRANSFER'
    FEE = 'FEE'
    INTEREST = 'INTEREST'

@dataclass(frozen=True)
class Transaction:
    transaction_id: str
    account_id: int
    amount: float
    transaction_type: TransactionType
    timestamp: int
    description: str
    source: str

class ImportSystem:

    def __init__(self):
        self.transactions: list[Transaction] = []
        self.balances: dict[int, float] = {}

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def get_account_summary(self, account_id: int) -> dict[str, int | float]:
        credits = 0.0
        debits = 0.0
        count = 0
        for transaction in self.transactions:
            if transaction.account_id != account_id:
                continue
            count += 1
            if transaction.transaction_type in (TransactionType.DEPOSIT, TransactionType.INTEREST):
                credits += transaction.amount
            else:
                debits += transaction.amount
        net_change = credits
        return {'total_credits': credits, 'total_debits': debits, 'net_change': net_change, 'transaction_count': count}

    def record_transaction(self, transaction_id: str, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int, description: str, source: str) -> None:
        raise NotImplementedError('Implement this stage of the exercise.')

    def get_type_summary(self) -> dict[str, dict[str, int | float]]:
        raise NotImplementedError('Implement this stage of the exercise.')
