# Solution notes: Imported Transactions, Running Balances, and Type Summaries

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/09-TransactionNew/TransactionNewProblem.txt) | [Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/09-TransactionNew/transaction1new.java)

## Debugging diagnosis

The account summary computes net movement from credits alone. Subtract total debits: the original account 101 has 820 credits and 400 debits, giving 420 net movement.

## Provenance

Stage 1 retains the original defect present in the source problem. Later-stage implementations are replaced by stubs. This source has two stages.

## Source issues and conversion choices

- The original Stage 1 bug is preserved directly: net_change is assigned credits without subtracting debits.

- The problem file contains completed later-stage code; Python restores method stubs for practice while retaining the balances declaration as model scaffolding.

- The source test runner comments out the Stage 2 tests. The Python staged runner enables them explicitly.

## Tests and complexity
All original data scenarios are retained: transaction fields, two-account summaries, six sequential balance updates, all-five-type aggregation, and the deposit-only summary. Added checks cover missing accounts, negative net movement, a first transaction that is a debit, and isolated state between systems.

For n transactions, per-account and per-type summaries take O(n) time. Recording appends and updates a dictionary in amortized O(1) time. Type summaries use O(k) space for k present transaction types; balances use O(a) for a accounts.
