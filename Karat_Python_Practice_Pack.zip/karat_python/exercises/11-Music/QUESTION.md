# 11. Listener Statistics and Duplicate Song Groups

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/11-Music/MusicProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 preserves the original wrong-list defect. Stage 2 follows the stated duplicate-group requirements and corrects additional flaws in the Java reference solution. This source has two stages.

Analyze listener activity and identify duplicate catalog records imported from different feeds. Keep skipped plays in listener statistics and use deterministic IDs when reporting duplicate groups.

Example: four plays covering three songs, with two completed plays, produce ListenerStats(4, 3, 0.5). Duplicate song IDs 9, 3, 5 produce DedupResult(song_id=3, merged_ids=[5, 9]).

## Data model

- `Song`: song_id: int, title: str, artist: str, duration_seconds: int; optional description, album, genre: str | None and release_year: int | None.

- `PlayEvent`: play_id: int, user_id: int, song_id: int, listened_seconds: int, timestamp: int.

- `ListenerStats`: total_plays: int, unique_songs: int, completion_rate: float.

- `DedupResult`: song_id: int (kept ID), merged_ids: list[int].

- `MusicLibrary`: songs: dict[int, Song], play_events: list[PlayEvent].

## Stage 1: Debug listener analytics

1. Read the library and fix the failing listener statistics test.

2. For one user, count all plays, count distinct song IDs including skipped plays, and calculate completed plays divided by total plays. A play is complete when listened_seconds >= duration_seconds.

3. A user with no plays receives ListenerStats(0, 0, 0.0). A statistics query must leave stored play events unchanged.

### Python API

```python

MusicLibrary.get_listener_stats(user_id: int) -> ListenerStats

```

## Stage 2: Identify duplicate song groups

1. Treat songs as duplicates when title and artist match without case sensitivity and duration_seconds is equal. Other metadata does not participate.

2. For each group with at least two members, keep the smallest song ID and put all other IDs in merged_ids sorted ascending.

3. Return DedupResult objects sorted by their kept song_id. Report groups only; do not remove songs or rewrite play events.

### Python API

```python

MusicLibrary.find_duplicate_groups() -> list[DedupResult]

```

## Clarifications

- Song IDs are unique, as guaranteed by the source, and all play events reference cataloged songs.

- Titles and artist names are strings. Python casefold provides case-insensitive grouping; whitespace is not stripped.

- Completion rate is a fraction between 0.0 and 1.0, not a percentage.

- Finding groups is a query: repeated calls with unchanged data should return identical groups.
