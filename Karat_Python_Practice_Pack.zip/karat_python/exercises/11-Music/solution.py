"""Python adaptation of the first music analytics exercise."""
from dataclasses import dataclass

@dataclass
class Song:
    song_id: int
    title: str
    artist: str
    duration_seconds: int
    description: str | None = None
    album: str | None = None
    release_year: int | None = None
    genre: str | None = None

@dataclass
class PlayEvent:
    play_id: int
    user_id: int
    song_id: int
    listened_seconds: int
    timestamp: int

@dataclass
class ListenerStats:
    total_plays: int
    unique_songs: int
    completion_rate: float

@dataclass
class DedupResult:
    song_id: int
    merged_ids: list[int]

class MusicLibrary:
    def __init__(self):
        self.songs: dict[int, Song] = {}
        self.play_events: list[PlayEvent] = []

    def add_song(self, song: Song) -> None:
        self.songs[song.song_id] = song

    def add_play_event(self, event: PlayEvent) -> None:
        self.play_events.append(event)

    def is_completed(self, event: PlayEvent) -> bool:
        return event.listened_seconds >= self.songs[event.song_id].duration_seconds

    def get_listener_stats(self, user_id: int) -> ListenerStats:
        user_events = [e for e in self.play_events if e.user_id == user_id]
        completed_events: list[PlayEvent] = []
        for event in user_events:
            if self.is_completed(event):
                completed_events.append(event)
        total = len(user_events)
        unique = len({event.song_id for event in user_events})
        rate = len(completed_events) / total if total else 0.0
        return ListenerStats(total, unique, rate)

    def find_duplicate_groups(self) -> list[DedupResult]:
        groups: dict[tuple[str, str, int], list[int]] = {}
        for song in self.songs.values():
            key = (song.title.casefold(), song.artist.casefold(), song.duration_seconds)
            groups.setdefault(key, []).append(song.song_id)
        result = []
        for ids in groups.values():
            if len(ids) > 1:
                ids.sort()
                result.append(DedupResult(ids[0], ids[1:]))
        return sorted(result, key=lambda item: item.song_id)
