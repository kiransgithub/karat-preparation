import unittest

def build_suite(implementation, stage="all"):
    M = implementation

    class Stage1(unittest.TestCase):
        def test_empty_and_skipped_user(self):
            # Existing empty-user contract plus a skipped-only edge case.
            library = M.MusicLibrary()
            self.assertEqual(library.get_listener_stats(99), M.ListenerStats(0, 0, 0.0))
            library.add_song(M.Song(1, 'A', 'Artist', 180))
            library.add_play_event(M.PlayEvent(1, 7, 1, 20, 1))
            self.assertEqual(library.get_listener_stats(7), M.ListenerStats(1, 1, 0.0))

        def test_regression(self):
            # Original user 1, 2, 3 scenarios, retained in one regression test.
            library = M.MusicLibrary()
            for row in [(101, 'Song A', 'Artist 1', 180), (102, 'Song B', 'Artist 2', 200),
                        (103, 'Song C', 'Artist 1', 240)]:
                library.add_song(M.Song(*row))
            for row in [(1, 1, 101, 180, 1000), (2, 1, 102, 220, 1100),
                        (3, 1, 101, 50, 1200), (4, 1, 103, 100, 1300),
                        (5, 2, 102, 200, 2000), (6, 2, 103, 250, 2100)]:
                library.add_play_event(M.PlayEvent(*row))
            self.assertEqual(library.get_listener_stats(1), M.ListenerStats(4, 3, 0.5))
            self.assertEqual(library.get_listener_stats(2), M.ListenerStats(2, 2, 1.0))
            self.assertEqual(library.get_listener_stats(3), M.ListenerStats(0, 0, 0.0))
            # Added query stability check catches the same wrong-list mutation.
            self.assertEqual(len(library.play_events), 6)
            self.assertEqual(library.get_listener_stats(1), M.ListenerStats(4, 3, 0.5))
            self.assertEqual(len(library.play_events), 6)

    class Stage2(unittest.TestCase):
        def test_original_groups(self):
            library = M.MusicLibrary()
            data = [(1, 'Song A', 'Artist 1', 180, None, None, None, 'rock'),
                    (2, 'song a', 'ARTIST 1', 180, 'Studio version', 'First Album', None, 'rock'),
                    (3, 'SONG A', 'artist 1', 180, 'Live', 'Live Album', None, None),
                    (10, 'Song B', 'Artist 2', 200, None, 'B Album', None, None),
                    (11, 'SONG B', 'Artist 2', 200, 'some description', None, None, 'pop'),
                    (20, 'Song C', 'Artist 3', 240), (21, 'song c', 'Artist 3', 240),
                    (99, 'Only Song', 'Solo Artist', 300)]
            for row in data:
                library.add_song(M.Song(*row))
            expected = [M.DedupResult(1, [2, 3]), M.DedupResult(10, [11]), M.DedupResult(20, [21])]
            self.assertEqual(library.find_duplicate_groups(), expected)

        def test_ordering_repeatability_and_distinct_duration(self):
            # Added regressions for defects in the supplied Java reference solution.
            library = M.MusicLibrary()
            for row in [(9, 'Tune', 'Singer', 10), (3, 'TUNE', 'SINGER', 10),
                        (5, 'tune', 'singer', 10), (1, 'Tune', 'Singer', 11)]:
                library.add_song(M.Song(*row))
            expected = [M.DedupResult(3, [5, 9])]
            self.assertEqual(library.find_duplicate_groups(), expected)
            self.assertEqual(library.find_duplicate_groups(), expected)
            self.assertEqual(len(library.songs), 4)

        def test_empty_and_key_separation(self):
            self.assertEqual(M.MusicLibrary().find_duplicate_groups(), [])
            # Different title/artist boundaries must not collide in a concatenated key.
            library = M.MusicLibrary()
            library.add_song(M.Song(1, 'b c', 'a', 10))
            library.add_song(M.Song(2, 'c', 'a b', 10))
            self.assertEqual(library.find_duplicate_groups(), [])

    groups = {'1': Stage1, '2': Stage2}
    suite = unittest.TestSuite()
    for key, case in groups.items():
        if stage == 'all' or str(stage) == key:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
