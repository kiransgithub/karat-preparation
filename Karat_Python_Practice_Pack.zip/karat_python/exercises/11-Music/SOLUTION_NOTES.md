# Solution notes: Listener Statistics and Duplicate Song Groups

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/11-Music/MusicProblem.txt) | [Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/11-Music/Solution.java)

## Debugging diagnosis

Completed plays are appended to self.play_events rather than completed_events. The completion count stays zero and a read operation changes future results. Append to the local completed list, leaving the global event log untouched.

## Provenance

Stage 1 preserves the original wrong-list defect. Stage 2 follows the stated duplicate-group requirements and corrects additional flaws in the Java reference solution. This source has two stages.

## Source issues and conversion choices

- The original starter appends completed plays to the global play-event list instead of the local completed list. The Python starter preserves that single wrong-list defect.

- The Java dedup solution uses a persistent group map, so repeated calls accumulate entries. Python builds groups per call.

- The Java dedup solution assumes iteration order yields the smallest ID and sorted remaining IDs. Python explicitly sorts each duplicate group.

- A tuple key avoids collisions possible with concatenated title and artist text. Optional metadata is retained in the model but does not affect grouping.

## Tests and complexity
The original three-listener statistics scenario and three duplicate groups are retained. Added checks cover skipped-only users, repeated statistics queries, descending insertion order, repeated dedup queries, differing durations, empty catalogs, and tuple-key separation.

For p play events, listener statistics take O(p) time and O(p) temporary space. For s songs, grouping plus per-group/output sorting costs O(s log s) in the worst case and O(s) space, excluding title/artist string lengths.
