from dataclasses import dataclass
from enum import Enum

class MembershipStatus(Enum):
    BRONZE = 'BRONZE'
    SILVER = 'SILVER'
    GOLD = 'GOLD'

@dataclass
class Member:
    member_id: int
    name: str
    membership_status: MembershipStatus

@dataclass
class Workout:
    id: int
    start_time: int
    end_time: int

    def get_duration(self) -> int:
        return self.end_time - self.start_time

@dataclass
class MembershipStatistics:
    total_members: int
    total_paid_members: int
    conversion_rate: float

class Membership:
    def __init__(self):
        self.members: list[Member] = []
        self.workout_sessions: dict[int, list[Workout]] = {}

    def add_member(self, member: Member) -> None:
        self.members.append(member)

    def update_membership(self, member_id: int, membership_status: MembershipStatus) -> None:
        for member in self.members:
            if member.member_id == member_id:
                member.membership_status = membership_status
                break

    def get_membership_statistics(self) -> MembershipStatistics:
        count = len(self.members)
        if not count:
            return MembershipStatistics(0, 0, 0.0)
        paid = sum(m.membership_status in (MembershipStatus.SILVER, MembershipStatus.GOLD)
                   for m in self.members)
        return MembershipStatistics(count, paid, paid * 100.0 / count)

    def add_workout(self, member_id: int, workout: Workout) -> None:
        if any(m.member_id == member_id for m in self.members):
            self.workout_sessions.setdefault(member_id, []).append(workout)

    def get_average_workout_durations(self) -> dict[int, float]:
        return {member_id: sum(w.get_duration() for w in workouts) / len(workouts)
                for member_id, workouts in self.workout_sessions.items() if workouts}

    def get_due_payments(self) -> dict[int, int]:
        tiers = {MembershipStatus.BRONZE: (1, 10), MembershipStatus.SILVER: (3, 8),
                 MembershipStatus.GOLD: (5, 6)}
        payments = {}
        for member in self.members:
            free, rate = tiers[member.membership_status]
            ordered = sorted(self.workout_sessions.get(member.member_id, []), key=lambda w: w.id)
            payments[member.member_id] = sum(((w.get_duration() + 59) // 60) * rate
                                              for w in ordered[free:])
        return payments
