import unittest

def build_suite(M, stage="all"):
    S = M.MembershipStatus

    class Stage1(unittest.TestCase):
        def test_source_member_and_update(self):
            m = M.Member(1, 'John Doe', S.BRONZE)
            self.assertEqual((m.member_id, m.name, m.membership_status), (1, 'John Doe', S.BRONZE))
            gym = M.Membership()
            gym.add_member(m)
            self.assertIs(gym.members[0], m)
            gym.update_membership(1, S.SILVER)
            self.assertEqual(m.membership_status, S.SILVER)
            gym.update_membership(99, S.GOLD)
            self.assertEqual(len(gym.members), 1)

        def test_source_regression(self):
            gym = M.Membership()
            for i, tier in enumerate([S.SILVER, S.BRONZE, S.GOLD, S.SILVER, S.BRONZE], 1):
                gym.add_member(M.Member(i, str(i), tier))
            stats = gym.get_membership_statistics()
            self.assertEqual(stats.total_members, 5)
            self.assertEqual(stats.total_paid_members, 3)
            self.assertAlmostEqual(stats.conversion_rate, 60.0)
            # Added fractional-percentage check.
            gym = M.Membership()
            for i, tier in enumerate([S.SILVER, S.BRONZE, S.BRONZE], 1):
                gym.add_member(M.Member(i, str(i), tier))
            self.assertAlmostEqual(gym.get_membership_statistics().conversion_rate, 100 / 3)

        def test_empty_statistics(self):
            self.assertEqual(M.Membership().get_membership_statistics(), M.MembershipStatistics(0, 0, 0.0))

    class Stage2(unittest.TestCase):
        def test_source_averages(self):
            gym = M.Membership()
            for i,tier in [(12,S.SILVER),(22,S.BRONZE),(31,S.GOLD),(37,S.SILVER)]:
                gym.add_member(M.Member(i, str(i), tier))
            for member, ident, start, end in [(12,11,10,20),(22,24,15,35),(31,32,45,90),
                     (12,47,100,155),(22,56,120,200),(31,62,300,400),(12,78,1000,1010),(4,80,1010,1045)]:
                gym.add_workout(member, M.Workout(ident,start,end))
            self.assertEqual(gym.get_average_workout_durations(), {12:25.0,22:50.0,31:72.5})
            self.assertNotIn(4, gym.workout_sessions)

        def test_empty_and_zero_duration(self):
            gym = M.Membership()
            self.assertEqual(gym.get_average_workout_durations(), {})
            gym.add_member(M.Member(1,'A',S.BRONZE))
            gym.add_workout(1,M.Workout(1,10,10))
            self.assertEqual(gym.get_average_workout_durations(), {1:0.0})

    class Stage3(unittest.TestCase):
        def test_source_payments(self):
            gym = M.Membership()
            for i,tier in [(1,S.BRONZE),(2,S.SILVER),(3,S.GOLD)]:
                gym.add_member(M.Member(i,str(i),tier))
            data = {
                1:[(1,500,700),(10,300,350),(12,10,20),(3,50,90),(6,130,150),(15,900,920)],
                2:[(13,510,540),(14,600,700),(2,15,35),(4,100,155),(18,200,225),(8,1050,1155)],
                3:[(5,120,135),(17,140,190),(9,210,255),(11,400,450),(16,910,940),(7,1000,1100)]}
            for member, rows in data.items():
                for row in rows:
                    gym.add_workout(member,M.Workout(*row))
            self.assertEqual(gym.get_due_payments(), {1:50,2:32,3:6})
            gym.add_member(M.Member(4,'Ron',S.SILVER))
            self.assertEqual(gym.get_due_payments()[4], 0)

        def test_hour_boundaries(self):
            # Added: each session must be rounded separately, after ID ordering.
            gym=M.Membership()
            gym.add_member(M.Member(1,'A',S.BRONZE))
            for row in [(4,0,61),(2,0,1),(1,0,90),(3,0,60)]:
                gym.add_workout(1,M.Workout(*row))
            self.assertEqual(gym.get_due_payments(), {1:40})

    groups={'1':Stage1,'2':Stage2,'3':Stage3}
    selected=list(groups.values()) if stage=='all' else [groups[str(stage)]]
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in selected)
