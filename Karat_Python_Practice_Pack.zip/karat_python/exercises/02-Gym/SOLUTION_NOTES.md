# Gym Membership and Workout Billing: solution notes

## Stage 1

The starter counts only GOLD. Include SILVER as well, and compute paid_count * 100.0 / member_count with the explicit empty case.

Provenance: Original paid-membership classification defect retained from the source question.

## Source corrections and adaptation decisions

- Both Java files count only GOLD as paid; the Python starter preserves this classification bug, and the solution counts SILVER and GOLD.
- Java percentage arithmetic uses integer division. Python uses true division to preserve fractional percentages; this language conversion removes a separate arithmetic defect.
- The Java billing solution calls Math.ceil(duration / 60) after integer division. Python computes ceiling hours correctly, following the prompt.
- The Java main method does not call the supplied billing test. The Python suite executes that test in Stage 3. Unused redundant workout collections were removed.

## Tests

Retained member construction, membership update/statistics, the source workout-average data, and all source billing data (BRONZE 50, SILVER 32, GOLD 6). Strengthened unknown-member exclusion and no-workout behavior. Added fractional percentages, empty state, zero duration, and 1/60/61-minute rounding boundaries.

## Complexity

For M members and W workouts, statistics take O(M). add_workout scans members in O(M). Averages take O(W) time and O(M) output space. Billing takes O(M + sum(W_i log W_i)) time, where W_i is a member's workout count; sorted copies avoid changing recorded insertion order.

## Source

[Question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/02-Gym/GymProblem.txt) | [Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/02-Gym/Solution.java)
