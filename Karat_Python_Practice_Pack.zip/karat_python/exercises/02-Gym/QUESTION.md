# 02. Gym Membership and Workout Billing

Manage membership levels, summarize workouts, and calculate tier-based charges after free workouts.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/02-Gym/GymProblem.txt).

This Python adaptation preserves the source tasks and separates the starter from the answer.

## Data model

- `MembershipStatus`: Enum: BRONZE, SILVER, GOLD
- `Member`: member_id: int, name: str, membership_status: MembershipStatus
- `Workout`: id: int, start_time: int, end_time: int; get_duration() returns minutes
- `MembershipStatistics`: total_members: int, total_paid_members: int, conversion_rate: float (percentage)

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug membership statistics

- Read the membership code and fix its statistics. SILVER and GOLD are paid memberships; BRONZE is not.
- Return total members, paid members, and the percentage of members on a paid tier. An empty gym returns (0, 0, 0.0). Existing add_member and update_membership behavior should remain usable.

Python methods:

```python
get_membership_statistics() -> MembershipStatistics
```

## Stage 2: Record workouts and average duration

- add_workout stores a workout for an existing member; ignore workouts for unknown member IDs.
- get_average_workout_durations maps each member with recorded workouts to their mean duration in minutes. All sessions are within the same day.

Python methods:

```python
add_workout(member_id: int, workout: Workout) -> None
get_average_workout_durations() -> dict[int, float]
```

## Stage 3: Calculate membership-tier charges

- Order each member's workouts by workout ID before deciding which are free.
- BRONZE: first 1 free, then $10/hour. SILVER: first 3 free, then $8/hour. GOLD: first 5 free, then $6/hour.
- Round each charged workout separately up to a whole hour. Return every member ID with their total, including zero for members with no workouts or no chargeable workouts.

Python methods:

```python
get_due_payments() -> dict[int, int]
```

## Examples

With five members on SILVER, BRONZE, GOLD, SILVER, BRONZE, the statistics are 5 total, 3 paid, and 60%. For BRONZE, a free first workout followed by 80-minute and 20-minute workouts costs $30.

## Clarifications

- Member IDs and workout IDs are unique as described in the source. Inputs have end_time >= start_time, in minutes within one day.
- Averages omit members with no workouts, matching the source implementation; payments include them with zero, as the source tests require.
- Unknown-member membership updates do nothing. Charges use the member's current tier. Rounding is per workout, not after combining durations.
- get_membership_statistics returns a percentage (0 through 100), not a fraction.
