from dataclasses import dataclass
from enum import IntEnum

class AccessLevel(IntEnum):
    VISITOR=1
    STAFF=2
    ADMIN=3

@dataclass
class User:
    user_id: int
    name: str
    access_level: AccessLevel

@dataclass
class AccessEvent:
    id: int
    entry_time: int
    exit_time: int

class AccessManager:
    def __init__(self):
        self.users: list[User] = []
        self.events: dict[int, list[AccessEvent]] = {}

    def add_user(self, user: User) -> None:
        self.users.append(user)

    def update_access_level(self, user_id: int, access_level: AccessLevel) -> None:
        for user in self.users:
            if user.user_id == user_id:
                user.access_level = access_level
                break

    def is_authorized(self, user_id: int, required_level: AccessLevel) -> bool:
        for user in self.users:
            if user.user_id == user_id:
                return user.access_level >= required_level
        return False

    def log_access(self, user_id: int, event: AccessEvent) -> bool:
        if any(user.user_id == user_id for user in self.users):
            self.events.setdefault(user_id, []).append(event)
            return True
        return False

    def get_after_hours_users(self) -> list[int]:
        return sorted(user_id for user_id, events in self.events.items()
                      if any(event.entry_time < 480 or event.exit_time > 1200 for event in events))
