# 04. Campus Access Control

Authorize campus users according to an access hierarchy, record access sessions, and identify users present outside opening hours.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/04-Campus/CampusProblem.txt).

Provenance: source files contain solved code and tests, without numbered question prose. This adaptation turns those behaviors into three practice stages and restores the commented authorization regression.

## Data model

- `AccessLevel`: IntEnum: VISITOR=1, STAFF=2, ADMIN=3
- `User`: user_id: int, name: str, access_level: AccessLevel
- `AccessEvent`: id: int, entry_time: int, exit_time: int (minutes since start of day)

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug hierarchical authorization

- A registered user is authorized for their own access level and any lower level. An unknown user is never authorized.
- Fix is_authorized while preserving add_user and update_access_level. Unknown-user updates do nothing.

Python methods:

```python
is_authorized(user_id: int, required_level: AccessLevel) -> bool
```

## Stage 2: Record access sessions

- log_access stores an event for a known user and returns True. For an unknown user, return False without storing the event.

Python methods:

```python
log_access(user_id: int, event: AccessEvent) -> bool
```

## Stage 3: Find after-hours visitors

- Return ascending user IDs with at least one event entering before minute 480 or exiting after minute 1200.
- The exact opening and closing boundaries are within hours. Include each qualifying user once; omit users with no qualifying event.

Python methods:

```python
get_after_hours_users() -> list[int]
```

## Examples

ADMIN can access VISITOR, STAFF, and ADMIN requirements. STAFF cannot access ADMIN. Events at [480,1200] are within hours; [479,480] and [1200,1201] are outside hours.

## Clarifications

- Events occur within one day and have entry_time <= exit_time; IDs are unique.
- Access logging only checks whether the user exists. It does not require a particular access level.
- The source does not provide numbered narrative stages. The three-stage grouping here is reconstructed from its authorization, logging, and after-hours tests.
