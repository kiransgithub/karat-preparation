# Campus Access Control: solution notes

## Stage 1

Equality is too restrictive for hierarchical access. Compare the user's rank with the requested rank using >=.

Provenance: Reconstructed from the commented equality-only implementation and source lower-level authorization tests.

## Source corrections and adaptation decisions

- Both published files contain completed implementations rather than unsolved question text.
- The authorization starter restores the equality-only implementation left as a comment in the source.
- Narrative requirements and the three-stage structure are reconstructed from code comments and tests; they are not claimed as an original numbered prompt.

## Tests

Preserved every source scenario for user fields, authorization, access logging, and after-hours users. Grouped all hierarchy regressions into one Stage 1 test. Added an update check, stored-event assertions, no-user rejection, repeated after-hours sessions, and exact/adjacent opening-hour boundaries.

## Complexity

With U users and E access events, authorization, user updates, and logging take O(U) time in the source-style user list. After-hours collection takes O(E + Q log Q), where Q is the number of qualifying users, plus O(Q) output space.

## Source

[Question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/04-Campus/CampusProblem.txt) | [Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/04-Campus/Solution.java)
