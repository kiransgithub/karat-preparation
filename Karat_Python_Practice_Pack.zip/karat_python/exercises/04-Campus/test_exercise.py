import unittest

def build_suite(M, stage="all"):
    L=M.AccessLevel

    def manager():
        m=M.AccessManager()
        for i,level in [(1,L.VISITOR),(2,L.STAFF),(3,L.ADMIN)]:
            m.add_user(M.User(i,str(i),level))
        return m

    class Stage1(unittest.TestCase):
        def test_source_user(self):
            user=M.User(1,'John Doe',L.VISITOR)
            self.assertEqual((user.user_id,user.name,user.access_level),(1,'John Doe',L.VISITOR))

        def test_source_own_level_denials_and_unknown(self):
            m=manager()
            for i,level in [(1,L.VISITOR),(2,L.STAFF),(3,L.ADMIN)]:
                self.assertTrue(m.is_authorized(i,level))
            self.assertFalse(m.is_authorized(1,L.STAFF))
            self.assertFalse(m.is_authorized(2,L.ADMIN))
            self.assertFalse(m.is_authorized(999,L.VISITOR))
            m.update_access_level(1,L.STAFF)
            self.assertTrue(m.is_authorized(1,L.STAFF))

        def test_source_regression(self):
            m=manager()
            self.assertTrue(m.is_authorized(2,L.VISITOR))
            self.assertTrue(m.is_authorized(3,L.VISITOR))
            self.assertTrue(m.is_authorized(3,L.STAFF))  # Added hierarchy edge.

    class Stage2(unittest.TestCase):
        def test_source_log_access(self):
            m=M.AccessManager()
            m.add_user(M.User(12,'John',L.STAFF))
            m.add_user(M.User(22,'Alex',L.VISITOR))
            self.assertTrue(m.log_access(12,M.AccessEvent(111,10,20)))
            self.assertTrue(m.log_access(22,M.AccessEvent(112,15,35)))
            self.assertTrue(m.log_access(12,M.AccessEvent(113,20,25)))
            self.assertFalse(m.log_access(404,M.AccessEvent(999,1,2)))
            self.assertEqual([e.id for e in m.events[12]],[111,113])
            self.assertNotIn(404,m.events)

        def test_empty_manager_rejects(self):
            m=M.AccessManager()
            self.assertFalse(m.log_access(1,M.AccessEvent(1,480,1200)))
            self.assertEqual(m.events,{})

    class Stage3(unittest.TestCase):
        def test_source_after_hours(self):
            m=M.AccessManager()
            for i,level in [(30,L.ADMIN),(10,L.STAFF),(50,L.VISITOR),(40,L.STAFF),(20,L.VISITOR)]:
                m.add_user(M.User(i,str(i),level))
            for user,row in [(30,(505,1150,1250)),(10,(501,400,450)),(10,(502,500,600)),
                             (20,(503,600,700)),(20,(504,800,1100)),(40,(506,480,1200))]:
                m.log_access(user,M.AccessEvent(*row))
            self.assertEqual(m.get_after_hours_users(),[10,30])
            m.log_access(10,M.AccessEvent(507,0,1))
            self.assertEqual(m.get_after_hours_users(),[10,30])  # Added uniqueness.

        def test_exact_and_adjacent_boundaries(self):
            m=manager()
            self.assertEqual(m.get_after_hours_users(),[])
            m.log_access(1,M.AccessEvent(1,480,1200))
            m.log_access(2,M.AccessEvent(2,479,480))
            m.log_access(3,M.AccessEvent(3,1200,1201))
            self.assertEqual(m.get_after_hours_users(),[2,3])

    groups={'1':Stage1,'2':Stage2,'3':Stage3}
    selected=list(groups.values()) if stage=='all' else [groups[str(stage)]]
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in selected)
