# Cloud Compute Reservations: solution notes

## Stage 1

The starter subtracts every reservation for a pool. Filter to ReservationStatus.ACTIVE before summing capacity; cancelled and expired records do not consume capacity.

Provenance: Reconstructed from the explicit bug comment in the published question.

## Source corrections and adaptation decisions

- The source question already contains the ACTIVE-status fix and a comment describing the prior bug. The Python starter removes that guard to restore the documented challenge.
- Stage 2 methods are absent from the Java question despite being called by tests. Python supplies explicit stubs.
- Preserved the source admission rule rather than adding status, duplicate-ID, or start-time restrictions.

## Tests

Translated all four source test scenarios: available capacity, admission, customer totals, and expiry. Added capacity equality, absent pools, empty state, an expired record, pool isolation, and repeated expiry. Stage 1 contains one regression test and one passing baseline test.

## Complexity

For R reservations, available-capacity lookup, admission, aggregation, and expiry each take O(R) time. Aggregation uses O(C) result space for C qualifying customers. Expiry mutates records in place with O(1) additional space. Pool insertion is expected O(1).

## Source

[Question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/01-CloudCompute/CloudComputeProblem.txt) | [Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/01-CloudCompute/Solution.java)
