# 01. Cloud Compute Reservations

Maintain compute pools and reservations, calculate remaining capacity, and expire reservations at a supplied time.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/01-CloudCompute/CloudComputeProblem.txt).

The published starter already contains a fix. This adaptation restores the previously missing check identified in the source comment so Stage 1 remains a debugging question.

## Data model

- `ReservationStatus`: Enum: ACTIVE, CANCELLED, EXPIRED
- `ComputePool`: pool_id: int, region: str, total_capacity: int
- `Reservation`: reservation_id: int, customer_id: int, pool_id: int, capacity_units: int, status: ReservationStatus, start_time: int, end_time: int

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug remaining capacity

- Read the existing manager and repair get_available_capacity. Capacity is the pool total minus the units in ACTIVE reservations for that pool.
- An unknown pool has zero available capacity; reservations in other pools must not affect the result.

Python methods:

```python
get_available_capacity(pool_id: int) -> int
```

## Stage 2: Add reservations and customer totals

- add_reservation stores the supplied reservation only when its pool exists and its capacity_units are no greater than that pool's currently available capacity. Otherwise ignore it.
- get_reserved_capacity_by_customer returns customer IDs mapped to the sum of their ACTIVE capacity units across pools. Omit customers with no ACTIVE reservations; return {} when none qualify.

Python methods:

```python
add_reservation(reservation: Reservation) -> None
get_reserved_capacity_by_customer() -> dict[int, int]
```

## Stage 3: Expire completed reservation windows

- Change ACTIVE reservations with end_time <= current_time to EXPIRED. Leave CANCELLED, already EXPIRED, and later-ending ACTIVE reservations unchanged.
- Return the number whose status changed. The changed records must stop consuming capacity.

Python methods:

```python
expire_reservations(current_time: int) -> int
```

## Examples

A pool of 100 units with an ACTIVE reservation of 30 and a CANCELLED reservation of 20 has 70 units available. Expiring two ACTIVE reservations ending at 900 and 1000 at current_time=1000 returns 2.

## Clarifications

- Times use the same integer unit. Capacity calculations depend on explicit status, not on the clock; expiry occurs when expire_reservations is called.
- Inputs use nonnegative capacity units and valid enum values. No extra deduplication or time-window validation is requested.
- The admission capacity check applies to every supplied reservation, regardless of its status, as written in the source prompt.
- add_compute_pool replaces a pool with the same ID, matching the source map behavior.
