import unittest

def build_suite(M, stage="all"):
    S = M.ReservationStatus

    def manager(capacity=100):
        result = M.ReservationManager()
        result.add_compute_pool(M.ComputePool(1, 'us-east', capacity))
        return result

    def reservation(i, customer, units, status=S.ACTIVE, end=2000, pool=1):
        return M.Reservation(i, customer, pool, units, status, 100, end)

    class Stage1(unittest.TestCase):
        def test_source_regression(self):
            m = manager()
            m.reservations.extend([reservation(101, 1001, 30), reservation(102, 1002, 20, S.CANCELLED)])
            self.assertEqual(m.get_available_capacity(1), 70)
            self.assertEqual(m.get_available_capacity(99), 0)
            # Added: another non-consuming state and another pool.
            m.reservations.extend([reservation(103, 1003, 10, S.EXPIRED), reservation(104, 1004, 50, pool=2)])
            self.assertEqual(m.get_available_capacity(1), 70)

        def test_empty_and_active_only(self):
            m = manager()
            self.assertEqual(m.get_available_capacity(1), 100)
            self.assertEqual(m.get_available_capacity(99), 0)
            m.reservations.append(reservation(1, 1, 40))
            self.assertEqual(m.get_available_capacity(1), 60)

    class Stage2(unittest.TestCase):
        def test_source_add_reservation(self):
            m = manager()
            m.reservations.append(reservation(201, 1001, 50, S.CANCELLED))
            m.add_reservation(reservation(202, 1002, 30))
            m.reservations.append(reservation(203, 1003, 40, S.EXPIRED))
            m.add_reservation(reservation(204, 1004, 60))
            m.add_reservation(reservation(205, 1005, 20, pool=99))
            m.add_reservation(reservation(206, 1006, 50))
            self.assertEqual(len(m.reservations), 4)
            self.assertEqual(m.reservations[3].reservation_id, 204)

        def test_source_customer_totals(self):
            m = manager(200)
            for r in [reservation(301, 1001, 30), reservation(302, 1001, 20),
                      reservation(303, 1002, 10), reservation(304, 1003, 50, S.CANCELLED)]:
                m.add_reservation(r)
            self.assertEqual(m.get_reserved_capacity_by_customer(), {1001: 50, 1002: 10})

        def test_capacity_equality_and_empty_totals(self):
            # Added boundary checks.
            m = manager()
            self.assertEqual(m.get_reserved_capacity_by_customer(), {})
            m.add_reservation(reservation(1, 1, 100))
            m.add_reservation(reservation(2, 2, 1))
            self.assertEqual(len(m.reservations), 1)
            self.assertEqual(m.get_available_capacity(1), 0)

    class Stage3(unittest.TestCase):
        def test_source_expiration(self):
            m = manager(500)
            for r in [reservation(401, 1001, 10, end=1000), reservation(402, 1002, 20, end=900),
                      reservation(403, 1003, 30, end=1100), reservation(404, 1004, 40, S.CANCELLED, 800),
                      reservation(405, 1005, 50, S.EXPIRED, 700)]:
                m.add_reservation(r)
            self.assertEqual(m.expire_reservations(1000), 2)
            self.assertEqual([r.status for r in m.reservations], [S.EXPIRED, S.EXPIRED, S.ACTIVE, S.CANCELLED, S.EXPIRED])
            self.assertEqual(m.get_available_capacity(1), 470)
            self.assertEqual(m.expire_reservations(1000), 0)  # Added idempotence.

        def test_empty_expiration(self):
            self.assertEqual(manager().expire_reservations(1000), 0)

    groups = {'1': Stage1, '2': Stage2, '3': Stage3}
    selected = list(groups.values()) if stage == 'all' else [groups[str(stage)]]
    return unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in selected)
