from dataclasses import dataclass
from enum import Enum

class ReservationStatus(Enum):
    ACTIVE = 'ACTIVE'
    CANCELLED = 'CANCELLED'
    EXPIRED = 'EXPIRED'

@dataclass
class ComputePool:
    pool_id: int
    region: str
    total_capacity: int

@dataclass
class Reservation:
    reservation_id: int
    customer_id: int
    pool_id: int
    capacity_units: int
    status: ReservationStatus
    start_time: int
    end_time: int

class ReservationManager:
    def __init__(self):
        self.compute_pools: dict[int, ComputePool] = {}
        self.reservations: list[Reservation] = []

    def add_compute_pool(self, compute_pool: ComputePool) -> None:
        self.compute_pools[compute_pool.pool_id] = compute_pool

    def get_available_capacity(self, pool_id: int) -> int:
        pool = self.compute_pools.get(pool_id)
        if pool is None:
            return 0
        used = sum(r.capacity_units for r in self.reservations
                   if r.pool_id == pool_id)
        return pool.total_capacity - used

    def add_reservation(self, reservation: Reservation) -> None:
        raise NotImplementedError("Implement Stage 2.")

    def get_reserved_capacity_by_customer(self) -> dict[int, int]:
        raise NotImplementedError("Implement Stage 2.")

    def expire_reservations(self, current_time: int) -> int:
        raise NotImplementedError("Implement Stage 3.")
