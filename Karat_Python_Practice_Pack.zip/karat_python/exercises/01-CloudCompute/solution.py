from dataclasses import dataclass
from enum import Enum

class ReservationStatus(Enum):
    ACTIVE = 'ACTIVE'
    CANCELLED = 'CANCELLED'
    EXPIRED = 'EXPIRED'

@dataclass
class ComputePool:
    pool_id: int
    region: str
    total_capacity: int

@dataclass
class Reservation:
    reservation_id: int
    customer_id: int
    pool_id: int
    capacity_units: int
    status: ReservationStatus
    start_time: int
    end_time: int

class ReservationManager:
    def __init__(self):
        self.compute_pools: dict[int, ComputePool] = {}
        self.reservations: list[Reservation] = []

    def add_compute_pool(self, compute_pool: ComputePool) -> None:
        self.compute_pools[compute_pool.pool_id] = compute_pool

    def get_available_capacity(self, pool_id: int) -> int:
        pool = self.compute_pools.get(pool_id)
        if pool is None:
            return 0
        used = sum(r.capacity_units for r in self.reservations
                   if r.pool_id == pool_id and r.status is ReservationStatus.ACTIVE)
        return pool.total_capacity - used

    def add_reservation(self, reservation: Reservation) -> None:
        if (reservation.pool_id in self.compute_pools and
                reservation.capacity_units <= self.get_available_capacity(reservation.pool_id)):
            self.reservations.append(reservation)

    def get_reserved_capacity_by_customer(self) -> dict[int, int]:
        totals: dict[int, int] = {}
        for reservation in self.reservations:
            if reservation.status is ReservationStatus.ACTIVE:
                key = reservation.customer_id
                totals[key] = totals.get(key, 0) + reservation.capacity_units
        return totals

    def expire_reservations(self, current_time: int) -> int:
        changed = 0
        for reservation in self.reservations:
            if reservation.status is ReservationStatus.ACTIVE and reservation.end_time <= current_time:
                reservation.status = ReservationStatus.EXPIRED
                changed += 1
        return changed
