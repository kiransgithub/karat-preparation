from dataclasses import dataclass
from enum import Enum

class Outcome(Enum):
    WIN = 'WIN'
    LOSS = 'LOSS'
    DRAW = 'DRAW'

@dataclass
class Player:
    player_id: int
    username: str

@dataclass
class MatchResult:
    player_id: int
    opponent_id: int
    outcome: Outcome
    score: int
    timestamp: int

@dataclass
class PlayerStats:
    total_matches: int
    wins: int
    win_rate: float

@dataclass
class HeadToHead:
    wins_player1: int
    wins_player2: int
    draws: int
    total_matches: int
    last_result: Outcome | None
    last_match_timestamp: int | None

class GameManager:
    def __init__(self):
        self.players: dict[int, Player] = {}
        self.match_results: list[MatchResult] = []

    def add_player(self, player: Player) -> None:
        self.players[player.player_id] = player

    def get_player_statistics(self, player_id: int) -> PlayerStats:
        matches = [m for m in self.match_results if m.player_id == player_id]
        total = len(matches)
        wins = sum(m.outcome is Outcome.WIN for m in matches)
        return PlayerStats(total, wins, wins / total if total else 0.0)

    def add_match_result(self, result: MatchResult) -> None:
        if result.player_id in self.players:
            self.match_results.append(result)

    def get_average_score_by_outcome(self, player_id: int) -> dict[Outcome, float]:
        scores: dict[Outcome, list[int]] = {}
        for result in self.match_results:
            if result.player_id == player_id:
                scores.setdefault(result.outcome, []).append(result.score)
        return {outcome: sum(values) / len(values) for outcome, values in scores.items()}

    def get_head_to_head(self, player1_id: int, player2_id: int) -> HeadToHead:
        matches = [m for m in self.match_results
                   if m.player_id == player1_id and m.opponent_id == player2_id]
        if not matches:
            return HeadToHead(0, 0, 0, 0, None, None)
        latest = max(enumerate(matches), key=lambda item: (item[1].timestamp, item[0]))[1]
        return HeadToHead(
            sum(m.outcome is Outcome.WIN for m in matches),
            sum(m.outcome is Outcome.LOSS for m in matches),
            sum(m.outcome is Outcome.DRAW for m in matches),
            len(matches), latest.outcome, latest.timestamp)

    def get_recent_form(self, n: int) -> list[list[int]]:
        if n <= 0:
            return []
        histories: dict[int, list[MatchResult]] = {pid: [] for pid in self.players}
        for result in self.match_results:
            if result.player_id in histories:
                histories[result.player_id].append(result)
        points = {Outcome.WIN: 3, Outcome.DRAW: 1, Outcome.LOSS: 0}
        result = []
        for pid, history in histories.items():
            if len(history) >= n:
                recent = sorted(history, key=lambda m: m.timestamp)[-n:]
                result.append([pid, sum(points[m.outcome] for m in recent)])
        return sorted(result, key=lambda row: (-row[1], row[0]))
