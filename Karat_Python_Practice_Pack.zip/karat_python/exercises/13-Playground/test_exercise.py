import unittest

def build_suite(implementation, stage='all'):
    M = implementation
    def manager(*ids):
        gm = M.GameManager()
        for pid in ids:
            gm.add_player(M.Player(pid, f'player{pid}'))
        return gm

    class Stage1(unittest.TestCase):
        def test_source_regression_all_outcomes(self):
            gm = manager(1, 2)
            for outcome, score, time in [('WIN',80,1000),('LOSS',50,2000),('DRAW',60,3000),('WIN',90,4000)]:
                gm.match_results.append(M.MatchResult(1,2,M.Outcome[outcome],score,time))
            stats = gm.get_player_statistics(1)
            self.assertEqual((stats.total_matches, stats.wins), (4,2))
            self.assertAlmostEqual(stats.win_rate, 0.5)
            gm.match_results += [M.MatchResult(2,1,M.Outcome.DRAW,60,t) for t in (1000,2000)]
            self.assertEqual(gm.get_player_statistics(2), M.PlayerStats(2,0,0.0))

        # Added edges: no observations and a history consisting only of wins.
        def test_empty_history(self):
            self.assertEqual(manager(1).get_player_statistics(1), M.PlayerStats(0,0,0.0))

        def test_only_wins(self):
            gm = manager(1)
            gm.match_results.append(M.MatchResult(1,2,M.Outcome.WIN,80,10))
            self.assertEqual(gm.get_player_statistics(1), M.PlayerStats(1,1,1.0))

    class Stage2(unittest.TestCase):
        def test_source_add_result(self):
            gm = manager(1,2)
            gm.add_match_result(M.MatchResult(1,2,M.Outcome.WIN,80,1000))
            gm.add_match_result(M.MatchResult(2,1,M.Outcome.LOSS,50,1000))
            gm.add_match_result(M.MatchResult(99,1,M.Outcome.WIN,100,2000))
            self.assertEqual(len(gm.match_results),2)

        def test_source_average_scores(self):
            gm = manager(1,2,3)
            rows = [(1,2,'WIN',80,1000),(2,1,'LOSS',50,1000),
                    (1,2,'WIN',90,2000),(2,1,'LOSS',60,2000),
                    (1,2,'DRAW',70,3000),(2,1,'DRAW',70,3000)]
            for p,o,r,s,t in rows:
                gm.add_match_result(M.MatchResult(p,o,M.Outcome[r],s,t))
            self.assertEqual(gm.get_average_score_by_outcome(1),{M.Outcome.WIN:85.0,M.Outcome.DRAW:70.0})
            self.assertEqual(gm.get_average_score_by_outcome(2),{M.Outcome.LOSS:55.0,M.Outcome.DRAW:70.0})
            self.assertEqual(gm.get_average_score_by_outcome(3),{})

        # Added edge: the source only requires the owner, not the opponent, to exist.
        def test_unknown_opponent_is_allowed(self):
            gm = manager(1)
            gm.add_match_result(M.MatchResult(1,999,M.Outcome.WIN,7,0))
            self.assertEqual(gm.get_average_score_by_outcome(1),{M.Outcome.WIN:7.0})

    class Stage3(unittest.TestCase):
        def test_source_head_to_head(self):
            gm = manager(1,2,3)
            for t,a,b in [(1000,'WIN','LOSS'),(2000,'LOSS','WIN'),(3000,'DRAW','DRAW'),(4000,'WIN','LOSS')]:
                gm.add_match_result(M.MatchResult(1,2,M.Outcome[a],80,t))
                gm.add_match_result(M.MatchResult(2,1,M.Outcome[b],60,t))
            self.assertEqual(gm.get_head_to_head(1,2),M.HeadToHead(2,1,1,4,M.Outcome.WIN,4000))
            self.assertEqual(gm.get_head_to_head(2,1),M.HeadToHead(1,2,1,4,M.Outcome.LOSS,4000))
            self.assertEqual(gm.get_head_to_head(1,3),M.HeadToHead(0,0,0,0,None,None))

        # Added edge: out-of-order arrival and a genuine timestamp zero.
        def test_latest_timestamp_and_read_only_query(self):
            gm = manager(1,2)
            gm.add_match_result(M.MatchResult(1,2,M.Outcome.WIN,8,20))
            gm.add_match_result(M.MatchResult(1,2,M.Outcome.LOSS,3,0))
            before = list(gm.match_results)
            self.assertEqual(gm.get_head_to_head(1,2).last_match_timestamp,20)
            self.assertEqual(gm.match_results,before)
            self.assertIsNone(gm.get_head_to_head(2,1).last_match_timestamp)

    class Stage4(unittest.TestCase):
        def test_source_recent_form_case1(self):
            gm = manager(1,2,3,4)
            histories = {1:[('WIN',1000),('WIN',2000),('WIN',3000)],
                         2:[('WIN',1000),('DRAW',2000),('LOSS',3000)],
                         3:[('LOSS',1000),('WIN',3000),('DRAW',500),('LOSS',2000)],
                         4:[('WIN',1000),('WIN',2000)]}
            for pid, rows in histories.items():
                for outcome,t in rows:
                    gm.add_match_result(M.MatchResult(pid,99,M.Outcome[outcome],80,t))
            self.assertEqual(gm.get_recent_form(3),[[1,9],[2,4],[3,3]])
            self.assertEqual(gm.get_recent_form(0),[])

        def test_source_recent_form_case2(self):
            gm = manager(2,1,3,4)
            for pid,times,outcome in [(1,[500,1000,2000,3000],'WIN'),(2,[1000,2000,3000],'WIN'),(3,[1000,2000],'WIN'),(4,[1000,2000,3000],'LOSS')]:
                for t in times:
                    gm.add_match_result(M.MatchResult(pid,99,M.Outcome[outcome],80,t))
            self.assertEqual(gm.get_recent_form(3),[[1,9],[2,9],[4,0]])

        # Added edges: negative n, empty manager, and no qualifying history.
        def test_nonpositive_and_insufficient(self):
            gm = manager(1)
            self.assertEqual(gm.get_recent_form(-2),[])
            self.assertEqual(gm.get_recent_form(1),[])
            self.assertEqual(manager().get_recent_form(2),[])

    classes = {'1': Stage1, '2': Stage2, '3': Stage3, '4': Stage4}
    chosen = classes if stage == "all" else {str(stage): classes[str(stage)]}
    suite = unittest.TestSuite()
    for case in chosen.values():
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
