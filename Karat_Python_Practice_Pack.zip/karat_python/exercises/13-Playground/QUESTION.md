# 13. Player Statistics, Head-to-Head Results, and Recent Form

Maintain player records and per-player match observations, then answer statistics and ranking queries. A match may have a separate observation for each participant.

## Data model

- **Outcome**: `WIN, LOSS, DRAW`
- **Player**: `player_id: int, username: str`
- **MatchResult**: `player_id: int, opponent_id: int, outcome: Outcome, score: int, timestamp: int`
- **PlayerStats**: `total_matches: int, wins: int, win_rate: float`
- **HeadToHead**: `wins_player1: int, wins_player2: int, draws: int, total_matches: int, last_result: Outcome | None, last_match_timestamp: int | None`

## Stage 1: Repair player statistics

- Read the supplied models and GameManager implementation, then diagnose its failing test.
- Return the number of all results belonging to the requested player, the number of wins, and wins divided by total matches. A player with no results has zero counts and a rate of 0.0.

Python methods:

- `get_player_statistics(player_id: int) -> PlayerStats`

## Stage 2: Record results and average scores

- Store a result only if its player_id is registered. Ignore unknown players.
- For one player, return an Outcome-to-average-score dictionary containing only outcomes that actually occur. Return {} when the player has no results.

Python methods:

- `add_match_result(result: MatchResult) -> None`
- `get_average_score_by_outcome(player_id: int) -> dict[Outcome, float]`

## Stage 3: Summarize two opponents

- Return counts of player 1 wins, player 2 wins, draws, and total matches between the two players.
- Include the latest result from player 1's perspective and its timestamp. With no matching history, all counts are zero and both latest fields are None.

Python methods:

- `get_head_to_head(player1_id: int, player2_id: int) -> HeadToHead`

## Stage 4: Rank recent form

- For each registered player with at least n results, select the n most recent results by timestamp. Score WIN as 3, DRAW as 1, and LOSS as 0.
- Return [player_id, form_points] pairs sorted by points descending, then player ID ascending. Return [] when n <= 0.

Python methods:

- `get_recent_form(n: int) -> list[list[int]]`

## Examples

- Outcomes WIN, LOSS, DRAW, WIN produce `PlayerStats(4, 2, 0.5)`.
- Scores 80 and 90 for WIN and 70 for DRAW produce `{Outcome.WIN: 85.0, Outcome.DRAW: 70.0}`.
- For `n=3`, recent outcomes WIN/WIN/WIN earn 9 points; WIN/DRAW/LOSS earn 4.

## Clarifications

- Results are stored from one player's perspective. Head-to-head queries use player 1's records against player 2; reciprocal records must not be counted a second time.
- Only player_id must be registered when adding a result; opponent_id is not validated by the source contract.
- Timestamps determine recency, not arrival order. For equal timestamps, insertion order resolves the tie, with later insertion considered later.
- Outcome averages and win rates are fractions/float values, not percentages. Existing add_player replaces the same player ID as in the source.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/13-Playground/PlaygroundProblem.txt)
