# 13. Solution notes

## Debugging task

Restored from the commented-out WIN-only condition in the original problem file.

The starter counts only wins as total matches. Count every observation for the player, while retaining the separate win count and zero-denominator handling.

## Source adjustments

- The source problem already comments out the original WIN-only total-matches filter. The starter restores that documented fault.
- The Java head-to-head answer returns timestamp 0 for an empty history, contrary to its None/null requirement. The Python answer returns None.
- The Java recent-form answer lacks the required final sorting and n <= 0 handling. Both are implemented according to the prose contract.
- Head-to-head selection in the source is directional; the Python question states this explicitly to avoid double-counting reciprocal observations.

## Verification and complexity
All six original named test scenarios are represented; the two recent-form scenarios remain separate. Added checks cover empty/win-only histories, an unknown opponent, out-of-order observations, query non-mutation, and nonpositive n.

For M match records and P players: statistics, outcome averages, and head-to-head are O(M) time. Recent form groups in O(M), sorts each history in O(sum(m_p log m_p)), and ranks at most P players in O(P log P). Storage is O(M + P). None of the query methods changes the stored match order.

[Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/13-Playground/Solution.java)
