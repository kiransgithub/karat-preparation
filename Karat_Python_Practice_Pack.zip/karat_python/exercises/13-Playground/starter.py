from dataclasses import dataclass
from enum import Enum

class Outcome(Enum):
    WIN = 'WIN'
    LOSS = 'LOSS'
    DRAW = 'DRAW'

@dataclass
class Player:
    player_id: int
    username: str

@dataclass
class MatchResult:
    player_id: int
    opponent_id: int
    outcome: Outcome
    score: int
    timestamp: int

@dataclass
class PlayerStats:
    total_matches: int
    wins: int
    win_rate: float

@dataclass
class HeadToHead:
    wins_player1: int
    wins_player2: int
    draws: int
    total_matches: int
    last_result: Outcome | None
    last_match_timestamp: int | None

class GameManager:
    def __init__(self):
        self.players: dict[int, Player] = {}
        self.match_results: list[MatchResult] = []

    def add_player(self, player: Player) -> None:
        self.players[player.player_id] = player

    def get_player_statistics(self, player_id: int) -> PlayerStats:
        matches = [m for m in self.match_results if m.player_id == player_id]
        total = sum(m.outcome is Outcome.WIN for m in matches)
        wins = sum(m.outcome is Outcome.WIN for m in matches)
        return PlayerStats(total, wins, wins / total if total else 0.0)

    def add_match_result(self, result: MatchResult) -> None:
        raise NotImplementedError("Implement this stage.")

    def get_average_score_by_outcome(self, player_id: int) -> dict[Outcome, float]:
        raise NotImplementedError("Implement this stage.")

    def get_head_to_head(self, player1_id: int, player2_id: int) -> HeadToHead:
        raise NotImplementedError("Implement this stage.")

    def get_recent_form(self, n: int) -> list[list[int]]:
        raise NotImplementedError("Implement this stage.")
