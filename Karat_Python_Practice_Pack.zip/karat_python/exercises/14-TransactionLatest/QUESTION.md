# 14. Banking Compliance Queries

Store the day's financial events and provide account-level and high-value transaction queries. This is the repository's latest transaction variant, with two stages.

## Data model

- **TransactionType**: `DEPOSIT, WITHDRAWAL, TRANSFER`
- **Transaction**: `transaction_id: int, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int`

## Stage 1: Repair account filtering

- Read the supplied ComplianceMonitor and fix the failed account-query test.
- Return every transaction ID belonging to the requested account in ascending ID order. Return [] when no transaction belongs to that account. Preserve existing registration and ID lookup behavior.

Python methods:

- `get_transactions_for_account(account_id: int) -> list[int]`

## Stage 2: High-value activity and account totals

- Return IDs whose amounts are at least threshold, sorted by amount descending and transaction ID ascending for equal amounts. Return [] when none qualify.
- Return an account summary with total_transactions and total_amount. Include every transaction type and use zero for both values when the account has no records.

Python methods:

- `get_high_value_transactions(threshold: float) -> list[int]`
- `get_account_summary(account_id: int) -> dict[str, int | float]`

## Examples

For transactions `(1, account=100, amount=5000)`, `(2, account=100, amount=15000)`, and `(3, account=200, amount=5000)`:

- `get_transactions_for_account(100)` returns `[1, 2]`.
- `get_high_value_transactions(5000)` returns `[2, 1, 3]`.
- `get_account_summary(100)` returns `{"total_transactions": 2, "total_amount": 20000.0}`.

## Clarifications

- Timestamps are minutes since the start of the day. Amounts retain the Java double representation as Python float; compare calculated amounts with a tolerance.
- The summary adds recorded amounts across all transaction types. It is an activity total, not a signed account balance.
- add_transaction appends records; no extra ID deduplication or account validation is introduced. get_transaction returns the first matching record, or None.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/14-TransactionLatest/TransactionLatestProblem.txt)
