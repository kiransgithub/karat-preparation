from dataclasses import dataclass
from enum import Enum

class TransactionType(Enum):
    DEPOSIT = 'DEPOSIT'
    WITHDRAWAL = 'WITHDRAWAL'
    TRANSFER = 'TRANSFER'

@dataclass(frozen=True)
class Transaction:
    transaction_id: int
    account_id: int
    amount: float
    transaction_type: TransactionType
    timestamp: int

class ComplianceMonitor:
    def __init__(self):
        self.transactions: list[Transaction] = []

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def get_transaction(self, transaction_id: int) -> Transaction | None:
        return next((t for t in self.transactions if t.transaction_id == transaction_id), None)

    def get_transactions_for_account(self, account_id: int) -> list[int]:
        return sorted(t.transaction_id for t in self.transactions if t.transaction_id == account_id)

    def get_high_value_transactions(self, threshold: float) -> list[int]:
        raise NotImplementedError("Implement this stage.")

    def get_account_summary(self, account_id: int) -> dict[str, int | float]:
        raise NotImplementedError("Implement this stage.")
