import unittest

def build_suite(implementation, stage='all'):
    M = implementation
    def load(rows):
        monitor = M.ComplianceMonitor()
        for tid,aid,amount,kind,time in rows:
            monitor.add_transaction(M.Transaction(tid,aid,amount,M.TransactionType[kind],time))
        return monitor

    class Stage1(unittest.TestCase):
        def test_source_transaction_model(self):
            t = M.Transaction(1,100,5000.0,M.TransactionType.DEPOSIT,480)
            self.assertEqual((t.transaction_id,t.account_id,t.transaction_type,t.timestamp),(1,100,M.TransactionType.DEPOSIT,480))
            self.assertAlmostEqual(t.amount,5000.0)

        def test_source_account_filter_regression(self):
            monitor = load([(1,100,5000,'DEPOSIT',480),(2,200,3000,'WITHDRAWAL',490),
                            (3,100,1500,'TRANSFER',500),(4,200,7500,'DEPOSIT',510),(5,100,2000,'DEPOSIT',520)])
            self.assertEqual(monitor.get_transactions_for_account(100),[1,3,5])
            self.assertEqual(monitor.get_transactions_for_account(200),[2,4])
            self.assertEqual(monitor.get_transactions_for_account(999),[])
            # Added edge: ID sorting must not depend on insertion order.
            monitor.transactions.reverse()
            self.assertEqual(monitor.get_transactions_for_account(100),[1,3,5])

        # Added checks for the existing lookup and an empty account query.
        def test_existing_lookup(self):
            monitor = load([(2,100,4,'TRANSFER',10)])
            self.assertEqual(monitor.get_transaction(2),monitor.transactions[0])
            self.assertIsNone(monitor.get_transaction(99))

        def test_empty(self):
            self.assertEqual(M.ComplianceMonitor().get_transactions_for_account(7),[])

    class Stage2(unittest.TestCase):
        def test_source_high_value(self):
            monitor = load([(3,200,5000,'WITHDRAWAL',510),(2,100,15000,'DEPOSIT',500),
                            (1,100,5000,'DEPOSIT',480),(4,300,200,'TRANSFER',520),(5,200,10000,'DEPOSIT',530)])
            self.assertEqual(monitor.get_high_value_transactions(5000),[2,5,1,3])
            self.assertEqual(monitor.get_high_value_transactions(10000),[2,5])
            self.assertEqual(monitor.get_high_value_transactions(50000),[])
            self.assertEqual(monitor.get_high_value_transactions(200),[2,5,1,3,4])

        def test_source_account_summary(self):
            monitor = load([(1,100,5000,'DEPOSIT',480),(2,100,15000,'DEPOSIT',500),(3,200,3000,'WITHDRAWAL',510)])
            self.assertEqual(monitor.get_account_summary(100),{'total_transactions':2,'total_amount':20000.0})
            self.assertEqual(monitor.get_account_summary(200),{'total_transactions':1,'total_amount':3000.0})
            self.assertEqual(monitor.get_account_summary(999),{'total_transactions':0,'total_amount':0.0})

        # Added edge: fractional values, exact threshold, and all transaction types.
        def test_fractional_amounts_and_empty(self):
            monitor = load([(9,10,0.1,'DEPOSIT',0),(2,10,0.2,'WITHDRAWAL',1),(4,10,0.1,'TRANSFER',2)])
            self.assertEqual(monitor.get_high_value_transactions(0.1),[2,4,9])
            summary = monitor.get_account_summary(10)
            self.assertEqual(summary['total_transactions'],3)
            self.assertAlmostEqual(summary['total_amount'],0.4)
            self.assertEqual(M.ComplianceMonitor().get_high_value_transactions(0),[])

    classes = {'1': Stage1, '2': Stage2}
    chosen = classes if stage == "all" else {str(stage): classes[str(stage)]}
    suite = unittest.TestSuite()
    for case in chosen.values():
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
