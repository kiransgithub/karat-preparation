# 14. Solution notes

## Debugging task

Added practice regression because the source Stage 1 implementation is already corrected; it is not claimed to be the original interview fault.

The filter compares transaction_id with account_id. Select records using their account_id, then return sorted transaction IDs.

## Source adjustments

- The checked-in problem already contains a correct Stage 1 account query. Its original fault is not recoverable from the repository.
- To supply the requested debugging experience, the Python starter includes an added practice regression comparing the transaction ID to the requested account ID. The existing source account-filtering test detects it.
- There are only two source stages; no third-stage problem has been invented.

## Verification and complexity
All four original test scenarios are translated. Added checks cover reversed insertion order, the existing lookup, empty input, fractional amounts, and the inclusive threshold.

For T transactions and K matching records, account ID listing and high-value listing take O(T + K log K) time and O(K) space. Account summary and lookup take O(T) time. Registration appends in amortized O(1). Python dataclass value equality preserves the source Transaction equality contract.

[Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/14-TransactionLatest/Solution.java)
