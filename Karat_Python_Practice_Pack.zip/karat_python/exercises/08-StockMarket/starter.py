"""Python adaptation of the stock-market exercise; see QUESTION.md."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Stock:
    symbol: str
    name: str

@dataclass
class PriceRecord:
    stock: Stock
    price: int
    date: str

class StockCollection:

    def __init__(self, stock: Stock):
        self.stock = stock
        self.price_records: list[PriceRecord] = []

    def add_price_record(self, record: PriceRecord) -> None:
        if record.stock != self.stock:
            raise ValueError('Stock mismatch')
        self.price_records.append(record)

    def get_num_price_records(self) -> int:
        return len(self.price_records)

    def get_max_price(self) -> int:
        return max((r.price for r in self.price_records), default=-1)

    def get_min_price(self) -> int:
        return min((r.price for r in self.price_records), default=-1)

    def get_avg_price(self) -> float:
        if not self.price_records:
            return -1.0
        return sum((r.price for r in self.price_records)) // len(self.price_records)

    def get_biggest_change(self) -> list[int | str] | None:
        raise NotImplementedError('Implement this stage of the exercise.')

@dataclass
class Transaction:
    stock: Stock
    transaction_type: str
    date: str
    quantity: int

class Tradebook:

    def __init__(self):
        self.transactions: list[Transaction] = []

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def get_total(self, stock_collections: list[StockCollection]) -> int:
        raise NotImplementedError('Implement this stage of the exercise.')
