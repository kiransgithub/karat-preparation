"""Python adaptation of the stock-market exercise; see QUESTION.md."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Stock:
    symbol: str
    name: str

@dataclass
class PriceRecord:
    stock: Stock
    price: int
    date: str

class StockCollection:
    def __init__(self, stock: Stock):
        self.stock = stock
        self.price_records: list[PriceRecord] = []

    def add_price_record(self, record: PriceRecord) -> None:
        if record.stock != self.stock:
            raise ValueError('Stock mismatch')
        self.price_records.append(record)

    def get_num_price_records(self) -> int:
        return len(self.price_records)

    def get_max_price(self) -> int:
        return max((r.price for r in self.price_records), default=-1)

    def get_min_price(self) -> int:
        return min((r.price for r in self.price_records), default=-1)

    def get_avg_price(self) -> float:
        if not self.price_records:
            return -1.0
        return sum(r.price for r in self.price_records) / len(self.price_records)

    def get_biggest_change(self) -> list[int | str] | None:
        if len(self.price_records) < 2:
            return None
        ordered = sorted(self.price_records, key=lambda r: r.date)
        first, second = ordered[0], ordered[1]
        best = [second.price - first.price, first.date, second.date]
        for previous, current in zip(ordered[1:], ordered[2:]):
            change = current.price - previous.price
            if abs(change) > abs(best[0]):
                best = [change, previous.date, current.date]
        return best

@dataclass
class Transaction:
    stock: Stock
    transaction_type: str
    date: str
    quantity: int

class Tradebook:
    def __init__(self):
        self.transactions: list[Transaction] = []

    def add_transaction(self, transaction: Transaction) -> None:
        self.transactions.append(transaction)

    def get_total(self, stock_collections: list[StockCollection]) -> int:
        quantities: dict[Stock, int] = {}
        for transaction in self.transactions:
            delta = transaction.quantity if transaction.transaction_type == 'buy' else -transaction.quantity
            quantities[transaction.stock] = quantities.get(transaction.stock, 0) + delta
        latest = {collection.stock: max(collection.price_records, key=lambda r: r.date).price
                  for collection in stock_collections if collection.stock in quantities}
        return sum(quantity * latest[stock] for stock, quantity in quantities.items())
