# Solution notes: Stock Prices, Consecutive Changes, and Portfolio Value

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/08-StockMarket/StockMarketProblem.txt) | [Original Java solution](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/08-StockMarket/Solution.java)

## Debugging diagnosis

The Python starter truncates a fractional average with //: the four original prices total 417, so the correct average is 104.25 rather than 104. Use true division while keeping the empty sentinel.

## Provenance

Stage 1 includes an added practice regression because the published Stage 1 code already passes its tests. This is not claimed to recover the original interview bug.

## Source issues and conversion choices

- The published Stage 1 implementation already computes a correct average and exposes no original bug. An added practice regression uses integer division and is caught by the original 104.25 average assertion.

- The Java biggest-change code initializes a sentinel to Integer.MIN_VALUE; its absolute value overflows in Java, and a direct Python port would also misbehave. Initialize from a real adjacent pair instead.

- The Java solution returns an invalid sentinel result for a single record; this adaptation returns None, matching the absence of a pair.

- The problem-file portfolio implementation groups by company name, while the separate solution compares full Stock objects. Python follows the stated stock identity (symbol and name).

- The Java solution applies abs to net holdings; Python follows buy-minus-sell arithmetic and does not turn negative positions into positive holdings.

- Stray whitespace in some problem-file symbols/dates is normalized to the clean Solution.java fixtures.

## Tests and complexity
Translated tests retain PriceRecord fields, empty and populated statistics, both chronological change examples, and the original portfolio milestones 1050, 1260, and 52890. Added tests cover mismatched stocks, one record, zero changes, tied movements, empty portfolios, and stocks sharing a company name.

For n price records, statistics cost O(n); sorting for biggest change costs O(n log n) time and O(n) temporary space. Portfolio valuation costs O(t + p) time for t transactions and p price records in held stocks, with O(s) space for s positions. Query functions do not reorder the stored records.
