# 08. Stock Prices, Consecutive Changes, and Portfolio Value

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/08-StockMarket/StockMarketProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 includes an added practice regression because the published Stage 1 code already passes its tests. This is not claimed to recover the original interview bug.

Maintain historical stock prices, identify the sharpest recorded movement, and value a user portfolio at current recorded prices.

Example: chronological prices 90, 110, 112, 105 have adjacent changes +20, +2, -7; the result is [20, "2023-06-25", "2023-06-29"]. A position of 12 units at a latest price of 105 is worth 1260.

## Data model

- `Stock`: symbol: str, name: str; equality uses both fields.

- `PriceRecord`: stock: Stock, price: int, date: str (YYYY-MM-DD).

- `StockCollection`: stock: Stock, price_records: list[PriceRecord].

- `Transaction`: stock: Stock, transaction_type: str (buy or sell), date: str, quantity: int.

- `Tradebook`: transactions: list[Transaction].

## Stage 1: Debug price statistics

1. Read the supplied classes and repair the failing StockCollection statistics test.

2. Keep the existing count, maximum, minimum, and arithmetic-average contracts. Empty price collections return -1 for minimum/maximum and -1.0 for average. Reject a record whose Stock differs from the collection Stock.

### Python API

```python

StockCollection.get_avg_price() -> float

StockCollection.get_num_price_records() -> int

StockCollection.get_max_price() -> int

StockCollection.get_min_price() -> int

```

## Stage 2: Find the largest consecutive change

1. Order records by date. Consecutive means neighboring recorded dates, even if calendar days are missing.

2. Return [signed_change, earlier_date, later_date] for the adjacent pair with the largest absolute price change. Return None when fewer than two records exist.

### Python API

```python

StockCollection.get_biggest_change() -> list[int | str] | None

```

## Stage 3: Calculate current portfolio value

1. Compute net units owned for every stock: bought quantities minus sold quantities.

2. Multiply each stock position by that stock's latest recorded price and add the values. Historical transaction prices are not the valuation prices.

### Python API

```python

Tradebook.get_total(stock_collections: list[StockCollection]) -> int

```

## Clarifications

- Dates are valid zero-padded YYYY-MM-DD strings, with at most one price record per stock per date.

- For equal absolute changes, choose the earliest pair chronologically. This tie rule is an explicit clarification.

- The input list provides a collection and price history for every transacted stock, as guaranteed by the source.

- transaction_type is exactly buy or sell. No overselling validation is requested; value the algebraic net quantity.

- The latest date is determined separately from each stock's available records.
