import unittest

def build_suite(implementation, stage="all"):
    M = implementation

    def collection(stock, data):
        result = M.StockCollection(stock)
        for price, date in data:
            result.add_price_record(M.PriceRecord(stock, price, date))
        return result

    class Stage1(unittest.TestCase):
        def test_record_and_empty_collection(self):
            stock = M.Stock('AAPL', 'Apple Inc.')
            record = M.PriceRecord(stock, 100, '2023-07-01')
            self.assertEqual((record.stock, record.price, record.date), (stock, 100, '2023-07-01'))
            result = M.StockCollection(stock)
            self.assertEqual(result.get_num_price_records(), 0)
            self.assertEqual(result.get_max_price(), -1)
            self.assertEqual(result.get_min_price(), -1)
            self.assertEqual(result.get_avg_price(), -1.0)

        def test_regression(self):
            stock = M.Stock('AAPL', 'Apple Inc.')
            result = collection(stock, [(110, '2023-06-29'), (112, '2023-07-01'),
                                        (90, '2023-06-28'), (105, '2023-07-06')])
            self.assertEqual(result.get_num_price_records(), 4)
            self.assertEqual(result.get_max_price(), 112)
            self.assertEqual(result.get_min_price(), 90)
            self.assertAlmostEqual(result.get_avg_price(), 104.25)

        def test_stock_mismatch(self):
            # Added validation check for the existing source contract.
            c = M.StockCollection(M.Stock('A', 'A'))
            with self.assertRaises(ValueError):
                c.add_price_record(M.PriceRecord(M.Stock('B', 'B'), 10, '2024-01-01'))
            self.assertEqual(c.price_records, [])

    class Stage2(unittest.TestCase):
        def test_biggest_change(self):
            stock = M.Stock('AAPL', 'Apple Inc.')
            self.assertIsNone(M.StockCollection(stock).get_biggest_change())
            c = collection(stock, [(110, '2023-06-29'), (112, '2023-07-01'),
                                   (90, '2023-06-25'), (105, '2023-07-06')])
            self.assertEqual(c.get_biggest_change(), [20, '2023-06-25', '2023-06-29'])
            c = collection(stock, [(200, '2000-01-04'), (210, '1999-12-30'),
                                   (190, '2000-01-03'), (180, '2000-01-01')])
            self.assertEqual(c.get_biggest_change(), [-30, '1999-12-30', '2000-01-01'])

        def test_single_flat_and_tied_changes(self):
            # Added missing one-record case and deterministic tie clarification.
            stock = M.Stock('A', 'A')
            self.assertIsNone(collection(stock, [(10, '2024-01-01')]).get_biggest_change())
            self.assertEqual(collection(stock, [(10, '2024-01-01'), (10, '2024-01-02')]).get_biggest_change(),
                             [0, '2024-01-01', '2024-01-02'])
            self.assertEqual(collection(stock, [(10, '2024-01-01'), (20, '2024-01-02'),
                                               (10, '2024-01-03')]).get_biggest_change(),
                             [10, '2024-01-01', '2024-01-02'])

    class Stage3(unittest.TestCase):
        def test_original_portfolio(self):
            stocks = [M.Stock('AAPL', 'Apple Inc.'), M.Stock('GOOG', 'Alphabet Inc.'),
                      M.Stock('MSFT', 'Microsoft Corporation'), M.Stock('AMZN', 'Amazon.com Inc.')]
            prices = [[(110, '2023-06-29'), (112, '2023-07-01'), (90, '2023-06-25'), (105, '2023-07-06')],
                      [(1500, '2023-06-29'), (1550, '2023-07-01'), (1475, '2023-06-25'), (1520, '2023-07-06')],
                      [(250, '2023-06-29'), (255, '2023-07-01'), (260, '2023-07-06'), (245, '2023-06-25')],
                      [(3550, '2023-07-06'), (3500, '2023-06-29'), (3600, '2023-07-01'), (3450, '2023-06-25')]]
            collections = [collection(s, p) for s, p in zip(stocks, prices)]
            book = M.Tradebook()
            book.add_transaction(M.Transaction(stocks[0], 'buy', '2023-06-25', 10))
            self.assertEqual(book.get_total(collections[:1]), 1050)
            book.add_transaction(M.Transaction(stocks[0], 'buy', '2023-06-29', 5))
            book.add_transaction(M.Transaction(stocks[0], 'sell', '2023-07-01', 3))
            self.assertEqual(book.get_total(collections[:1]), 1260)
            data = [(1, 'buy', '2023-06-25', 15), (1, 'sell', '2023-06-29', 10),
                    (1, 'sell', '2023-07-01', 1), (2, 'sell', '2023-07-01', 5),
                    (2, 'buy', '2023-06-29', 20), (2, 'buy', '2023-06-25', 10),
                    (3, 'buy', '2023-07-01', 5), (3, 'buy', '2023-06-29', 5),
                    (3, 'buy', '2023-06-25', 1)]
            for idx, kind, day, quantity in data:
                book.add_transaction(M.Transaction(stocks[idx], kind, day, quantity))
            self.assertEqual(book.get_total(collections), 52890)

        def test_empty_and_stock_identity(self):
            # Added equal company names with different stock symbols.
            self.assertEqual(M.Tradebook().get_total([]), 0)
            a, b = M.Stock('A', 'Shared Name'), M.Stock('B', 'Shared Name')
            book = M.Tradebook()
            book.add_transaction(M.Transaction(a, 'buy', '2024-01-01', 2))
            book.add_transaction(M.Transaction(b, 'buy', '2024-01-01', 3))
            self.assertEqual(book.get_total([collection(a, [(10, '2024-01-01')]),
                                            collection(b, [(100, '2024-01-01')])]), 320)

    groups = {'1': Stage1, '2': Stage2, '3': Stage3}
    suite = unittest.TestSuite()
    for key, case in groups.items():
        if stage == 'all' or str(stage) == key:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
