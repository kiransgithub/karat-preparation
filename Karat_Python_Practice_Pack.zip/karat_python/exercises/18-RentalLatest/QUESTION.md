# 18. Equipment Reservations with Turnaround Time

Manage sports-facility equipment reservations, query active member bookings, and find equipment with a 30-minute cleaning gap around a requested interval.

## Data model

- **ReservationStatus**: `ACTIVE, CANCELLED`
- **Equipment**: `equipment_id: int, name: str`
- **Reservation**: `reservation_id: int, member_name: str, equipment_id: int, start_time: int, end_time: int, status: ReservationStatus = ACTIVE`

## Stage 1: Repair cancellation-aware availability

- Read FacilityManager, then repair the failing reservation test.
- make_reservation should append and return True when there is no overlapping active reservation for the same equipment; otherwise return False without storing it. Cancelled reservations stay in history but must not block a new reservation.
- Preserve cancellation by ID: return True when an existing record is marked CANCELLED, or False when the ID is absent.

Python methods:

- `is_available(equipment_id: int, start_time: int, end_time: int) -> bool`
- `make_reservation(reservation: Reservation) -> bool`
- `cancel_reservation(reservation_id: int) -> bool`

## Stage 2: Member history and equipment totals

- Return all active reservations whose member_name equals the requested name. A member without active bookings gets [].
- Return total_reservations and total_minutes for active reservations of one equipment ID. A missing/unused ID gets both values as 0.

Python methods:

- `get_reservations_for_member(member_name: str) -> list[Reservation]`
- `get_equipment_summary(equipment_id: int) -> dict[str, int]`

## Stage 3: Find equipment with cleaning gaps

- Return registered equipment IDs that have no overlap with the requested interval and at least 30 minutes of separation from every active reservation, whether before or after the request.
- A gap of exactly 30 minutes is sufficient. Ignore cancelled bookings. Sort the IDs ascending and return [] if none qualify.

Python methods:

- `get_available_equipment(start_time: int, end_time: int) -> list[int]`

## Examples

For an active booking from 480 to 600 on equipment 1:

- A new overlapping booking is rejected; after cancellation, that same interval can be booked.
- The Stage 3 request 630-720 has exactly 30 minutes of turnaround and can use equipment 1.
- Request 620-720 has only 20 minutes of turnaround and cannot use equipment 1.
- An active booking at 600-720 also prevents request 500-580, but permits 500-570.

## Clarifications

- Times are integer minutes and request/reservation windows have start_time < end_time. Ordinary overlap uses half-open intervals, so touching endpoints do not overlap.
- The 30-minute rule applies to the new Stage 3 availability query only. Preserve the source make_reservation behavior; its earlier tests deliberately allow back-to-back bookings.
- make_reservation does not require the equipment ID to be registered, as demonstrated by the original tests. get_available_equipment considers only entries in equipment_list.
- Member names compare by string value, case-sensitively. Lists preserve reservation insertion order unless the contract explicitly requires sorting.
- Reservation equality/hash use reservation_id, matching the Java model. No additional duplicate-ID enforcement is introduced.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/18-RentalLatest/RentalLatestProblem.txt)
