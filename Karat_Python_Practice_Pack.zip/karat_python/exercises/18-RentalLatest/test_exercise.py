import unittest

def build_suite(implementation, stage='all'):
    M = implementation

    class Stage1(unittest.TestCase):
        def test_source_make_reservation(self):
            manager = M.FacilityManager()
            self.assertTrue(manager.make_reservation(M.Reservation(101,'Alice Johnson',1,480,600)))
            self.assertEqual(len(manager.reservations),1)

        def test_source_conflict(self):
            manager = M.FacilityManager()
            manager.make_reservation(M.Reservation(101,'Alice Johnson',1,480,600))
            self.assertFalse(manager.make_reservation(M.Reservation(102,'Bob Smith',1,540,660)))
            self.assertEqual(len(manager.reservations),1)

        def test_source_different_equipment(self):
            manager = M.FacilityManager()
            self.assertTrue(manager.make_reservation(M.Reservation(101,'Alice Johnson',1,480,600)))
            self.assertTrue(manager.make_reservation(M.Reservation(102,'Bob Smith',2,480,600)))

        def test_source_cancellation_regression(self):
            manager = M.FacilityManager()
            first = M.Reservation(101,'Alice Johnson',1,480,600)
            manager.make_reservation(first)
            self.assertTrue(manager.cancel_reservation(101))
            self.assertEqual(len(manager.reservations),1)
            self.assertEqual(first.status,M.ReservationStatus.CANCELLED)
            self.assertTrue(manager.make_reservation(M.Reservation(102,'Bob Smith',1,480,600)))
            self.assertEqual(len(manager.reservations),2)

        # Added edges: touching intervals and an absent cancellation ID.
        def test_touching_and_absent(self):
            manager = M.FacilityManager()
            manager.make_reservation(M.Reservation(1,'A',7,100,200))
            self.assertTrue(manager.make_reservation(M.Reservation(2,'B',7,200,250)))
            self.assertFalse(manager.cancel_reservation(99))

    class Stage2(unittest.TestCase):
        def test_source_member_reservations(self):
            manager = M.FacilityManager()
            rows = [M.Reservation(101,'Alice Johnson',1,480,600),M.Reservation(102,'Bob Smith',1,660,720),M.Reservation(103,'Alice Johnson',2,720,840),M.Reservation(104,'Carol White',2,480,540)]
            for row in rows:
                manager.make_reservation(row)
            self.assertEqual(manager.get_reservations_for_member('Alice Johnson'),[rows[0],rows[2]])
            fresh_name = ''.join(['Alice',' ','Johnson'])
            self.assertEqual(manager.get_reservations_for_member(fresh_name),[rows[0],rows[2]])
            self.assertEqual(manager.get_reservations_for_member('Bob Smith'),[rows[1]])
            self.assertEqual(manager.get_reservations_for_member('David Brown'),[])
            manager.cancel_reservation(101)
            self.assertEqual(manager.get_reservations_for_member('Alice Johnson'),[rows[2]])

        def test_source_equipment_summary(self):
            manager = M.FacilityManager()
            for row in [M.Reservation(101,'Alice Johnson',1,480,540),M.Reservation(102,'Bob Smith',1,660,720),M.Reservation(103,'Carol White',1,720,780),M.Reservation(104,'David Brown',2,480,600)]:
                self.assertTrue(manager.make_reservation(row))
            self.assertEqual(manager.get_equipment_summary(1),{'total_reservations':3,'total_minutes':180})
            self.assertEqual(manager.get_equipment_summary(2),{'total_reservations':1,'total_minutes':120})
            self.assertEqual(manager.get_equipment_summary(3),{'total_reservations':0,'total_minutes':0})
            manager.cancel_reservation(101)
            self.assertEqual(manager.get_equipment_summary(1),{'total_reservations':2,'total_minutes':120})

        # Added edge: cancelled-only histories are empty in both query forms.
        def test_cancelled_only(self):
            manager = M.FacilityManager()
            manager.make_reservation(M.Reservation(1,'A',1,10,20))
            manager.cancel_reservation(1)
            self.assertEqual(manager.get_reservations_for_member('A'),[])
            self.assertEqual(manager.get_equipment_summary(1),{'total_reservations':0,'total_minutes':0})

    class Stage3(unittest.TestCase):
        def test_source_available_equipment(self):
            manager = M.FacilityManager()
            for eid,name in [(4,'Elliptical Trainer'),(1,'Treadmill'),(2,'Rowing Machine'),(3,'Exercise Bike')]:
                manager.add_equipment(M.Equipment(eid,name))
            for row in [M.Reservation(101,'Alice Johnson',1,480,600),M.Reservation(102,'Bob Smith',2,300,420),M.Reservation(103,'Carol White',3,700,780)]:
                manager.make_reservation(row)
            self.assertEqual(manager.get_available_equipment(630,720),[1,2,4])
            self.assertEqual(manager.get_available_equipment(620,720),[2,4])
            manager.cancel_reservation(101)
            self.assertIn(1,manager.get_available_equipment(620,720))
            other = M.FacilityManager()
            other.add_equipment(M.Equipment(5,'Weight Bench'))
            other.make_reservation(M.Reservation(201,'Alice Johnson',5,480,600))
            self.assertEqual(other.get_available_equipment(610,700),[])
            before = M.FacilityManager()
            before.add_equipment(M.Equipment(6,'Spin Bike'))
            before.make_reservation(M.Reservation(301,'Nina Patel',6,600,720))
            self.assertEqual(before.get_available_equipment(500,580),[])
            self.assertEqual(before.get_available_equipment(500,570),[6])

        # Added edges: both sides of a free gap and inventory with no reservations.
        def test_two_sided_gap_and_empty_inventory(self):
            manager = M.FacilityManager()
            manager.add_equipment(M.Equipment(2,'Bike'))
            manager.add_equipment(M.Equipment(1,'Rower'))
            manager.make_reservation(M.Reservation(1,'A',1,100,200))
            manager.make_reservation(M.Reservation(2,'B',1,300,400))
            self.assertEqual(manager.get_available_equipment(230,270),[1,2])
            self.assertEqual(manager.get_available_equipment(229,270),[2])
            self.assertEqual(manager.get_available_equipment(230,271),[2])
            self.assertEqual(M.FacilityManager().get_available_equipment(0,10),[])

    classes = {'1': Stage1, '2': Stage2, '3': Stage3}
    chosen = classes if stage == "all" else {str(stage): classes[str(stage)]}
    suite = unittest.TestSuite()
    for case in chosen.values():
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(case))
    return suite
