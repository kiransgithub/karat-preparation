from dataclasses import dataclass
from enum import Enum

class ReservationStatus(Enum):
    ACTIVE = 'ACTIVE'
    CANCELLED = 'CANCELLED'

@dataclass(frozen=True)
class Equipment:
    equipment_id: int
    name: str

@dataclass(eq=False)
class Reservation:
    reservation_id: int
    member_name: str
    equipment_id: int
    start_time: int
    end_time: int
    status: ReservationStatus = ReservationStatus.ACTIVE

    def get_duration(self) -> int:
        return self.end_time - self.start_time

    def __eq__(self, other):
        if not isinstance(other, Reservation):
            return NotImplemented
        return self.reservation_id == other.reservation_id

    def __hash__(self):
        return hash(self.reservation_id)

class FacilityManager:
    def __init__(self):
        self.equipment_list: list[Equipment] = []
        self.reservations: list[Reservation] = []

    def add_equipment(self, equipment: Equipment) -> None:
        self.equipment_list.append(equipment)

    def is_available(self, equipment_id: int, start_time: int, end_time: int) -> bool:
        for reservation in self.reservations:
            if (reservation.equipment_id == equipment_id
                    and reservation.status is ReservationStatus.ACTIVE
                    and start_time < reservation.end_time
                    and end_time > reservation.start_time):
                return False
        return True

    def make_reservation(self, reservation: Reservation) -> bool:
        if not self.is_available(reservation.equipment_id, reservation.start_time, reservation.end_time):
            return False
        self.reservations.append(reservation)
        return True

    def cancel_reservation(self, reservation_id: int) -> bool:
        for reservation in self.reservations:
            if reservation.reservation_id == reservation_id:
                reservation.status = ReservationStatus.CANCELLED
                return True
        return False

    def get_reservations_for_member(self, member_name: str) -> list[Reservation]:
        return [r for r in self.reservations
                if r.member_name == member_name and r.status is ReservationStatus.ACTIVE]

    def get_equipment_summary(self, equipment_id: int) -> dict[str, int]:
        active = [r for r in self.reservations
                  if r.equipment_id == equipment_id and r.status is ReservationStatus.ACTIVE]
        return {'total_reservations': len(active), 'total_minutes': sum(r.get_duration() for r in active)}

    def get_available_equipment(self, start_time: int, end_time: int) -> list[int]:
        available = []
        for equipment in self.equipment_list:
            blocked = any(
                r.equipment_id == equipment.equipment_id
                and r.status is ReservationStatus.ACTIVE
                and start_time < r.end_time + 30
                and end_time + 30 > r.start_time
                for r in self.reservations)
            if not blocked:
                available.append(equipment.equipment_id)
        return sorted(available)
