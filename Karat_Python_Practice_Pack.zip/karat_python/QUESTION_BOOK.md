# Python Interview Practice

18 scenarios adapted from Krishnazz/Karat-Preperation. See README.md for setup, staged test commands, and provenance.


---

# 01. Cloud Compute Reservations

Maintain compute pools and reservations, calculate remaining capacity, and expire reservations at a supplied time.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/01-CloudCompute/CloudComputeProblem.txt).

The published starter already contains a fix. This adaptation restores the previously missing check identified in the source comment so Stage 1 remains a debugging question.

## Data model

- `ReservationStatus`: Enum: ACTIVE, CANCELLED, EXPIRED
- `ComputePool`: pool_id: int, region: str, total_capacity: int
- `Reservation`: reservation_id: int, customer_id: int, pool_id: int, capacity_units: int, status: ReservationStatus, start_time: int, end_time: int

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug remaining capacity

- Read the existing manager and repair get_available_capacity. Capacity is the pool total minus the units in ACTIVE reservations for that pool.
- An unknown pool has zero available capacity; reservations in other pools must not affect the result.

Python methods:

```python
get_available_capacity(pool_id: int) -> int
```

## Stage 2: Add reservations and customer totals

- add_reservation stores the supplied reservation only when its pool exists and its capacity_units are no greater than that pool's currently available capacity. Otherwise ignore it.
- get_reserved_capacity_by_customer returns customer IDs mapped to the sum of their ACTIVE capacity units across pools. Omit customers with no ACTIVE reservations; return {} when none qualify.

Python methods:

```python
add_reservation(reservation: Reservation) -> None
get_reserved_capacity_by_customer() -> dict[int, int]
```

## Stage 3: Expire completed reservation windows

- Change ACTIVE reservations with end_time <= current_time to EXPIRED. Leave CANCELLED, already EXPIRED, and later-ending ACTIVE reservations unchanged.
- Return the number whose status changed. The changed records must stop consuming capacity.

Python methods:

```python
expire_reservations(current_time: int) -> int
```

## Examples

A pool of 100 units with an ACTIVE reservation of 30 and a CANCELLED reservation of 20 has 70 units available. Expiring two ACTIVE reservations ending at 900 and 1000 at current_time=1000 returns 2.

## Clarifications

- Times use the same integer unit. Capacity calculations depend on explicit status, not on the clock; expiry occurs when expire_reservations is called.
- Inputs use nonnegative capacity units and valid enum values. No extra deduplication or time-window validation is requested.
- The admission capacity check applies to every supplied reservation, regardless of its status, as written in the source prompt.
- add_compute_pool replaces a pool with the same ID, matching the source map behavior.


---

# 02. Gym Membership and Workout Billing

Manage membership levels, summarize workouts, and calculate tier-based charges after free workouts.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/02-Gym/GymProblem.txt).

This Python adaptation preserves the source tasks and separates the starter from the answer.

## Data model

- `MembershipStatus`: Enum: BRONZE, SILVER, GOLD
- `Member`: member_id: int, name: str, membership_status: MembershipStatus
- `Workout`: id: int, start_time: int, end_time: int; get_duration() returns minutes
- `MembershipStatistics`: total_members: int, total_paid_members: int, conversion_rate: float (percentage)

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug membership statistics

- Read the membership code and fix its statistics. SILVER and GOLD are paid memberships; BRONZE is not.
- Return total members, paid members, and the percentage of members on a paid tier. An empty gym returns (0, 0, 0.0). Existing add_member and update_membership behavior should remain usable.

Python methods:

```python
get_membership_statistics() -> MembershipStatistics
```

## Stage 2: Record workouts and average duration

- add_workout stores a workout for an existing member; ignore workouts for unknown member IDs.
- get_average_workout_durations maps each member with recorded workouts to their mean duration in minutes. All sessions are within the same day.

Python methods:

```python
add_workout(member_id: int, workout: Workout) -> None
get_average_workout_durations() -> dict[int, float]
```

## Stage 3: Calculate membership-tier charges

- Order each member's workouts by workout ID before deciding which are free.
- BRONZE: first 1 free, then $10/hour. SILVER: first 3 free, then $8/hour. GOLD: first 5 free, then $6/hour.
- Round each charged workout separately up to a whole hour. Return every member ID with their total, including zero for members with no workouts or no chargeable workouts.

Python methods:

```python
get_due_payments() -> dict[int, int]
```

## Examples

With five members on SILVER, BRONZE, GOLD, SILVER, BRONZE, the statistics are 5 total, 3 paid, and 60%. For BRONZE, a free first workout followed by 80-minute and 20-minute workouts costs $30.

## Clarifications

- Member IDs and workout IDs are unique as described in the source. Inputs have end_time >= start_time, in minutes within one day.
- Averages omit members with no workouts, matching the source implementation; payments include them with zero, as the source tests require.
- Unknown-member membership updates do nothing. Charges use the member's current tier. Rounding is per workout, not after combining durations.
- get_membership_statistics returns a percentage (0 through 100), not a fraction.


---

# 03. Clinic Appointments and Patient Visits

Summarize appointment outcomes and calculate each doctor's average visit duration by visit type.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/03-Doctor/DoctorProblem.txt).

Provenance: the published starter is already correct for Stage 1. This version introduces an added practice regression while preserving the source expected behavior. The source has two stages; no third-stage requirement is invented.

## Data model

- `AppointmentStatus`: Enum: SCHEDULED, COMPLETED, CANCELLED, NO_SHOW
- `VisitType`: Enum: CONSULTATION, FOLLOWUP, EMERGENCY
- `Doctor`: doctor_id: int, name: str
- `Appointment`: appointment_id: int, doctor_id: int, patient_id: int, duration_minutes: int, status: AppointmentStatus
- `PatientVisit`: visit_id: int, patient_id: int, doctor_id: int, start_time: int, duration_minutes: int, visit_type: VisitType
- `AppointmentStats`: total_appointments: int, completed_appointments: int, no_show_rate: float (fraction)

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug appointment statistics

- Read the manager and fix the supplied statistics regression. Count every appointment in the total, count COMPLETED records separately, and report NO_SHOW records divided by total appointments.
- For no appointments return total=0, completed=0, no_show_rate=0.0. The rate is a fraction, not a percentage.

Python methods:

```python
get_appointment_statistics() -> AppointmentStats
```

## Stage 2: Store visits and average by type

- add_patient_visit stores the visit only if its doctor_id is registered; ignore unknown doctors.
- For the requested doctor, return a dictionary from each observed VisitType to mean duration_minutes. Omit absent types and return {} when the doctor has no visits.

Python methods:

```python
add_patient_visit(patient_visit: PatientVisit) -> None
get_average_visit_duration_by_type(doctor_id: int) -> dict[VisitType, float]
```

## Examples

Two COMPLETED, one NO_SHOW, one CANCELLED, and one SCHEDULED appointment produce (5, 2, 0.2). CONSULTATION visits lasting 30 and 50 minutes for one doctor average 40 minutes.

## Clarifications

- start_time uses minutes since the start of the day. Durations are nonnegative and enums valid.
- Appointment statistics cover all stored appointments; add_appointment does not validate doctor IDs, matching the source.
- An unknown doctor produces an empty visit-average dictionary because unknown-doctor visits cannot be stored.
- Doctors are keyed by ID; registering an existing ID replaces the doctor object.


---

# 04. Campus Access Control

Authorize campus users according to an access hierarchy, record access sessions, and identify users present outside opening hours.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/04-Campus/CampusProblem.txt).

Provenance: source files contain solved code and tests, without numbered question prose. This adaptation turns those behaviors into three practice stages and restores the commented authorization regression.

## Data model

- `AccessLevel`: IntEnum: VISITOR=1, STAFF=2, ADMIN=3
- `User`: user_id: int, name: str, access_level: AccessLevel
- `AccessEvent`: id: int, entry_time: int, exit_time: int (minutes since start of day)

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug hierarchical authorization

- A registered user is authorized for their own access level and any lower level. An unknown user is never authorized.
- Fix is_authorized while preserving add_user and update_access_level. Unknown-user updates do nothing.

Python methods:

```python
is_authorized(user_id: int, required_level: AccessLevel) -> bool
```

## Stage 2: Record access sessions

- log_access stores an event for a known user and returns True. For an unknown user, return False without storing the event.

Python methods:

```python
log_access(user_id: int, event: AccessEvent) -> bool
```

## Stage 3: Find after-hours visitors

- Return ascending user IDs with at least one event entering before minute 480 or exiting after minute 1200.
- The exact opening and closing boundaries are within hours. Include each qualifying user once; omit users with no qualifying event.

Python methods:

```python
get_after_hours_users() -> list[int]
```

## Examples

ADMIN can access VISITOR, STAFF, and ADMIN requirements. STAFF cannot access ADMIN. Events at [480,1200] are within hours; [479,480] and [1200,1201] are outside hours.

## Clarifications

- Events occur within one day and have entry_time <= exit_time; IDs are unique.
- Access logging only checks whether the user exists. It does not require a particular access level.
- The source does not provide numbered narrative stages. The three-stage grouping here is reconstructed from its authorization, logging, and after-hours tests.


---

# 05. Device Fleet Lifecycle

Enforce device status transitions, validate registrations, and count active devices by type.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/05-DeviceFleet/DevicefleetProblem.txt).

Provenance: the source status-update implementation is already corrected. Stage 1 therefore contains an added practice regression based on its existing tests. Stage 2 follows the published task text; there is no source Stage 3.

## Data model

- `Device`: device_id: str, device_type: str, location: str, status: str, registered_day: int, next_maintenance_day: int, failure_count: int
- `ReplacementEntry`: device_id: str, failure_count: int, age_days: int; present in source but unused by these tasks

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug status transitions

- update_device_status must return True and mutate status only when the device exists and the requested transition is allowed. Invalid requests return False without changing state.
- Allowed transitions: REGISTERED -> ACTIVE or RETIRED; ACTIVE -> SUSPENDED, MAINTENANCE_DUE, or RETIRED; SUSPENDED -> ACTIVE or RETIRED; MAINTENANCE_DUE -> ACTIVE or RETIRED; RETIRED -> none.
- Same-status updates are not allowed. Unknown status strings and unknown device IDs must be rejected.

Python methods:

```python
update_device_status(device_id: str, new_status: str) -> bool
```

## Stage 2: Register devices and count active types

- add_device accepts a device only if its ID is unused, its status is valid, its type is SENSOR, CAMERA, or GATEWAY, and registered_day >= 0. Return True on insertion; otherwise False, preserving all existing records.
- get_active_device_counts_by_type maps each device type to its ACTIVE-device count. Omit types with no ACTIVE devices and return {} for an empty qualifying set.

Python methods:

```python
add_device(device: Device) -> bool
get_active_device_counts_by_type() -> dict[str, int]
```

## Examples

ACTIVE -> SUSPENDED succeeds, but ACTIVE -> REGISTERED fails without changing the device. Two ACTIVE SENSOR devices and one ACTIVE GATEWAY produce {"SENSOR": 2, "GATEWAY": 1}.

## Clarifications

- Status and type strings are case-sensitive. The five valid statuses are REGISTERED, ACTIVE, SUSPENDED, MAINTENANCE_DUE, RETIRED.
- No validation of location, failure_count, or next_maintenance_day is requested. Registration may start in any valid status.
- The published source only supplies Stage 2 narrative. Stage 1 behavior is reconstructed from its existing method and three status-update tests.
- ReplacementEntry is retained for model completeness; no replacement-planning question exists in the supplied files.


---

# 06. Account Transactions and Activity Monitoring

Repair account balances, calculate transaction statistics and fees, and detect suspicious debit activity. Two optional analytics helpers are extracted from the source solution.

Source: [original Java question](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/06-Transactions/TransactionProblem.txt).

The source has four numbered stages. Optional Stage 5 is extracted from two extra methods found only in its solution file; it is clearly separate from the original questions.

## Data model

- `TransactionType`: Enum: CREDIT, DEBIT
- `Account`: account_id: int, owner_name: str
- `Transaction`: transaction_id: int, account_id: int, type: TransactionType, amount: float, timestamp_sec: int

## How to work

Edit `starter.py`. Run Stage 1 first; it deliberately contains one regression. Later-stage methods raise `NotImplementedError` until you implement them. Use `solution.py` and `SOLUTION_NOTES.md` only after attempting the questions.

## Stage 1: Debug account balances

- Read the account manager and repair get_balance. CREDIT increases the balance and DEBIT decreases it. Transactions belonging to another account must not affect the result.
- Accounts with no transactions have a zero balance. Existing account and transaction registration methods are provided.

Python methods:

```python
get_balance(account_id: int) -> float
```

## Stage 2: Average transaction amount

- Return account IDs mapped to the average absolute transaction amount, including CREDIT and DEBIT records.
- Omit accounts without transactions. All transactions refer to valid accounts.

Python methods:

```python
get_average_transaction_amount_by_account() -> dict[int, float]
```

## Stage 3: Calculate transaction fees

- Order transactions by timestamp_sec separately for each account. Its first three transactions are free.
- Every later CREDIT costs $1 and every later DEBIT costs $2. Return the total fee per account.

Python methods:

```python
get_transaction_fees() -> dict[int, float]
```

## Stage 4: Detect suspicious accounts

- Consider only DEBIT records whose amount is at least 50.
- An account qualifies if any three or more such records fit in an inclusive 60-second window. Input records may arrive out of order.
- Return qualifying account IDs once each in ascending order. Records at t and t+60 can be in the same window.

Python methods:

```python
get_suspicious_accounts() -> list[int]
```

## Stage 5: Optional: additional analytics from the Java solution

- These two helpers exist only in Solution.java; they are optional practice questions derived from that code, not numbered tasks in the original prompt.
- get_top_spending_account returns the account with the largest total DEBIT amount. Break equal-total ties by smaller account ID; return -1 if there are no debit transactions.
- get_transaction_count_by_account maps each account with transactions to its number of records, including both types. Omit accounts with no records.

Python methods:

```python
get_top_spending_account() -> int
get_transaction_count_by_account() -> dict[int, int]
```

## Examples

Credits of 100 and 10 plus debits of 30 and 20 produce a balance of 60 and an average amount of 40. Three large debits at times 500, 530, and 560 qualify; replacing 560 by 561 does not.

## Clarifications

- Source inputs use positive amounts, valid enum values, unique transaction IDs, and valid account IDs. Negative balances are permitted; no overdraft rejection is requested.
- No fees are subtracted by get_balance: fees are a separate report.
- Fee output includes all registered accounts, with 0.0 for accounts having at most three transactions. This makes the prompt's "each account" behavior explicit where source tests are silent.
- For equal timestamps, retain insertion order (stable sorting). This is an adaptation clarification because the source does not specify another tie-break.
- The source fee prompt says getPaymentFee, while its implementation/tests say getTransactionFees. The Python API uses get_transaction_fees.


---

# 07. Insurance Claims and Status History

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/07-Insurance/InsuranceProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** The original bug is restored from an explicit source comment; Stage 1 wording is reconstructed from the supplied code and tests. This source has two stages.

Track claim outcomes and keep an audit history of staff decisions. Status statistics summarize all claims; history summaries count actions by approver role.

Example: nine claims with three approvals and two rejections have five resolved claims. Recording two JUNIOR actions and one SENIOR action yields {"JUNIOR": 2, "SENIOR": 1}.

## Data model

- `ClaimStatus`: SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED.

- `ClaimType`: AUTO, HEALTH, PROPERTY.

- `StatusChange`: new_status: ClaimStatus, approver_role: str, timestamp: int.

- `Claim`: claim_id: int, policyholder_id: int, claim_type: ClaimType, amount: float, status: ClaimStatus, status_history: list[StatusChange].

- `ClaimsSystem`: claims: list[Claim].

## Stage 1: Debug claim statistics

1. Read the models and existing add/update methods, then fix the failing statistics test.

2. Return total_claims, total_resolved_claims, and resolution_rate. APPROVED and REJECTED are resolved; the other states remain active. The rate is a percentage, not a fraction.

### Python API

```python

ClaimsSystem.get_claim_statistics() -> dict[str, int | float]

```

## Stage 2: Record status history and summarize approvers

1. Ensure each claim starts with its own empty status_history list. Its data-model field is supplied in the scaffold.

2. record_status_change updates the matching claim status and appends a StatusChange containing the new status, role, and integer-hour timestamp. Even recording the current status adds a history entry.

3. get_status_change_counts_per_role counts all history entries across all claims by role; omit roles with no changes and return an empty dictionary when no changes exist.

### Python API

```python

ClaimsSystem.record_status_change(claim_id: int, new_status: ClaimStatus, approver_role: str, timestamp: int) -> None

ClaimsSystem.get_status_change_counts_per_role() -> dict[str, int]

```

## Clarifications

- For zero claims, return a resolution_rate of 0.0; the original prompt does not define the empty denominator.

- Claim IDs are assumed unique in normal input. A missing ID is ignored, matching the Java search behavior.

- update_claim_status is the legacy update without history; record_status_change is the new operation that records history.

- No transition validation or timestamp sorting is required. Record history in call order.


---

# 08. Stock Prices, Consecutive Changes, and Portfolio Value

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/08-StockMarket/StockMarketProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 includes an added practice regression because the published Stage 1 code already passes its tests. This is not claimed to recover the original interview bug.

Maintain historical stock prices, identify the sharpest recorded movement, and value a user portfolio at current recorded prices.

Example: chronological prices 90, 110, 112, 105 have adjacent changes +20, +2, -7; the result is [20, "2023-06-25", "2023-06-29"]. A position of 12 units at a latest price of 105 is worth 1260.

## Data model

- `Stock`: symbol: str, name: str; equality uses both fields.

- `PriceRecord`: stock: Stock, price: int, date: str (YYYY-MM-DD).

- `StockCollection`: stock: Stock, price_records: list[PriceRecord].

- `Transaction`: stock: Stock, transaction_type: str (buy or sell), date: str, quantity: int.

- `Tradebook`: transactions: list[Transaction].

## Stage 1: Debug price statistics

1. Read the supplied classes and repair the failing StockCollection statistics test.

2. Keep the existing count, maximum, minimum, and arithmetic-average contracts. Empty price collections return -1 for minimum/maximum and -1.0 for average. Reject a record whose Stock differs from the collection Stock.

### Python API

```python

StockCollection.get_avg_price() -> float

StockCollection.get_num_price_records() -> int

StockCollection.get_max_price() -> int

StockCollection.get_min_price() -> int

```

## Stage 2: Find the largest consecutive change

1. Order records by date. Consecutive means neighboring recorded dates, even if calendar days are missing.

2. Return [signed_change, earlier_date, later_date] for the adjacent pair with the largest absolute price change. Return None when fewer than two records exist.

### Python API

```python

StockCollection.get_biggest_change() -> list[int | str] | None

```

## Stage 3: Calculate current portfolio value

1. Compute net units owned for every stock: bought quantities minus sold quantities.

2. Multiply each stock position by that stock's latest recorded price and add the values. Historical transaction prices are not the valuation prices.

### Python API

```python

Tradebook.get_total(stock_collections: list[StockCollection]) -> int

```

## Clarifications

- Dates are valid zero-padded YYYY-MM-DD strings, with at most one price record per stock per date.

- For equal absolute changes, choose the earliest pair chronologically. This tie rule is an explicit clarification.

- The input list provides a collection and price history for every transacted stock, as guaranteed by the source.

- transaction_type is exactly buy or sell. No overselling validation is requested; value the algebraic net quantity.

- The latest date is determined separately from each stock's available records.


---

# 09. Imported Transactions, Running Balances, and Type Summaries

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/09-TransactionNew/TransactionNewProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 retains the original defect present in the source problem. Later-stage implementations are replaced by stubs. This source has two stages.

Import financial events from multiple sources, report account activity, and maintain balances for newly recorded transactions.

Example: a deposit of 500, withdrawal of 150, fee of 50, and interest of 20 leave a running balance of 320. A type summary totals positive transaction amounts even for debit types.

## Data model

- `TransactionType`: DEPOSIT, WITHDRAWAL, TRANSFER, FEE, INTEREST.

- `Transaction`: transaction_id: str, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int, description: str, source: str.

- `ImportSystem`: transactions: list[Transaction], balances: dict[int, float].

## Stage 1: Debug per-account net movement

1. Read the models and repair get_account_summary while preserving per-account filtering.

2. Return total_credits, total_debits, net_change, and transaction_count. DEPOSIT and INTEREST add funds; WITHDRAWAL, FEE, and TRANSFER subtract funds.

### Python API

```python

ImportSystem.get_account_summary(account_id: int) -> dict[str, int | float]

```

## Stage 2: Record transactions and aggregate by type

1. Maintain an initially empty balances mapping. The scaffold includes its declaration; verify that new accounts begin at 0.0.

2. record_transaction creates and appends a Transaction and updates that account's running balance using the type's direction.

3. get_type_summary aggregates across all accounts and sources. Keys are uppercase enum-name strings; each value has integer count and positive total_amount. Omit unused types.

### Python API

```python

ImportSystem.record_transaction(transaction_id: str, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int, description: str, source: str) -> None

ImportSystem.get_type_summary() -> dict[str, dict[str, int | float]]

```

## Clarifications

- Amounts are positive and transaction_type is a valid enum member, as specified by the source.

- add_transaction is the original append-only fixture/import helper; only record_transaction updates balances. Do not mix preloaded add_transaction rows into a running-balance workflow without defining a separate initialization policy.

- No deduplication, source matching, or reconciliation algorithm is requested in this variant.

- An account with no matching transactions has zeros for all four summary fields.


---

# 10. Medical Equipment Reservations and Status Reports

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/10-Rental/RentalProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 contains an added practice regression because the published code already passes its tests. The source provides two stages; the rental variant is kept separate from RentalLatest.

Manage shared clinic equipment, allow staff to reserve time intervals, and report booked minutes by reservation status.

Example: a booking from minute 480 through 600 blocks a booking starting at 540, permits one starting at 600, and stops blocking the interval after cancellation. Three bookings of 60, 60, and 90 minutes total 210 active minutes.

## Data model

- `ReservationStatus`: ACTIVE, CANCELLED.

- `Equipment`: equipment_id: int, name: str.

- `Reservation`: reservation_id: int, staff_name: str, equipment_id: int, start_time: int, end_time: int; status initially ACTIVE; equality compares reservation_id.

- `RentalManager`: equipment_list: list[Equipment], reservations: list[Reservation].

## Stage 1: Debug booking availability

1. Read the manager and repair its failing reservation test.

2. Reservations conflict only for the same equipment when active time intervals overlap. A cancelled reservation remains stored but must free its time slot.

3. make_reservation returns True only when it stores the booking. cancel_reservation changes an active booking and returns True; return False when no active matching booking exists.

### Python API

```python

RentalManager.is_available(equipment_id: int, start_time: int, end_time: int) -> bool

RentalManager.make_reservation(reservation: Reservation) -> bool

RentalManager.cancel_reservation(reservation_id: int) -> bool

```

## Stage 2: Report active bookings and booked minutes

1. get_active_reservation_ids returns every active reservation ID in ascending numeric order, or an empty list.

2. get_total_minutes_by_status sums end_time - start_time for stored reservations separately by status. Always include ACTIVE and CANCELLED string keys, even when their totals are zero.

### Python API

```python

RentalManager.get_active_reservation_ids() -> list[int]

RentalManager.get_total_minutes_by_status() -> dict[str, int]

```

## Clarifications

- Times are integer minutes within one day and valid input has start_time < end_time.

- Intervals that only touch at an endpoint do not conflict.

- Equipment IDs need not be registered through add_equipment before booking: the original tests book without registering equipment.

- Reservation IDs are unique in valid input. This exercise does not add duplicate-ID validation.

- A second cancellation returns False, following the source method documentation's active-only contract.


---

# 11. Listener Statistics and Duplicate Song Groups

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/11-Music/MusicProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 preserves the original wrong-list defect. Stage 2 follows the stated duplicate-group requirements and corrects additional flaws in the Java reference solution. This source has two stages.

Analyze listener activity and identify duplicate catalog records imported from different feeds. Keep skipped plays in listener statistics and use deterministic IDs when reporting duplicate groups.

Example: four plays covering three songs, with two completed plays, produce ListenerStats(4, 3, 0.5). Duplicate song IDs 9, 3, 5 produce DedupResult(song_id=3, merged_ids=[5, 9]).

## Data model

- `Song`: song_id: int, title: str, artist: str, duration_seconds: int; optional description, album, genre: str | None and release_year: int | None.

- `PlayEvent`: play_id: int, user_id: int, song_id: int, listened_seconds: int, timestamp: int.

- `ListenerStats`: total_plays: int, unique_songs: int, completion_rate: float.

- `DedupResult`: song_id: int (kept ID), merged_ids: list[int].

- `MusicLibrary`: songs: dict[int, Song], play_events: list[PlayEvent].

## Stage 1: Debug listener analytics

1. Read the library and fix the failing listener statistics test.

2. For one user, count all plays, count distinct song IDs including skipped plays, and calculate completed plays divided by total plays. A play is complete when listened_seconds >= duration_seconds.

3. A user with no plays receives ListenerStats(0, 0, 0.0). A statistics query must leave stored play events unchanged.

### Python API

```python

MusicLibrary.get_listener_stats(user_id: int) -> ListenerStats

```

## Stage 2: Identify duplicate song groups

1. Treat songs as duplicates when title and artist match without case sensitivity and duration_seconds is equal. Other metadata does not participate.

2. For each group with at least two members, keep the smallest song ID and put all other IDs in merged_ids sorted ascending.

3. Return DedupResult objects sorted by their kept song_id. Report groups only; do not remove songs or rewrite play events.

### Python API

```python

MusicLibrary.find_duplicate_groups() -> list[DedupResult]

```

## Clarifications

- Song IDs are unique, as guaranteed by the source, and all play events reference cataloged songs.

- Titles and artist names are strings. Python casefold provides case-insensitive grouping; whitespace is not stripped.

- Completion rate is a fraction between 0.0 and 1.0, not a percentage.

- Finding groups is a query: repeated calls with unchanged data should return identical groups.


---

# 12. Order Status and Restaurant Delivery Averages

Source: [original Java exercise](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/12-FoodDelivery/FoodDeliveryProblem.txt).

Use `starter.py` and the staged tests. The reference implementation and explanations are in `solution.py` and `SOLUTION_NOTES.md`.

**Practice provenance:** Stage 1 contains an added practice regression because the published statistics code already passes its test. The delivery tasks preserve the source requirements. This source has two stages.

Track food orders through their lifecycle and report delivery performance for each restaurant. An order may have multiple delivery records.

Example: one restaurant has deliveries lasting 30, 30, and 60 minutes across two orders. Its average is 40.0 minutes; averaging the two order averages would give an incorrect 37.5.

## Data model

- `OrderStatus`: PLACED, PREPARING, OUT_FOR_DELIVERY, DELIVERED, CANCELED.

- `Delivery`: delivery_id: int, start_minute: int, end_minute: int.

- `Order`: order_id: int, restaurant_id: int, customer_id: int, order_value: float, distance_km: float, status: OrderStatus, deliveries: list[Delivery].

- `OrderStats`: total_orders: int, active_orders: int, closed_orders: int.

- `OrderManager`: orders: list[Order].

## Stage 1: Debug order status counts

1. Read the order lifecycle and repair the failing order-statistics test.

2. Return total order count, active order count, and closed order count. PLACED, PREPARING, and OUT_FOR_DELIVERY are active; DELIVERED and CANCELED are closed.

### Python API

```python

OrderManager.get_order_statistics() -> OrderStats

```

## Stage 2: Attach deliveries and average their durations

1. Associate a Delivery with the matching order. Ignore an unknown order ID. Delivery duration is end_minute - start_minute.

2. Return a mapping from restaurant ID to the average duration of all its deliveries across all orders. Count deliveries individually, rather than averaging the per-order averages.

### Python API

```python

OrderManager.add_delivery(order_id: int, delivery: Delivery) -> None

OrderManager.get_average_delivery_time_by_restaurant() -> dict[int, float]

```

## Clarifications

- Delivery IDs are unique and times are valid within the same day, as stated by the source.

- Order IDs identify one order. No additional deduplication or status-transition validation is requested.

- Include each restaurant represented by at least one order. If it has no deliveries, return 0.0, following the Java reference solution.

- Count all attached deliveries regardless of the order's current status.


---

# 13. Player Statistics, Head-to-Head Results, and Recent Form

Maintain player records and per-player match observations, then answer statistics and ranking queries. A match may have a separate observation for each participant.

## Data model

- **Outcome**: `WIN, LOSS, DRAW`
- **Player**: `player_id: int, username: str`
- **MatchResult**: `player_id: int, opponent_id: int, outcome: Outcome, score: int, timestamp: int`
- **PlayerStats**: `total_matches: int, wins: int, win_rate: float`
- **HeadToHead**: `wins_player1: int, wins_player2: int, draws: int, total_matches: int, last_result: Outcome | None, last_match_timestamp: int | None`

## Stage 1: Repair player statistics

- Read the supplied models and GameManager implementation, then diagnose its failing test.
- Return the number of all results belonging to the requested player, the number of wins, and wins divided by total matches. A player with no results has zero counts and a rate of 0.0.

Python methods:

- `get_player_statistics(player_id: int) -> PlayerStats`

## Stage 2: Record results and average scores

- Store a result only if its player_id is registered. Ignore unknown players.
- For one player, return an Outcome-to-average-score dictionary containing only outcomes that actually occur. Return {} when the player has no results.

Python methods:

- `add_match_result(result: MatchResult) -> None`
- `get_average_score_by_outcome(player_id: int) -> dict[Outcome, float]`

## Stage 3: Summarize two opponents

- Return counts of player 1 wins, player 2 wins, draws, and total matches between the two players.
- Include the latest result from player 1's perspective and its timestamp. With no matching history, all counts are zero and both latest fields are None.

Python methods:

- `get_head_to_head(player1_id: int, player2_id: int) -> HeadToHead`

## Stage 4: Rank recent form

- For each registered player with at least n results, select the n most recent results by timestamp. Score WIN as 3, DRAW as 1, and LOSS as 0.
- Return [player_id, form_points] pairs sorted by points descending, then player ID ascending. Return [] when n <= 0.

Python methods:

- `get_recent_form(n: int) -> list[list[int]]`

## Examples

- Outcomes WIN, LOSS, DRAW, WIN produce `PlayerStats(4, 2, 0.5)`.
- Scores 80 and 90 for WIN and 70 for DRAW produce `{Outcome.WIN: 85.0, Outcome.DRAW: 70.0}`.
- For `n=3`, recent outcomes WIN/WIN/WIN earn 9 points; WIN/DRAW/LOSS earn 4.

## Clarifications

- Results are stored from one player's perspective. Head-to-head queries use player 1's records against player 2; reciprocal records must not be counted a second time.
- Only player_id must be registered when adding a result; opponent_id is not validated by the source contract.
- Timestamps determine recency, not arrival order. For equal timestamps, insertion order resolves the tie, with later insertion considered later.
- Outcome averages and win rates are fractions/float values, not percentages. Existing add_player replaces the same player ID as in the source.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/13-Playground/PlaygroundProblem.txt)


---

# 14. Banking Compliance Queries

Store the day's financial events and provide account-level and high-value transaction queries. This is the repository's latest transaction variant, with two stages.

## Data model

- **TransactionType**: `DEPOSIT, WITHDRAWAL, TRANSFER`
- **Transaction**: `transaction_id: int, account_id: int, amount: float, transaction_type: TransactionType, timestamp: int`

## Stage 1: Repair account filtering

- Read the supplied ComplianceMonitor and fix the failed account-query test.
- Return every transaction ID belonging to the requested account in ascending ID order. Return [] when no transaction belongs to that account. Preserve existing registration and ID lookup behavior.

Python methods:

- `get_transactions_for_account(account_id: int) -> list[int]`

## Stage 2: High-value activity and account totals

- Return IDs whose amounts are at least threshold, sorted by amount descending and transaction ID ascending for equal amounts. Return [] when none qualify.
- Return an account summary with total_transactions and total_amount. Include every transaction type and use zero for both values when the account has no records.

Python methods:

- `get_high_value_transactions(threshold: float) -> list[int]`
- `get_account_summary(account_id: int) -> dict[str, int | float]`

## Examples

For transactions `(1, account=100, amount=5000)`, `(2, account=100, amount=15000)`, and `(3, account=200, amount=5000)`:

- `get_transactions_for_account(100)` returns `[1, 2]`.
- `get_high_value_transactions(5000)` returns `[2, 1, 3]`.
- `get_account_summary(100)` returns `{"total_transactions": 2, "total_amount": 20000.0}`.

## Clarifications

- Timestamps are minutes since the start of the day. Amounts retain the Java double representation as Python float; compare calculated amounts with a tolerance.
- The summary adds recorded amounts across all transaction types. It is an activity total, not a signed account balance.
- add_transaction appends records; no extra ID deduplication or account validation is introduced. get_transaction returns the first matching record, or None.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/14-TransactionLatest/TransactionLatestProblem.txt)


---

# 15. Order Notifications and Idempotent Delivery Updates

Manage messages generated for retail orders. Providers can repeat delivery updates within a batch or across batches; only new status/timestamp pairs should be retained.

## Data model

- **DeliveryStatus**: `QUEUED=1, SENT=2, DELIVERED=3, FAILED=4`
- **Notification**: `notification_id: int, order_id: int, created_at: int`
- **Update**: `tuple[DeliveryStatus, int] representing (status, timestamp)`

## Stage 1: Repair notification lookup by order

- Read NotificationCenter and diagnose its failing query test.
- Return all notification IDs for the requested order, sorted ascending. Return [] for an order without notifications. Preserve add_notification and get_notification.

Python methods:

- `get_order_notifications(order_id: int) -> list[int]`

## Stage 2: Ingest and count unique updates

- For a known notification, store only status/timestamp pairs not already present and return the number added. Deduplicate both against earlier calls and within the current batch.
- For an unknown notification, store nothing and return 0.
- Return the number of stored unique updates for a notification; return 0 if it is missing or has no updates.

Python methods:

- `add_updates(notification_id: int, updates: list[tuple[DeliveryStatus, int]]) -> int`
- `get_update_count(notification_id: int) -> int`

## Examples

With notification 40 registered:

- `add_updates(40, [(DeliveryStatus.SENT, 5), (DeliveryStatus.DELIVERED, 15)])` returns `2`.
- A later batch `[(DeliveryStatus.SENT, 5), (DeliveryStatus.FAILED, 30)]` returns `1`.
- `get_update_count(40)` now returns `3`.

## Clarifications

- Times are integer minutes from the start of the current window.
- A duplicate requires both the same status and the same timestamp. Different statuses at one timestamp and one status at different timestamps remain distinct.
- No ordering, transition validation, latest-status calculation, or precedence rule is requested; the enum values preserve the source ranks only.
- add_notification appends records, and get_notification returns the first matching record or None.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/15-Notification/NotificationProblem.txt)


---

# 16. Music Analytics, Duplicate Groups, and Playlist Rules

Compute listener statistics, identify duplicate catalog entries, and evaluate playlist rules. This later music variant includes a playlist task reconstructed from the source tests and implementation.

## Data model

- **Song**: `song_id: int, title: str, artist: str, duration_seconds: int, description: str | None = None, album: str | None = None, release_year: int | None = None, genre: str | None = None`
- **PlayEvent**: `play_id: int, user_id: int, song_id: int, listened_seconds: int, timestamp: int`
- **ListenerStats**: `total_plays: int, unique_songs: int, completion_rate: float`
- **DedupResult**: `song_id: int, merged_ids: list[int]`
- **Rule**: `type: str, max_seconds: int = 0, artist: str | None = None, max_count: int = 0`
- **Playlist**: `playlist_id: int, owner_user_id: int, song_ids: list[int], rules: list[Rule]`

## Stage 1: Repair listener statistics

- Read MusicLibrary and repair its failed statistics test.
- For the requested user, count all play events and all distinct song IDs, including skipped plays. A play is completed when listened_seconds is at least the song duration. Return completed plays / total plays, or 0.0 if there are no plays.

Python methods:

- `get_listener_stats(user_id: int) -> ListenerStats`

## Stage 2: Identify catalog duplicates

- Group songs with matching title and artist ignoring case, and exactly equal duration_seconds. Song IDs are unique.
- For every group with more than one song, keep the smallest song ID and return the other IDs in ascending order as merged_ids. Sort the DedupResult list by retained song ID.
- Identify groups only: do not remove catalog entries or rewrite play events. Return [] when no duplicate group exists.

Python methods:

- `find_duplicate_groups() -> list[DedupResult]`

## Stage 3: Validate playlist rules (reconstructed from source tests)

- For MAX_DURATION, report a violation when the sum of playlist song durations exceeds max_seconds.
- For MAX_PER_ARTIST, report a violation when occurrences of the specified artist exceed max_count.
- Return the names of violated rules in their input order. A missing playlist or a playlist without rules returns []. Evaluate each rule independently.

Python methods:

- `validate_playlist(playlist_id: int) -> list[str]`

## Examples

- Four plays of three distinct songs, with two completed plays, produce `ListenerStats(4, 3, 0.5)`.
- Songs 9, 2, and 7 with the same normalized title, artist, and duration produce `DedupResult(2, [7, 9])`.
- A playlist totaling 700 seconds with a 500-second limit reports `"MAX_DURATION"`.

## Clarifications

- Stage 3 has no standalone prose statement in the repository. Its contract is derived from testPlaylistValidation, the Rule/Playlist models, and the supplied Java implementation.
- Play events refer to known songs. Song IDs are unique. Deduplication ignores description, album, release_year, and genre; title and artist comparisons use Python casefold().
- Playlist artist rules use exact case-sensitive matching, consistent with the Java implementation. Repeated song IDs count as repeated occurrences.
- Unknown song IDs in a playlist are skipped, matching the supplied Java answer. Only MAX_DURATION and MAX_PER_ARTIST rules are in scope.
- The Python Rule dataclass replaces Java overloads: Rule("MAX_DURATION", max_seconds=500) or Rule("MAX_PER_ARTIST", artist="Artist A", max_count=1).

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/16-Music/MusicProblem.txt)


---

# 17. Toll Logs, Complete Journeys, and Speeding Detection

Parse toll-booth observations, count completed highway journeys, and flag journeys whose segment speeds exceed the stated thresholds.

## Data model

- **LogEntry**: `timestamp: float, license_plate: str, booth_type: str, location: int, direction: str`
- **LogFile**: `log_entries: list[LogEntry]`

## Stage 1: Repair log parsing

- Read LogEntry and LogFile, then fix the parsing regression.
- Parse a line as timestamp, license plate, distance/direction token, and booth type. Preserve timestamp precision within 0.0001 seconds of the displayed decimal value. Convert E to EAST and W to WEST.

Python methods:

- `LogEntry(log_line: str)`
- `LogFile(reader: str | Iterable[str])`
- `get(index: int) -> LogEntry`
- `size() -> int`

## Stage 2: Count complete journeys

- Count journeys consisting of ENTRY, zero or more MAINROAD observations, then EXIT for a vehicle.
- You may assume journeys are complete and there are no missing observations. Different vehicles may be interleaved, and the same plate may take multiple journeys.

Python methods:

- `count_journeys() -> int`

## Stage 3: Find unsafe journeys

- Flag a journey if any 10 km segment has speed >= 130 km/h, or if at least two of its 10 km segments have speed >= 120 km/h.
- Return a list containing a license plate once per flagged journey. The same plate can therefore appear multiple times. Result order is not significant.
- Do not measure the gap between an EXIT and the next ENTRY. Reset all speeding state between journeys.

Python methods:

- `catch_speeders() -> list[str]`

## Examples

- `LogEntry("44776.619 KTB918 310E MAINROAD")` has location `310`, direction `"EAST"`, and timestamp approximately `44776.619`.
- An ENTRY at 1000 seconds followed by EXIT at 1275 seconds is a 10 km journey at approximately 130.91 km/h, so its plate is flagged.
- Two 10 km segments taking 300 seconds each meet the two-segment 120 km/h threshold.

## Clarifications

- Log lines have four whitespace-separated tokens and valid booth types ENTRY, MAINROAD, or EXIT. Direction must be E or W; any other direction raises ValueError.
- For speeding analysis, successive observations within one journey represent consecutive 10 km segments and strictly increasing timestamps for that vehicle. Other vehicles can be interleaved.
- The count-only SMALL_LOG source fixture includes a 120E-to-290E jump despite the no-missing-observations assumption. It is retained only for parsing/counting tests, not used as a valid speeding fixture.
- LogFile accepts either a text string or an iterable of lines such as io.StringIO. No physical file is required.
- The timestamp accuracy expectation is made explicit for this Python adaptation; source Java f-suffixed test literals obscure the float32 precision loss.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/17-TollBooth/TollBoothProblem.txt)


---

# 18. Equipment Reservations with Turnaround Time

Manage sports-facility equipment reservations, query active member bookings, and find equipment with a 30-minute cleaning gap around a requested interval.

## Data model

- **ReservationStatus**: `ACTIVE, CANCELLED`
- **Equipment**: `equipment_id: int, name: str`
- **Reservation**: `reservation_id: int, member_name: str, equipment_id: int, start_time: int, end_time: int, status: ReservationStatus = ACTIVE`

## Stage 1: Repair cancellation-aware availability

- Read FacilityManager, then repair the failing reservation test.
- make_reservation should append and return True when there is no overlapping active reservation for the same equipment; otherwise return False without storing it. Cancelled reservations stay in history but must not block a new reservation.
- Preserve cancellation by ID: return True when an existing record is marked CANCELLED, or False when the ID is absent.

Python methods:

- `is_available(equipment_id: int, start_time: int, end_time: int) -> bool`
- `make_reservation(reservation: Reservation) -> bool`
- `cancel_reservation(reservation_id: int) -> bool`

## Stage 2: Member history and equipment totals

- Return all active reservations whose member_name equals the requested name. A member without active bookings gets [].
- Return total_reservations and total_minutes for active reservations of one equipment ID. A missing/unused ID gets both values as 0.

Python methods:

- `get_reservations_for_member(member_name: str) -> list[Reservation]`
- `get_equipment_summary(equipment_id: int) -> dict[str, int]`

## Stage 3: Find equipment with cleaning gaps

- Return registered equipment IDs that have no overlap with the requested interval and at least 30 minutes of separation from every active reservation, whether before or after the request.
- A gap of exactly 30 minutes is sufficient. Ignore cancelled bookings. Sort the IDs ascending and return [] if none qualify.

Python methods:

- `get_available_equipment(start_time: int, end_time: int) -> list[int]`

## Examples

For an active booking from 480 to 600 on equipment 1:

- A new overlapping booking is rejected; after cancellation, that same interval can be booked.
- The Stage 3 request 630-720 has exactly 30 minutes of turnaround and can use equipment 1.
- Request 620-720 has only 20 minutes of turnaround and cannot use equipment 1.
- An active booking at 600-720 also prevents request 500-580, but permits 500-570.

## Clarifications

- Times are integer minutes and request/reservation windows have start_time < end_time. Ordinary overlap uses half-open intervals, so touching endpoints do not overlap.
- The 30-minute rule applies to the new Stage 3 availability query only. Preserve the source make_reservation behavior; its earlier tests deliberately allow back-to-back bookings.
- make_reservation does not require the equipment ID to be registered, as demonstrated by the original tests. get_available_equipment considers only entries in equipment_list.
- Member names compare by string value, case-sensitively. Lists preserve reservation insertion order unless the contract explicitly requires sorting.
- Reservation equality/hash use reservation_id, matching the Java model. No additional duplicate-ID enforcement is introduced.

## Practice files

Edit `starter.py`. Run only Stage 1 first: exactly one test method should fail. Then implement later stages in order. `solution.py` and `SOLUTION_NOTES.md` are the answer key.

[Original problem](https://github.com/Krishnazz/Karat-Preperation/blob/d2af0e84e7f5e4ea902a9f62c4b1d1e6445201ba/18-RentalLatest/RentalLatestProblem.txt)
