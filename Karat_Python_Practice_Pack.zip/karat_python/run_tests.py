#!/usr/bin/env python3
"""Run one stage of a Python interview exercise using only the standard library."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def catalog():
    items = []
    for path in sorted((ROOT / "exercises").glob("*/metadata.json")):
        metadata = json.loads(path.read_text(encoding="utf-8"))
        items.append((path.parent, metadata))
    return items


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Practice a debugging stage or validate a completed exercise."
    )
    parser.add_argument("--list", action="store_true", help="List the exercises and stages.")
    parser.add_argument("--exercise", default="01", help="Exercise number (01-18), full folder name, or all.")
    parser.add_argument("--stage", default="1", help="A stage number or all. Default: 1.")
    parser.add_argument("--mode", choices=("starter", "solution"), default="starter")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show each test name.")
    args = parser.parse_args(argv)
    if args.stage != "all" and (not args.stage.isdigit() or int(args.stage) < 1):
        parser.error("--stage must be a positive integer or all")
    if args.stage != "all":
        args.stage = str(int(args.stage))
    items = catalog()
    if args.list:
        for directory, metadata in items:
            stages = ", ".join(str(s["stage"]) for s in metadata["stages"])
            print(f"{metadata['id']}  {metadata['title']}  [stages {stages}]")
        return 0
    requested = args.exercise.zfill(2) if args.exercise.isdigit() else args.exercise
    selected = [
        (directory, metadata) for directory, metadata in items
        if requested == "all" or requested in (metadata["id"], directory.name)
    ]
    if not selected:
        parser.error("Unknown exercise. Run python run_tests.py --list to see choices.")

    total_tests = total_failures = total_errors = total_skipped = executed = 0
    for directory, metadata in selected:
        stages = {str(s["stage"]) for s in metadata["stages"]}
        if args.stage != "all" and args.stage not in stages:
            if requested != "all":
                parser.error(f"Exercise {metadata['id']} has stages {', '.join(sorted(stages))}.")
            print(f"Skipping {metadata['id']}: no stage {args.stage}.")
            continue
        module_name = f"karat_{metadata['id']}_{args.mode}"
        implementation = load_module(directory / f"{args.mode}.py", module_name)
        tests = load_module(directory / "test_exercise.py", f"karat_{metadata['id']}_tests")
        suite = tests.build_suite(implementation, stage=args.stage)
        if suite.countTestCases() == 0:
            raise RuntimeError(f"No tests were selected for exercise {metadata['id']}.")
        print(f"\n{metadata['id']} | {metadata['title']} | {args.mode} | stage {args.stage}", flush=True)
        result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2 if args.verbose else 1).run(suite)
        executed += 1
        total_tests += result.testsRun
        total_failures += len(result.failures)
        total_errors += len(result.errors)
        total_skipped += len(result.skipped)

    if executed == 0:
        parser.error(f"No exercises contain stage {args.stage}.")
    print(
        f"\nTOTAL: {executed} exercise(s), {total_tests} tests, "
        f"{total_failures} failures, {total_errors} errors, {total_skipped} skipped."
    )
    if args.mode == "starter" and args.stage == "1" and total_failures:
        print("An unedited Stage 1 starter intentionally has one failing regression test per exercise.")
    elif args.mode == "starter" and total_errors:
        print("Later-stage methods start as NotImplementedError stubs; implement them before running those stages.")
    return 1 if total_failures or total_errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
